# User Guide: Naming Things Application

This guide provides detailed instructions for using the improved Naming Things application with all its new features.

## Table of Contents

1. [Introduction](#introduction)
2. [Getting Started](#getting-started)
3. [Developer Name Generator](#developer-name-generator)
4. [Personal Name Generator](#personal-name-generator)
5. [Authentication System](#authentication-system)
6. [Subscription Tiers](#subscription-tiers)
7. [Name Feedback System](#name-feedback-system)
8. [Troubleshooting](#troubleshooting)

## Introduction

The Naming Things application is a comprehensive tool that helps you generate names for:
- Developer resources (functions, methods, variables)
- Personal use (babies, pets)

The application uses AI to generate contextually appropriate name suggestions based on your input.

## Getting Started

### System Requirements
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Internet connection
- Node.js and npm (for local installation)

### Installation

#### Local Installation
1. Extract the `naming_things_improved_final.zip` file
2. Open a terminal and navigate to the extracted directory
3. Run `npm install` to install dependencies
4. Create a `.env` file based on `.env.example`
5. Run `npm start` to start the server
6. Access the application at http://localhost:3000

#### Online Access
The application can also be accessed online at [your-deployment-url].

## Developer Name Generator

The Developer Name Generator helps you create meaningful names for your code elements.

### How to Use
1. Select the "Developer Tool" tab
2. Choose input type:
   - **Description**: Enter a text description of what your function/method does
   - **Code**: Paste a code snippet for context
3. Enter your input in the text area
4. Click "Generate Names"
5. Review the generated suggestions
6. Rate names using the star rating system
7. Click on a name to copy it to clipboard

### Examples

#### Description Input
Input: "A function that calculates the total price including tax"
Output: 
- calculateTotalWithTax
- computePriceAfterTax
- getTaxInclusivePrice

#### Code Input
Input: 
```javascript
function(items) {
  let sum = 0;
  for(let i = 0; i < items.length; i++) {
    sum += items[i].price;
  }
  return sum;
}
```
Output:
- calculateTotalPrice
- sumItemPrices
- computeOrderTotal

## Personal Name Generator

The Personal Name Generator helps you find names for babies, pets, or other personal uses.

### How to Use
1. Select the "Personal Names" tab
2. Choose name type:
   - Baby
   - Pet
3. Select gender:
   - Boy
   - Girl
   - Neutral
4. Choose origin:
   - Nordic
   - Italian
   - German
   - Greek
   - Hebrew
   - African
   - Indian
   - Japanese
   - Chinese
   - Arabic
   - Other options...
5. Click "Generate Names"
6. Review the generated suggestions
7. Rate names using the star rating system
8. Click on a name to copy it to clipboard

### Non-Latin Script Names
For Japanese, Chinese, and Arabic names, both the original script and English translation are displayed:
- Japanese: "健太 - Kenta"
- Chinese: "李明 - Li Ming"
- Arabic: "محمد - Muhammad"

## Authentication System

The application includes a complete authentication system to manage your account and subscription tier.

### Registration
1. Click "Register" in the navigation bar
2. Fill in your details:
   - Name
   - Email
   - Password
   - Confirm Password
3. Click "Create Account"
4. Alternatively, click "Sign in with Google" for faster registration

### Login
1. Click "Login" in the navigation bar
2. Enter your email and password
3. Click "Sign In"
4. Alternatively, click "Sign in with Google"

### Profile Management
1. After logging in, click your name in the navigation bar
2. Select "Profile" to view your account details
3. View your current subscription tier
4. Manage your subscription

## Subscription Tiers

The application offers three subscription tiers with different features and limitations.

### Free Tier
- 10 name suggestions per request
- 500 character input limit
- 5 requests per day
- Basic name options

### Premium Tier ($5/month)
- 25 name suggestions per request
- 2000 character input limit
- Unlimited requests
- Enhanced AI suggestions
- Priority support

### Enterprise Tier ($15/month)
- 50 name suggestions per request
- 5000 character input limit
- Unlimited requests
- Premium AI models
- API access
- Custom integration
- Dedicated support

### Upgrading Your Subscription
1. Navigate to the pricing page
2. Select your desired tier
3. Click "Upgrade"
4. Complete the payment process through Stripe
5. Your account will be immediately upgraded

### Cancelling Your Subscription
1. Go to your profile page
2. Click "Manage Subscription"
3. Click "Cancel Subscription"
4. Confirm cancellation
5. Your account will revert to the Free tier at the end of your billing period

## Name Feedback System

The feedback system helps improve future name suggestions based on your ratings.

### How to Rate Names
1. Generate names using either the Developer or Personal name generator
2. For each name, click on the stars to rate (1-5 stars)
3. Your feedback is automatically saved
4. Future name suggestions will be improved based on your ratings

## Troubleshooting

### Common Issues

#### Application Not Loading
- Check your internet connection
- Clear your browser cache
- Try a different browser

#### Login Issues
- Ensure you're using the correct email and password
- Check if caps lock is enabled
- Try resetting your password
- Try the "Sign in with Google" option

#### Payment Issues
- Ensure your credit card information is correct
- Check if your card has sufficient funds
- Contact your bank if the payment is declined
- Try a different payment method

### Getting Help
For additional assistance, please contact support at support@namingthings.com
