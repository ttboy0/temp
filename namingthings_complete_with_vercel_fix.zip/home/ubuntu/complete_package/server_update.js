// Integration of enhanced OpenAI service with server.js
const EnhancedOpenAIService = require('./services/enhancedOpenAIService');
const expandedNames = require('./data/expanded_names');
const nameRules = require('./data/name_rules');

// Update server.js to use the enhanced OpenAI service and name rules
module.exports = function updateServer(app) {
  // Initialize AI service based on configuration
  let aiService;
  const MODEL_CONFIG = {
    mode: process.env.MODEL_MODE || 'local',
    openaiApiKey: process.env.OPENAI_API_KEY || '',
    openaiModel: process.env.OPENAI_MODEL || 'gpt-3.5-turbo',
    localModelPath: process.env.LOCAL_MODEL_PATH || './models'
  };

  if (MODEL_CONFIG.mode === 'openai' || MODEL_CONFIG.mode === 'hybrid') {
    aiService = new EnhancedOpenAIService(MODEL_CONFIG.openaiApiKey);
  } else if (MODEL_CONFIG.mode === 'local') {
    const LocalAIService = require('./services/localAIService');
    aiService = new LocalAIService(MODEL_CONFIG.localModelPath);
  }

  // Enhanced function to generate baby names with expanded datasets and rules
  function generateBabyNames(gender, style, origin, numSuggestions = 10, seed = 0) {
    let names = [];
    
    // Use expanded datasets for Nordic and Indian names if available
    if (origin === 'nordic' && expandedNames.nordic && expandedNames.nordic[gender]) {
      names = names.concat(expandedNames.nordic[gender]);
    } else if (origin === 'indian' && expandedNames.indian && expandedNames.indian[gender]) {
      names = names.concat(expandedNames.indian[gender]);
    } else {
      // Use existing logic for other origins
      // (existing code from server.js)
    }
    
    // Apply name rules for validation and improvement
    names = names.map(name => {
      // Validate and improve name based on rules
      if (!nameRules.validateName(name, 'baby')) {
        return '';
      }
      return nameRules.improveName(name, 'baby', style, origin);
    }).filter(name => name.length > 0);
    
    // If we don't have enough names, try to generate with OpenAI if available
    if (names.length < numSuggestions && aiService instanceof EnhancedOpenAIService && aiService.isInitialized()) {
      try {
        const openaiNames = aiService.generatePersonalNames('baby', gender, style, origin, null, numSuggestions, seed);
        names = names.concat(openaiNames);
      } catch (error) {
        console.error('Error generating names with OpenAI:', error);
      }
    }
    
    // Shuffle and return requested number of names
    return shuffleArray(names, seed).slice(0, numSuggestions);
  }

  // Enhanced function to generate pet names with rules
  function generatePetNames(gender, style, theme, numSuggestions = 10, seed = 0) {
    let names = [];
    
    // Use existing pet name lists
    // (existing code from server.js)
    
    // Apply name rules for validation and improvement
    names = names.map(name => {
      // Validate and improve name based on rules
      if (!nameRules.validateName(name, 'pet')) {
        return '';
      }
      return nameRules.improveName(name, 'pet', style, null);
    }).filter(name => name.length > 0);
    
    // If we don't have enough names, try to generate with OpenAI if available
    if (names.length < numSuggestions && aiService instanceof EnhancedOpenAIService && aiService.isInitialized()) {
      try {
        const openaiNames = aiService.generatePersonalNames('pet', gender, style, null, theme, numSuggestions, seed);
        names = names.concat(openaiNames);
      } catch (error) {
        console.error('Error generating names with OpenAI:', error);
      }
    }
    
    // Shuffle and return requested number of names
    return shuffleArray(names, seed).slice(0, numSuggestions);
  }

  // Enhanced function to validate and improve names
  function validateAndImproveNames(names, type, origin, style) {
    // Filter out invalid names and improve valid ones
    return names
      .map(name => {
        // Validate name based on type and script
        if (!nameRules.validateName(name, type)) {
          // If invalid, try to improve it
          if (name.length < 3 && !['chinese', 'japanese', 'arabic'].includes(origin)) {
            return nameRules.improvement.abbreviations[name] || '';
          }
          return '';
        }
        
        // Improve name based on type, style, and origin
        return nameRules.improveName(name, type, style, origin);
      })
      .filter(name => name.length > 0); // Remove any empty names
  }

  return {
    generateBabyNames,
    generatePetNames,
    validateAndImproveNames,
    aiService
  };
};
