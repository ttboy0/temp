/**
 * User Authentication Module
 * 
 * This file contains functionality for user authentication, registration,
 * and session management
 */

// Mock database for user storage (in a real app, this would be a database)
const users = [];

// User session storage
const sessions = {};

// Function to register a new user
function registerUser(email, password, name) {
  // Check if user already exists
  const existingUser = users.find(user => user.email === email);
  if (existingUser) {
    return { success: false, message: 'User with this email already exists' };
  }
  
  // Create new user with free tier by default
  const newUser = {
    id: generateUserId(),
    email,
    password, // In a real app, this would be hashed
    name,
    tier: 'free',
    registrationDate: new Date(),
    lastLogin: new Date()
  };
  
  users.push(newUser);
  
  return { success: true, message: 'Registration successful', userId: newUser.id };
}

// Function to authenticate a user
function loginUser(email, password) {
  // Find user by email
  const user = users.find(user => user.email === email);
  
  // Check if user exists and password matches
  if (!user || user.password !== password) {
    return { success: false, message: 'Invalid email or password' };
  }
  
  // Update last login time
  user.lastLogin = new Date();
  
  // Create session
  const sessionId = generateSessionId();
  sessions[sessionId] = {
    userId: user.id,
    email: user.email,
    name: user.name,
    tier: user.tier,
    created: new Date()
  };
  
  return { 
    success: true, 
    message: 'Login successful', 
    sessionId,
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      tier: user.tier
    }
  };
}

// Function to register or login with Google
function googleAuth(googleUserData) {
  // Extract user info from Google data
  const { email, name, googleId } = googleUserData;
  
  // Check if user already exists
  let user = users.find(user => user.email === email);
  
  if (!user) {
    // Create new user with Google info
    user = {
      id: generateUserId(),
      email,
      name,
      googleId,
      tier: 'free',
      registrationDate: new Date(),
      lastLogin: new Date()
    };
    
    users.push(user);
  } else {
    // Update existing user with Google ID if not present
    if (!user.googleId) {
      user.googleId = googleId;
    }
    user.lastLogin = new Date();
  }
  
  // Create session
  const sessionId = generateSessionId();
  sessions[sessionId] = {
    userId: user.id,
    email: user.email,
    name: user.name,
    tier: user.tier,
    created: new Date()
  };
  
  return { 
    success: true, 
    message: 'Google authentication successful', 
    sessionId,
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      tier: user.tier
    }
  };
}

// Function to validate a session
function validateSession(sessionId) {
  const session = sessions[sessionId];
  
  if (!session) {
    return { valid: false, message: 'Invalid session' };
  }
  
  // Check if session is expired (24 hours)
  const now = new Date();
  const sessionAge = now - session.created;
  const sessionExpiry = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
  
  if (sessionAge > sessionExpiry) {
    delete sessions[sessionId];
    return { valid: false, message: 'Session expired' };
  }
  
  return { 
    valid: true, 
    user: {
      id: session.userId,
      email: session.email,
      name: session.name,
      tier: session.tier
    }
  };
}

// Function to logout (invalidate session)
function logoutUser(sessionId) {
  if (sessions[sessionId]) {
    delete sessions[sessionId];
    return { success: true, message: 'Logout successful' };
  }
  
  return { success: false, message: 'Invalid session' };
}

// Function to update user tier
function updateUserTier(userId, newTier) {
  const user = users.find(user => user.id === userId);
  
  if (!user) {
    return { success: false, message: 'User not found' };
  }
  
  user.tier = newTier;
  
  // Update tier in any active sessions for this user
  Object.keys(sessions).forEach(sessionId => {
    if (sessions[sessionId].userId === userId) {
      sessions[sessionId].tier = newTier;
    }
  });
  
  return { success: true, message: 'User tier updated successfully' };
}

// Helper function to generate a unique user ID
function generateUserId() {
  return 'user_' + Math.random().toString(36).substr(2, 9);
}

// Helper function to generate a unique session ID
function generateSessionId() {
  return 'session_' + Math.random().toString(36).substr(2, 9);
}

module.exports = {
  registerUser,
  loginUser,
  googleAuth,
  validateSession,
  logoutUser,
  updateUserTier
};
