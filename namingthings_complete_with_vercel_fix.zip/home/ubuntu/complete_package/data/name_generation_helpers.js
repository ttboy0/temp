// Modify server.js to integrate expanded name datasets
const expandedNames = require('./data/expanded_names');

// Update the generateBabyNames function to use expanded datasets
function generateBabyNames(gender, style, origin, numSuggestions = 10, seed = 0) {
  let names = [];
  
  // Use expanded datasets for Nordic and Indian names if available
  if (origin === 'nordic' && expandedNames.nordic && expandedNames.nordic[gender]) {
    names = names.concat(expandedNames.nordic[gender]);
  } else if (origin === 'indian' && expandedNames.indian && expandedNames.indian[gender]) {
    names = names.concat(expandedNames.indian[gender]);
  } else {
    // Use existing logic for other origins
    if (gender === 'boy') {
      if (origin === 'english' || origin === 'any') {
        names = names.concat([
          'Liam', 'Noah', 'Oliver', 'Elijah', 'William', 'James', 'Benjamin', 'Lucas', 'Henry', 'Alexander',
          'Mason', 'Michael', 'Ethan', 'Daniel', 'Jacob', 'Logan', 'Jackson', 'Levi', 'Sebastian', 'Mateo',
          'Jack', 'Owen', 'Theodore', 'Aiden', 'Samuel', 'Joseph', 'John', 'David', 'Wyatt', 'Matthew'
        ]);
      }
      
      if (origin === 'french' || origin === 'any') {
        names = names.concat([
          'Louis', 'Hugo', 'Gabriel', 'Léo', 'Raphaël', 'Jules', 'Adam', 'Lucas', 'Arthur', 'Nathan',
          'Ethan', 'Théo', 'Noah', 'Mathis', 'Enzo', 'Maël', 'Timéo', 'Nolan', 'Gabin', 'Sacha'
        ]);
      }
      
      // Continue with existing origin checks...
    } else if (gender === 'girl') {
      // Existing girl name logic...
    } else if (gender === 'neutral') {
      // Existing neutral name logic...
    }
  }
  
  // Apply style filtering
  names = filterNamesByStyle(names, style, origin);
  
  // Shuffle and return requested number of names
  return shuffleArray(names, seed).slice(0, numSuggestions);
}

// Helper function to filter names by style
function filterNamesByStyle(names, style, origin) {
  // If no style specified or not enough names, return all
  if (!style || style === 'any' || names.length < 20) {
    return names;
  }
  
  // Create a copy of the names array to avoid modifying the original
  const namesCopy = [...names];
  
  // Shuffle the array with a consistent seed based on style and origin
  const seed = (style.charCodeAt(0) + (origin ? origin.charCodeAt(0) : 0)) / 100;
  const shuffledNames = shuffleArray(namesCopy, seed);
  
  // Select names based on style
  switch (style) {
    case 'common':
      // Common names are typically shorter and more familiar
      return shuffledNames.filter(name => name.length < 8).slice(0, Math.floor(shuffledNames.length * 0.6));
    case 'unique':
      // Unique names are typically longer or less common
      return shuffledNames.filter(name => name.length >= 5).slice(Math.floor(shuffledNames.length * 0.4));
    case 'traditional':
      // Traditional names are typically in the first half of the shuffled array (arbitrary but consistent)
      return shuffledNames.slice(0, Math.floor(shuffledNames.length * 0.5));
    case 'modern':
      // Modern names are typically in the second half of the shuffled array (arbitrary but consistent)
      return shuffledNames.slice(Math.floor(shuffledNames.length * 0.5));
    default:
      return shuffledNames;
  }
}
