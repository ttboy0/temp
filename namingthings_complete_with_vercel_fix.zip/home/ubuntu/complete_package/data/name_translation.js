/**
 * Name Translation Utilities
 * 
 * This file contains utilities for translating non-Latin script names
 * and displaying them with their English translations
 */

// Function to format a name with its translation
function formatNameWithTranslation(name) {
  // Check if the name already contains a translation (format: "原名 - Translation")
  if (name.includes(' - ')) {
    return name; // Already formatted correctly
  }
  
  // For names without translation, return as is
  return name;
}

// Function to extract original name from formatted string
function getOriginalName(formattedName) {
  if (formattedName.includes(' - ')) {
    return formattedName.split(' - ')[0].trim();
  }
  return formattedName;
}

// Function to extract translation from formatted string
function getTranslation(formattedName) {
  if (formattedName.includes(' - ')) {
    return formattedName.split(' - ')[1].trim();
  }
  return formattedName; // For Latin script names, return the name itself
}

// Function to detect if a name is in a non-Latin script
function isNonLatinScript(name) {
  // Extract original name if it's a formatted string
  const originalName = getOriginalName(name);
  
  // Regular expressions for different non-Latin scripts
  const nonLatinScripts = {
    japanese: /[\u3040-\u309F\u30A0-\u30FF]/,
    chinese: /[\u4E00-\u9FFF\u3400-\u4DBF]/,
    arabic: /[\u0600-\u06FF]/,
    cyrillic: /[\u0400-\u04FF]/,
    devanagari: /[\u0900-\u097F]/,
    hebrew: /[\u0590-\u05FF]/,
    thai: /[\u0E00-\u0E7F]/,
    korean: /[\uAC00-\uD7AF\u1100-\u11FF]/
  };
  
  // Check if the name contains characters from any non-Latin script
  for (const script in nonLatinScripts) {
    if (nonLatinScripts[script].test(originalName)) {
      return true;
    }
  }
  
  return false;
}

// Function to identify which script a name is in
function identifyScript(name) {
  // Extract original name if it's a formatted string
  const originalName = getOriginalName(name);
  
  // Regular expressions for different scripts
  const scripts = {
    latin: /^[A-Za-z\s\-']+$/,
    // Japanese-specific characters (hiragana and katakana)
    japanese: /[\u3040-\u309F\u30A0-\u30FF]/,
    // Chinese characters (hanzi) - note that some overlap with Japanese kanji
    chinese: /^[\u4E00-\u9FFF\u3400-\u4DBF]+$/,
    arabic: /[\u0600-\u06FF]/,
    cyrillic: /[\u0400-\u04FF]/,
    devanagari: /[\u0900-\u097F]/,
    hebrew: /[\u0590-\u05FF]/,
    thai: /[\u0E00-\u0E7F]/,
    korean: /[\uAC00-\uD7AF\u1100-\u11FF]/
  };
  
  // Special case for Chinese vs Japanese
  // If it contains Chinese characters but no Japanese-specific characters, it's Chinese
  if (scripts.chinese.test(originalName) && !scripts.japanese.test(originalName)) {
    return 'chinese';
  }
  
  // If it contains Japanese-specific characters, it's Japanese
  if (scripts.japanese.test(originalName)) {
    return 'japanese';
  }
  
  // Check other scripts
  for (const script in scripts) {
    // Skip Japanese and Chinese as we've already handled them
    if (script === 'japanese' || script === 'chinese') continue;
    
    if (scripts[script].test(originalName)) {
      return script;
    }
  }
  
  return 'unknown';
}

module.exports = {
  formatNameWithTranslation,
  getOriginalName,
  getTranslation,
  isNonLatinScript,
  identifyScript
};
