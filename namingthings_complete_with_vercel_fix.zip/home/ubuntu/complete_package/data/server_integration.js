// Integration of name rules with server.js
const nameRules = require('./data/name_rules');

// Update the validateAndImproveNames function to use the new name rules
function validateAndImproveNames(names, type, origin, style) {
  // Filter out invalid names and improve valid ones
  return names
    .map(name => {
      // For Chinese, Japanese, and Arabic names, use special validation
      const isNonLatinScript = origin === 'chinese' || origin === 'japanese' || origin === 'arabic';
      
      // Validate name based on type and script
      if (!nameRules.validateName(name, type)) {
        // If invalid, try to improve it
        if (name.length < 3 && !isNonLatinScript) {
          return nameRules.improvement.abbreviations[name] || '';
        }
        return '';
      }
      
      // Improve name based on type, style, and origin
      return nameRules.improveName(name, type, style, origin);
    })
    .filter(name => name.length > 0); // Remove any empty names
}
