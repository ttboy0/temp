/**
 * Name-specific rules for improved name generation
 * This file contains rules and patterns for generating better quality names
 */

const nameRules = {
  // Rules for validating and improving names
  validation: {
    // Minimum length requirements by script type
    minLength: {
      latin: 3,        // Latin script (English, French, Spanish, etc.)
      cyrillic: 3,     // Cyrillic script (Russian, etc.)
      devanagari: 2,   // Devanagari script (Hindi, etc.)
      chinese: 1,      // Chinese characters
      japanese: 1,     // Japanese characters
      arabic: 2,       // Arabic script
      hebrew: 2,       // Hebrew script
      thai: 2,         // Thai script
      korean: 1        // Korean script
    },
    
    // Maximum length recommendations by name type
    maxLength: {
      developer: 30,   // Function/method names
      baby: 15,        // Baby names
      pet: 12          // Pet names
    },
    
    // Patterns to avoid in names (regex patterns)
    avoidPatterns: {
      developer: [
        /^[0-9]/, // Names starting with numbers
        /[^\w$]/, // Names with special characters (except $ for JavaScript)
        /^(function|class|var|let|const|if|else|for|while|do|switch|case|break|return|try|catch|finally)$/ // Reserved words
      ],
      baby: [
        /[0-9]/, // Names with numbers
        /[^\p{L}\s\-']/u, // Names with special characters (except hyphen and apostrophe)
        /(.)\1{2,}/ // Names with three or more repeated characters
      ],
      pet: [
        /[^\p{L}\s\-'0-9]/u, // Names with special characters (except hyphen and apostrophe)
        /(.)\1{3,}/ // Names with four or more repeated characters
      ]
    }
  },
  
  // Script detection patterns
  scriptDetection: {
    latin: /^[A-Za-z\s\-']+$/,
    cyrillic: /^[\u0400-\u04FF\s\-']+$/,
    devanagari: /^[\u0900-\u097F\s\-']+$/,
    chinese: /^[\u4E00-\u9FFF\s\-']+$/,
    japanese: /^[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF\s\-']+$/,
    arabic: /^[\u0600-\u06FF\s\-']+$/,
    hebrew: /^[\u0590-\u05FF\s\-']+$/,
    thai: /^[\u0E00-\u0E7F\s\-']+$/,
    korean: /^[\uAC00-\uD7AF\u1100-\u11FF\s\-']+$/
  },
  
  // Name improvement rules
  improvement: {
    // Capitalization rules by name type
    capitalization: {
      developer: 'camelCase', // camelCase for functions
      baby: 'Title Case',     // Title Case for baby names
      pet: 'Title Case'       // Title Case for pet names
    },
    
    // Common abbreviations and their expansions
    abbreviations: {
      'Ja': 'James',
      'Ma': 'Matthew',
      'Jo': 'Joseph',
      'Mi': 'Michael',
      'Da': 'Daniel',
      'Sa': 'Samuel',
      'An': 'Andrew',
      'Al': 'Alexander',
      'Ro': 'Robert',
      'Wi': 'William',
      'Th': 'Thomas',
      'Ch': 'Charles',
      'Ed': 'Edward',
      'Ri': 'Richard',
      'Pa': 'Patrick',
      'St': 'Steven',
      'Ge': 'George',
      'Fr': 'Francis',
      'Ni': 'Nicholas',
      'Be': 'Benjamin',
      'Br': 'Brian',
      'Ke': 'Kevin',
      'Je': 'Jeffrey',
      'Gr': 'Gregory',
      'Ti': 'Timothy',
      'Ra': 'Raymond',
      'Sc': 'Scott',
      'Tr': 'Travis',
      'Ju': 'Justin',
      'Na': 'Nathan',
      'Ad': 'Adam',
      'Aa': 'Aaron',
      'Ry': 'Ryan',
      'Ty': 'Tyler',
      'Co': 'Connor',
      'Ca': 'Caleb',
      'Dy': 'Dylan',
      'Ev': 'Evan',
      'Et': 'Ethan',
      'No': 'Noah',
      'Wy': 'Wyatt',
      'Ai': 'Aiden',
      'Lo': 'Logan',
      'Lu': 'Lucas',
      'El': 'Elijah',
      'Li': 'Liam',
      'Ol': 'Oliver',
      'Ja': 'Jacob',
      'Ow': 'Owen',
      'Se': 'Sebastian',
      'Ga': 'Gabriel',
      'He': 'Henry',
      'Is': 'Isaac',
      'Le': 'Levi',
      'Hu': 'Hunter',
      'Em': 'Emmett',
      'As': 'Asher',
      'Ez': 'Ezra',
      'Th': 'Theodore',
      'Ju': 'Julian',
      'Hu': 'Hudson',
      'Ja': 'Jasper',
      'El': 'Elliott',
      'Au': 'Austin',
      'Ia': 'Ian',
      'Ev': 'Everett',
      'Li': 'Lincoln',
      'Ch': 'Christopher',
      'Na': 'Nathan',
      'Ch': 'Christian',
      'Ma': 'Maverick',
      'Co': 'Colton',
      'El': 'Eli',
      'Vi': 'Vincent',
      'We': 'Wesley'
    },
    
    // Style-specific transformations
    styleTransformations: {
      traditional: {
        // Prefer longer, more established names
        preferPatterns: [/^[A-Z][a-z]{3,}$/],
        avoidPatterns: [/^[A-Z][a-z]{1,2}$/, /[^a-zA-Z]/]
      },
      modern: {
        // Allow shorter, more unique names
        preferPatterns: [/^[A-Z][a-z]{2,6}$/],
        avoidPatterns: []
      },
      unique: {
        // Prefer uncommon letter combinations
        preferPatterns: [/[qxzjvk]/i],
        avoidPatterns: []
      },
      common: {
        // Prefer common letter combinations
        preferPatterns: [/^[A-Z][aeiou][bcdfghlmnprst]/i],
        avoidPatterns: [/[qxzjvk]{2}/i]
      },
      cute: {
        // Prefer names ending with diminutive sounds
        preferPatterns: [/[yi]e$/, /[eo]$/, /ie$/, /y$/],
        avoidPatterns: [/[qxz]/i]
      },
      funny: {
        // Allow more unusual combinations
        preferPatterns: [],
        avoidPatterns: []
      },
      cool: {
        // Prefer shorter names with strong consonants
        preferPatterns: [/^[A-Z][aeiou][xkzjvdtbp]/i, /[xkzjv]/i],
        avoidPatterns: [/ie$/, /[aeiou]{3}/]
      }
    }
  },
  
  // Origin-specific rules
  originRules: {
    nordic: {
      preferPatterns: [/[åäöÅÄÖ]/, /^[A-ZÅÄÖ][a-zåäö]+$/],
      commonEndings: ['son', 'sen', 'sson', 'dottir']
    },
    indian: {
      preferPatterns: [/[aeiou]$/i, /^[A-Z][aeiou]/i],
      commonEndings: ['raj', 'deep', 'esh', 'endra', 'eet', 'ant', 'ita', 'ika']
    }
  }
};

// Function to detect script type
function detectScriptType(name) {
  for (const [script, pattern] of Object.entries(nameRules.scriptDetection)) {
    if (pattern.test(name)) {
      return script;
    }
  }
  return 'latin'; // Default to latin if no match
}

// Function to validate name based on rules
function validateName(name, type) {
  if (!name) return false;
  
  // Detect script type
  const script = detectScriptType(name);
  
  // Check minimum length
  const minLength = nameRules.validation.minLength[script] || 3;
  if (name.length < minLength) return false;
  
  // Check maximum length
  const maxLength = nameRules.validation.maxLength[type] || 30;
  if (name.length > maxLength) return false;
  
  // Check avoid patterns
  const avoidPatterns = nameRules.validation.avoidPatterns[type] || [];
  for (const pattern of avoidPatterns) {
    if (pattern.test(name)) return false;
  }
  
  return true;
}

// Function to improve name based on rules
function improveName(name, type, style, origin) {
  if (!name) return '';
  
  // Detect script type
  const script = detectScriptType(name);
  
  // Expand abbreviations for Latin script
  if (script === 'latin' && name.length <= 2) {
    name = nameRules.improvement.abbreviations[name] || name;
  }
  
  // Apply capitalization rules
  const capitalizationRule = nameRules.improvement.capitalization[type];
  if (capitalizationRule === 'camelCase') {
    name = name.charAt(0).toLowerCase() + name.slice(1);
  } else if (capitalizationRule === 'Title Case') {
    name = name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
  }
  
  // Apply style-specific transformations if applicable
  if (style && nameRules.improvement.styleTransformations[style]) {
    const styleRules = nameRules.improvement.styleTransformations[style];
    
    // Check if name matches preferred patterns
    let matchesPreferred = styleRules.preferPatterns.length === 0;
    for (const pattern of styleRules.preferPatterns) {
      if (pattern.test(name)) {
        matchesPreferred = true;
        break;
      }
    }
    
    // Check if name matches avoid patterns
    let matchesAvoid = false;
    for (const pattern of styleRules.avoidPatterns) {
      if (pattern.test(name)) {
        matchesAvoid = true;
        break;
      }
    }
    
    // If name doesn't match style criteria, return empty to filter it out
    if (!matchesPreferred || matchesAvoid) {
      return '';
    }
  }
  
  // Apply origin-specific rules if applicable
  if (origin && nameRules.originRules[origin]) {
    const originRules = nameRules.originRules[origin];
    
    // Check if name matches preferred patterns for origin
    let matchesOriginPreferred = originRules.preferPatterns.length === 0;
    for (const pattern of originRules.preferPatterns) {
      if (pattern.test(name)) {
        matchesOriginPreferred = true;
        break;
      }
    }
    
    // If name doesn't match origin criteria, return empty to filter it out
    if (!matchesOriginPreferred) {
      return '';
    }
  }
  
  return name;
}

module.exports = {
  validateName,
  improveName,
  detectScriptType,
  nameRules
};
