/**
 * Authentic Names Dataset
 * 
 * This file contains authentic native names for various cultures
 * with English translations where applicable for non-Latin scripts
 */

const authenticNames = {
  nordic: {
    boy: [
      // Swedish, Norwegian, Danish, Finnish, and Icelandic boy names
      'Åke', 'Björn', 'Dag', 'Erik', 'Frode', 'Gunnar', 'Håkon', 'Ivar', 'Jens', 'Knut',
      'Lars', 'Magnus', 'Nils', 'Olav', 'Petter', 'Ragnar', 'Sven', 'Torbjörn', 'Ulf', 'Viggo',
      'Yngve', 'Örjan', 'Åsmund', 'Björk', 'Einar', 'Folke', 'Gorm', 'Harald', 'Ingvar', 'Joar',
      'Kjell', 'Leif', 'Mikkel', 'Njål', 'Oddvar', 'Rune', 'Sigurd', 'Tore', 'Ulf', 'Vidar'
    ],
    girl: [
      // Swedish, Norwegian, Danish, Finnish, and Icelandic girl names
      'Åsa', 'Björg', 'Dagny', 'Elin', 'Freja', 'Greta', 'Helga', 'Ingrid', 'Jórunn', 'Karin',
      'Linnea', 'Märta', 'Nanna', 'Olga', 'Pernilla', 'Ragnhild', 'Sigrid', 'Tove', 'Ulla', 'Vigdis',
      'Ylva', 'Ása', 'Birgitta', 'Dagmar', 'Erika', 'Frida', 'Gudrun', 'Hedvig', 'Inga', 'Johanna',
      'Kristín', 'Liv', 'Maja', 'Nora', 'Ósk', 'Randi', 'Solveig', 'Thora', 'Unnur', 'Vår'
    ],
    neutral: [
      // Gender-neutral Nordic names
      'Åke', 'Bo', 'Eli', 'Hjalmar', 'Inge', 'Kim', 'Lo', 'Mika', 'Noa', 'Rene',
      'Saga', 'Tove', 'Vide', 'Alva', 'Billie', 'Cleo', 'Elliot', 'Kai', 'Lumi', 'Nova'
    ]
  },
  italian: {
    boy: [
      // Authentic Italian boy names
      'Alessandro', 'Bernardo', 'Carlo', 'Dante', 'Enzo', 'Francesco', 'Giuseppe', 'Lorenzo', 'Marco', 'Nicola',
      'Paolo', 'Riccardo', 'Salvatore', 'Tommaso', 'Umberto', 'Vincenzo', 'Antonio', 'Bruno', 'Cesare', 'Dario',
      'Emilio', 'Fabio', 'Gianni', 'Luca', 'Matteo', 'Orazio', 'Pietro', 'Roberto', 'Stefano', 'Vito'
    ],
    girl: [
      // Authentic Italian girl names
      'Alessandra', 'Bianca', 'Chiara', 'Daniela', 'Elena', 'Francesca', 'Giovanna', 'Isabella', 'Lucia', 'Maria',
      'Nicoletta', 'Paola', 'Rosa', 'Sofia', 'Teresa', 'Valentina', 'Adriana', 'Benedetta', 'Carmela', 'Donatella',
      'Eleonora', 'Federica', 'Gabriella', 'Ilaria', 'Laura', 'Margherita', 'Natalia', 'Patrizia', 'Serena', 'Viola'
    ],
    neutral: [
      // Gender-neutral or unisex Italian names
      'Andrea', 'Gabriele', 'Michele', 'Nicola', 'Simone', 'Fiore', 'Celeste', 'Sole', 'Diamante', 'Mare',
      'Felice', 'Bene', 'Amore', 'Cielo', 'Gioia', 'Luce', 'Neve', 'Pace', 'Stella', 'Vento'
    ]
  },
  german: {
    boy: [
      // Authentic German boy names
      'Albrecht', 'Bernhard', 'Christoph', 'Dieter', 'Ernst', 'Friedrich', 'Gerhard', 'Heinrich', 'Johannes', 'Klaus',
      'Ludwig', 'Manfred', 'Norbert', 'Otto', 'Peter', 'Rainer', 'Stefan', 'Thomas', 'Ulrich', 'Wolfgang',
      'Axel', 'Bernd', 'Conrad', 'Dietrich', 'Eberhard', 'Franz', 'Günther', 'Helmut', 'Jürgen', 'Karl',
      'Lothar', 'Matthias', 'Nikolaus', 'Oskar', 'Philipp', 'Rudolf', 'Siegfried', 'Tobias', 'Uwe', 'Werner'
    ],
    girl: [
      // Authentic German girl names
      'Adelheid', 'Brigitte', 'Charlotte', 'Dorothea', 'Elisabeth', 'Franziska', 'Gertrud', 'Hedwig', 'Ingeborg', 'Johanna',
      'Katharina', 'Liesel', 'Margarete', 'Nadine', 'Ottilie', 'Petra', 'Renate', 'Sabine', 'Trude', 'Ursula',
      'Anneliese', 'Brunhilde', 'Claudia', 'Dagmar', 'Emma', 'Frieda', 'Gisela', 'Helga', 'Ilse', 'Julia',
      'Karoline', 'Lotte', 'Mathilde', 'Nina', 'Olga', 'Paula', 'Regina', 'Silvia', 'Theresa', 'Ute'
    ],
    neutral: [
      // Gender-neutral or unisex German names
      'Eike', 'Kim', 'Luca', 'Mika', 'Nicola', 'Quinn', 'Robin', 'Sascha', 'Toni', 'Ulli',
      'Alex', 'Chris', 'Dominique', 'Elia', 'Finn', 'Gabriel', 'Jona', 'Kai', 'Lou', 'Noa'
    ]
  },
  greek: {
    boy: [
      // Authentic Greek boy names
      'Alexandros', 'Basileios', 'Christos', 'Dimitrios', 'Eleftherios', 'Georgios', 'Ioannis', 'Konstantinos', 'Leonidas', 'Michail',
      'Nikolaos', 'Panagiotis', 'Petros', 'Spyridon', 'Theodoros', 'Vasileios', 'Anastasios', 'Athanasios', 'Charalampos', 'Emmanouil',
      'Evangelos', 'Fotios', 'Grigorios', 'Ilias', 'Kyriakos', 'Marios', 'Nikolaos', 'Odysseas', 'Pavlos', 'Stavros'
    ],
    girl: [
      // Authentic Greek girl names
      'Aikaterini', 'Dimitra', 'Eleni', 'Georgia', 'Ioanna', 'Konstantina', 'Maria', 'Nikoleta', 'Olga', 'Paraskevi',
      'Sofia', 'Theodora', 'Vasiliki', 'Zoi', 'Anastasia', 'Chrysanthi', 'Despina', 'Evgenia', 'Fotini', 'Irini',
      'Kalliopi', 'Lamprini', 'Magdalini', 'Nikoleta', 'Ourania', 'Panagiota', 'Stamatina', 'Triantafyllia', 'Xanthi', 'Ypatia'
    ],
    neutral: [
      // Gender-neutral or unisex Greek names
      'Agapi', 'Chrysa', 'Dafni', 'Elpida', 'Fotis', 'Galanis', 'Iason', 'Kleio', 'Lyra', 'Melina',
      'Nefeli', 'Orestes', 'Paris', 'Sotiris', 'Thanasis', 'Vaso', 'Xenia', 'Yanni', 'Zephyr', 'Alexis'
    ]
  },
  hebrew: {
    boy: [
      // Authentic Hebrew boy names
      'Avi', 'Boaz', 'Chaim', 'David', 'Eitan', 'Gabriel', 'Hillel', 'Isaac', 'Jacob', 'Kobi',
      'Levi', 'Moshe', 'Noam', 'Omer', 'Pinchas', 'Rafael', 'Shmuel', 'Tal', 'Uri', 'Yosef',
      'Amir', 'Barak', 'Daniel', 'Efraim', 'Gideon', 'Haim', 'Idan', 'Jonathan', 'Kfir', 'Liron',
      'Matan', 'Nadav', 'Oded', 'Paz', 'Ron', 'Shai', 'Tomer', 'Uzi', 'Yair', 'Zev'
    ],
    girl: [
      // Authentic Hebrew girl names
      'Adina', 'Batya', 'Chana', 'Devorah', 'Esther', 'Gila', 'Hadassah', 'Ilana', 'Judith', 'Keren',
      'Leah', 'Miriam', 'Naomi', 'Ora', 'Penina', 'Rachel', 'Sarah', 'Tamar', 'Yael', 'Ziva',
      'Abigail', 'Bracha', 'Dalia', 'Eden', 'Galit', 'Hila', 'Inbal', 'Kinneret', 'Liat', 'Maya',
      'Noa', 'Orli', 'Pnina', 'Rina', 'Shira', 'Talia', 'Vered', 'Yaffa', 'Zehava', 'Ayelet'
    ],
    neutral: [
      // Gender-neutral or unisex Hebrew names
      'Ariel', 'Gal', 'Hadar', 'Lior', 'Maayan', 'Noam', 'Ori', 'Paz', 'Tal', 'Yuval',
      'Amit', 'Carmel', 'Eden', 'Gili', 'Hen', 'Inbar', 'Lev', 'Mor', 'Neta', 'Omer'
    ]
  },
  african: {
    boy: [
      // Authentic African boy names from various regions
      'Abebe', 'Babatunde', 'Chiumbo', 'Diallo', 'Ekon', 'Faraji', 'Gamba', 'Hakim', 'Imamu', 'Jelani',
      'Kamau', 'Lekan', 'Mandla', 'Nnamdi', 'Oluwaseun', 'Paki', 'Quame', 'Rashidi', 'Sefu', 'Tendai',
      'Uzoma', 'Vusi', 'Wekesa', 'Xolani', 'Yerodin', 'Zuberi', 'Adisa', 'Bongani', 'Chibuzo', 'Djimon',
      'Ekene', 'Folami', 'Gerwazy', 'Hasani', 'Issa', 'Jabari', 'Kofi', 'Lwazi', 'Mosi', 'Nkosi'
    ],
    girl: [
      // Authentic African girl names from various regions
      'Adia', 'Boipelo', 'Chiamaka', 'Dada', 'Ebele', 'Faizah', 'Gasira', 'Hasina', 'Ife', 'Jamila',
      'Kesi', 'Layla', 'Makena', 'Nia', 'Oni', 'Panya', 'Qadira', 'Rashida', 'Safiya', 'Thema',
      'Udo', 'Vela', 'Wangari', 'Xola', 'Yewande', 'Zola', 'Amara', 'Bisa', 'Chinara', 'Dalila',
      'Eshe', 'Fola', 'Gimbya', 'Halima', 'Imani', 'Jendayi', 'Kali', 'Lulama', 'Masego', 'Nala'
    ],
    neutral: [
      // Gender-neutral or unisex African names
      'Amani', 'Badu', 'Chioma', 'Diara', 'Enzi', 'Femi', 'Gahiji', 'Hasani', 'Imara', 'Jaha',
      'Kamaria', 'Lulu', 'Mawuli', 'Nuru', 'Olu', 'Pili', 'Rudo', 'Sade', 'Tau', 'Zuri',
      'Abeni', 'Bisi', 'Chike', 'Dayo', 'Esi', 'Folami', 'Gamba', 'Haji', 'Ife', 'Jelani'
    ]
  },
  indian: {
    boy: [
      // Authentic Indian boy names from various regions
      'Aarav', 'Bodhan', 'Chetan', 'Darshan', 'Ekansh', 'Farhan', 'Girish', 'Harish', 'Ishaan', 'Jagdish',
      'Karthik', 'Lokesh', 'Mahesh', 'Narayan', 'Omkar', 'Pranav', 'Rajesh', 'Sanjay', 'Tarun', 'Umesh',
      'Vijay', 'Yash', 'Abhimanyu', 'Bharat', 'Chandran', 'Devdas', 'Eklavya', 'Ganesh', 'Hemant', 'Indrajit',
      'Jayant', 'Kamlesh', 'Lakshman', 'Mohan', 'Neeraj', 'Prabhat', 'Raghav', 'Shyam', 'Tushar', 'Uday'
    ],
    girl: [
      // Authentic Indian girl names from various regions
      'Aanya', 'Bhavana', 'Chandni', 'Deepika', 'Esha', 'Falguni', 'Gayatri', 'Himani', 'Ishita', 'Jyoti',
      'Kalpana', 'Lalita', 'Madhuri', 'Nandini', 'Ojaswini', 'Priya', 'Rashmi', 'Sarika', 'Tanvi', 'Usha',
      'Vaani', 'Yamini', 'Aishwarya', 'Bhamini', 'Chitra', 'Divya', 'Ekta', 'Garima', 'Harshita', 'Indira',
      'Jaya', 'Kamala', 'Lakshmi', 'Meena', 'Neha', 'Pallavi', 'Radha', 'Savita', 'Tara', 'Uma'
    ],
    neutral: [
      // Gender-neutral or unisex Indian names
      'Akash', 'Chaman', 'Gyan', 'Indra', 'Jyoti', 'Kiran', 'Mani', 'Noor', 'Prem', 'Raj',
      'Santosh', 'Tarun', 'Anand', 'Chandra', 'Daya', 'Inder', 'Jeet', 'Kamal', 'Manju', 'Om',
      'Prakash', 'Roop', 'Shanti', 'Tej', 'Vimal', 'Amar', 'Bala', 'Chetan', 'Divya', 'Gita'
    ]
  },
  japanese: {
    boy: [
      // Authentic Japanese boy names with English translations
      '健太 - Kenta', '大輔 - Daisuke', '翔太 - Shota', '拓也 - Takuya', '健一 - Ken\'ichi', 
      '直樹 - Naoki', '浩二 - Koji', '誠 - Makoto', '和也 - Kazuya', '剛 - Tsuyoshi',
      '哲也 - Tetsuya', '隆 - Takashi', '裕太 - Yuta', '大介 - Daisuke', '健 - Ken', 
      '洋平 - Yohei', '学 - Manabu', '亮 - Ryo', '雄太 - Yuta', '勇 - Isamu',
      '悟 - Satoru', '聡 - Satoshi', '和夫 - Kazuo', '博 - Hiroshi', '淳 - Jun', 
      '清 - Kiyoshi', '浩 - Hiroshi', '稔 - Minoru', '修 - Osamu', '豊 - Yutaka'
    ],
    girl: [
      // Authentic Japanese girl names with English translations
      '愛 - Ai', '美咲 - Misaki', '彩 - Aya', '優子 - Yuko', '恵 - Megumi', 
      '麻衣 - Mai', '裕子 - Yuko', '香織 - Kaori', '直美 - Naomi', '由美子 - Yumiko',
      '真由美 - Mayumi', '久美子 - Kumiko', '智子 - Tomoko', '洋子 - Yoko', '和子 - Kazuko', 
      '幸子 - Sachiko', '恵子 - Keiko', '美穂 - Miho', '千尋 - Chihiro', '七海 - Nanami',
      '舞 - Mai', '美香 - Mika', '純子 - Junko', '明美 - Akemi', '京子 - Kyoko', 
      '貴子 - Takako', '典子 - Noriko', '千春 - Chiharu', '裕美 - Hiromi', '真理子 - Mariko'
    ],
    neutral: [
      // Gender-neutral or unisex Japanese names with English translations
      '陽 - Yo', '光 - Hikaru', '葵 - Aoi', '薫 - Kaoru', '晴 - Haru', 
      '空 - Sora', '樹 - Itsuki', '海 - Kai', '陸 - Riku', '蓮 - Ren',
      '翼 - Tsubasa', '朝 - Asa', '風 - Kaze', '月 - Tsuki', '雪 - Yuki', 
      '花 - Hana', '虹 - Niji', '星 - Hoshi', '夏 - Natsu', '春 - Haru'
    ]
  },
  chinese: {
    boy: [
      // Authentic Chinese boy names with English translations
      '李明 - Li Ming', '王强 - Wang Qiang', '张伟 - Zhang Wei', '刘洋 - Liu Yang', '陈刚 - Chen Gang', 
      '杨勇 - Yang Yong', '赵亮 - Zhao Liang', '吴鹏 - Wu Peng', '孙杰 - Sun Jie', '周涛 - Zhou Tao',
      '徐超 - Xu Chao', '朱峰 - Zhu Feng', '胡军 - Hu Jun', '郭涛 - Guo Tao', '何强 - He Qiang', 
      '马超 - Ma Chao', '林峰 - Lin Feng', '罗强 - Luo Qiang', '宋杰 - Song Jie', '郑伟 - Zheng Wei',
      '唐军 - Tang Jun', '冯刚 - Feng Gang', '于涛 - Yu Tao', '曹勇 - Cao Yong', '袁鹏 - Yuan Peng', 
      '许杰 - Xu Jie', '邓超 - Deng Chao', '萧峰 - Xiao Feng', '严俊 - Yan Jun', '韩磊 - Han Lei'
    ],
    girl: [
      // Authentic Chinese girl names with English translations
      '王芳 - Wang Fang', '李娜 - Li Na', '张丽 - Zhang Li', '刘英 - Liu Ying', '陈静 - Chen Jing', 
      '杨洁 - Yang Jie', '赵敏 - Zhao Min', '吴琳 - Wu Lin', '孙燕 - Sun Yan', '周梅 - Zhou Mei',
      '徐静 - Xu Jing', '朱丽 - Zhu Li', '胡敏 - Hu Min', '郭丽 - Guo Li', '何洁 - He Jie', 
      '马丽 - Ma Li', '林娜 - Lin Na', '罗敏 - Luo Min', '宋芳 - Song Fang', '郑洁 - Zheng Jie',
      '唐静 - Tang Jing', '冯敏 - Feng Min', '于丽 - Yu Li', '曹芳 - Cao Fang', '袁洁 - Yuan Jie', 
      '许娜 - Xu Na', '邓丽 - Deng Li', '萧敏 - Xiao Min', '严芳 - Yan Fang', '韩洁 - Han Jie'
    ],
    neutral: [
      // Gender-neutral or unisex Chinese names with English translations
      '李晨 - Li Chen', '王宇 - Wang Yu', '张晓 - Zhang Xiao', '刘阳 - Liu Yang', '陈安 - Chen An', 
      '杨晨 - Yang Chen', '赵阳 - Zhao Yang', '吴晓 - Wu Xiao', '孙宇 - Sun Yu', '周晨 - Zhou Chen',
      '徐阳 - Xu Yang', '朱晓 - Zhu Xiao', '胡宇 - Hu Yu', '郭晨 - Guo Chen', '何阳 - He Yang', 
      '马晓 - Ma Xiao', '林宇 - Lin Yu', '罗晨 - Luo Chen', '宋阳 - Song Yang', '郑晓 - Zheng Xiao'
    ]
  },
  arabic: {
    boy: [
      // Authentic Arabic boy names with English translations
      'محمد - Muhammad', 'أحمد - Ahmad', 'علي - Ali', 'عمر - Omar', 'حسن - Hassan', 
      'حسين - Hussein', 'إبراهيم - Ibrahim', 'يوسف - Yusuf', 'خالد - Khalid', 'عبدالله - Abdullah',
      'عبدالرحمن - Abdulrahman', 'سعيد - Saeed', 'طارق - Tariq', 'جمال - Jamal', 'كريم - Karim', 
      'فهد - Fahad', 'ناصر - Nasser', 'صالح - Saleh', 'هاني - Hani', 'وليد - Waleed',
      'سامي - Sami', 'فيصل - Faisal', 'ماجد - Majid', 'رامي - Rami', 'زياد - Ziyad', 
      'عادل - Adel', 'مصطفى - Mustafa', 'نبيل - Nabil', 'هشام - Hisham', 'بلال - Bilal'
    ],
    girl: [
      // Authentic Arabic girl names with English translations
      'فاطمة - Fatima', 'عائشة - Aisha', 'مريم - Maryam', 'زينب - Zainab', 'نور - Noor', 
      'سارة - Sara', 'هدى - Huda', 'ليلى - Layla', 'سلمى - Salma', 'رنا - Rana',
      'دينا - Dina', 'هناء - Hanaa', 'منى - Mona', 'سمية - Sumaya', 'رانيا - Rania', 
      'جميلة - Jamila', 'أمينة - Amina', 'نادية - Nadia', 'سهام - Siham', 'لينا - Lina',
      'ياسمين - Yasmin', 'هالة - Hala', 'غادة - Ghada', 'سناء - Sanaa', 'نجلاء - Najla', 
      'بشرى - Bushra', 'أمل - Amal', 'سميرة - Samira', 'نجوى - Najwa', 'فريدة - Farida'
    ],
    neutral: [
      // Gender-neutral or unisex Arabic names with English translations
      'نور - Noor', 'سلام - Salam', 'إحسان - Ihsan', 'جهاد - Jihad', 'إيمان - Iman', 
      'هدى - Huda', 'رضا - Rida', 'نعمة - Nima', 'كرم - Karam', 'صفاء - Safaa',
      'نسيم - Nasim', 'فجر - Fajr', 'أمان - Aman', 'بهاء - Bahaa', 'ضياء - Diya', 
      'وفاء - Wafaa', 'هناء - Hanaa', 'رجاء - Rajaa', 'سماح - Samah', 'نبيل - Nabil'
    ]
  }
};

module.exports = authenticNames;
