/**
 * Name Integration Module
 * 
 * This file integrates the authentic names dataset and translation utilities
 * with the main application
 */

const authenticNames = require('./authentic_names');
const nameTranslation = require('./name_translation');
const nameRules = require('./name_rules');

// Function to get names based on type, gender, style, and origin
function getNames(type, gender, style, origin) {
  // Default to expanded names if authentic names not available for the origin
  if (!authenticNames[origin]) {
    console.log(`No authentic names available for origin: ${origin}, using fallback`);
    return [];
  }
  
  // Get names based on gender
  let names = [];
  if (gender && authenticNames[origin][gender]) {
    names = authenticNames[origin][gender];
  } else if (authenticNames[origin]['neutral']) {
    names = authenticNames[origin]['neutral'];
  } else {
    // Fallback to all available names for the origin
    Object.keys(authenticNames[origin]).forEach(g => {
      names = names.concat(authenticNames[origin][g]);
    });
  }
  
  // Apply name rules for filtering and improvement
  names = names.filter(name => {
    // Extract original name for validation
    const originalName = nameTranslation.getOriginalName(name);
    return nameRules.validateName(originalName, type);
  }).map(name => {
    // Format name with translation if needed
    return nameTranslation.formatNameWithTranslation(name);
  });
  
  // Apply style filtering if specified
  if (style && style !== 'any') {
    names = names.filter(name => {
      const originalName = nameTranslation.getOriginalName(name);
      const improvedName = nameRules.improveName(originalName, type, style, origin);
      return improvedName !== ''; // Empty string means it didn't match style criteria
    });
  }
  
  return names;
}

// Function to get all available origins with their translated names
function getAvailableOrigins() {
  return Object.keys(authenticNames).map(origin => {
    return {
      value: origin,
      label: origin.charAt(0).toUpperCase() + origin.slice(1)
    };
  });
}

// Function to process a name for display
function processNameForDisplay(name, includeTranslation = true) {
  if (!includeTranslation) {
    return nameTranslation.getOriginalName(name);
  }
  
  // For non-Latin script names, ensure they have translations
  if (nameTranslation.isNonLatinScript(name)) {
    return nameTranslation.formatNameWithTranslation(name);
  }
  
  return name;
}

// Function to get names for a specific tier
function getNamesForTier(type, gender, style, origin, tier) {
  let names = getNames(type, gender, style, origin);
  
  // Apply tier-based limitations
  const tierLimits = {
    free: 10,
    premium: 25,
    enterprise: 50
  };
  
  const limit = tierLimits[tier] || tierLimits.free;
  
  // Shuffle the names to get a random selection
  names = shuffleArray(names);
  
  // Return limited number of names based on tier
  return names.slice(0, limit);
}

// Helper function to shuffle an array
function shuffleArray(array) {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}

module.exports = {
  getNames,
  getAvailableOrigins,
  processNameForDisplay,
  getNamesForTier
};
