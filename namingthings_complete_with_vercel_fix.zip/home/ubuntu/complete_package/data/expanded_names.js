/**
 * Expanded Names Dataset
 * 
 * This file contains expanded datasets for Nordic and Indian names
 * as well as other origins to enhance the name generation capabilities.
 */

const expandedNames = {
  nordic: {
    boy: [
      // Traditional Nordic/Scandinavian boy names
      'Aksel', 'Anders', 'Arne', 'Arvid', 'Asger', 'Asmund', 'Axel', 'Balder', 'Bjarke', 'Bjorn',
      'Bo', 'Dag', 'Einar', 'Erik', 'Eskil', 'Finn', 'Frode', 'Gunnar', 'Gustav', 'Haakon',
      'Halfdan', 'Harald', 'Ivar', 'Jesper', 'Johan', 'Jorgen', 'Kare', 'Kasper', 'Keld', 'Knud',
      'Leif', 'Loke', 'Magnus', 'Mikkel', 'Morten', 'Njal', 'Olaf', 'Olav', 'Ole', 'Peder',
      'Ragnar', 'Rune', 'Sigurd', 'Skjold', 'Soren', 'Steinar', 'Sven', 'Thor', 'Thorvald', 'Torsten',
      'Trygve', 'Ulf', 'Valdemar', 'Vidar', 'Viggo', 'Viking', 'Yngve',
      
      // Modern Nordic boy names
      'Alvin', 'Anton', 'August', 'Casper', 'Elias', 'Elliot', 'Emil', 'Filip', 'Gustav', 'Hjalmar',
      'Isak', 'Joakim', 'Linus', 'Ludvig', 'Malte', 'Melvin', 'Nils', 'Noel', 'Odin', 'Oskar',
      'Otto', 'Rasmus', 'Sixten', 'Tage', 'Theo', 'Valter', 'Vilgot', 'Vilhelm', 'Vilmer', 'Vincent'
    ],
    girl: [
      // Traditional Nordic/Scandinavian girl names
      'Agneta', 'Astrid', 'Birgitta', 'Bodil', 'Dagmar', 'Dorthe', 'Edda', 'Elin', 'Erika', 'Frida',
      'Freja', 'Gerda', 'Greta', 'Gudrun', 'Gunhild', 'Hanna', 'Hedvig', 'Helga', 'Hilda', 'Idun',
      'Inga', 'Ingrid', 'Karin', 'Kirsten', 'Lena', 'Liv', 'Maja', 'Nanna', 'Ragnhild', 'Signe',
      'Sigrid', 'Siv', 'Solveig', 'Svea', 'Thyra', 'Tora', 'Tove', 'Ulla', 'Ylva', 'Yrsa',
      
      // Modern Nordic girl names
      'Alva', 'Alma', 'Elsa', 'Elvira', 'Embla', 'Ester', 'Filippa', 'Hedda', 'Ines', 'Juni',
      'Klara', 'Leah', 'Lilly', 'Lova', 'Majken', 'Matilda', 'Minna', 'Molly', 'Nora', 'Ronja',
      'Saga', 'Siri', 'Svea', 'Thea', 'Tilda', 'Tuva', 'Tyra', 'Vera', 'Vigdis', 'Wilma'
    ],
    neutral: [
      'Alex', 'Andrea', 'Benny', 'Charlie', 'Eli', 'Ellis', 'Hjalmar', 'Inge', 'Kai', 'Kim',
      'Lo', 'Mika', 'Mio', 'Noa', 'Rene', 'Robin', 'Saga', 'Sasha', 'Tove', 'Vide',
      'Alva', 'Billie', 'Cleo', 'Elliot', 'Emery', 'Frankie', 'Helle', 'Indigo', 'Juno', 'Linden',
      'Lumi', 'Magne', 'Nicke', 'Nova', 'Ode', 'Pim', 'Quinn', 'Rowan', 'Sol', 'Tintin'
    ]
  },
  indian: {
    boy: [
      // North Indian boy names
      'Aarav', 'Advik', 'Advit', 'Agastya', 'Akshay', 'Amrit', 'Anant', 'Anay', 'Angad', 'Anhad',
      'Aniket', 'Anish', 'Ankit', 'Ankur', 'Arnav', 'Arjun', 'Aryan', 'Atharv', 'Ayaan', 'Ayush',
      'Bhavesh', 'Daksh', 'Darsh', 'Dev', 'Dhruv', 'Divij', 'Divyansh', 'Ekansh', 'Gaurav', 'Harsh',
      'Hemant', 'Hridaan', 'Ishaan', 'Jatin', 'Kabir', 'Kalpit', 'Kartik', 'Keshav', 'Krish', 'Krishna',
      'Lakshay', 'Madhav', 'Manan', 'Manav', 'Moksh', 'Naksh', 'Naman', 'Naveen', 'Nihal', 'Nishant',
      
      // South Indian boy names
      'Aadishankar', 'Aadithya', 'Aakarsh', 'Aakash', 'Aanan', 'Aanand', 'Aarush', 'Aathish', 'Abhinav', 'Adhrit',
      'Adithya', 'Advaith', 'Agni', 'Ahaan', 'Akarsh', 'Akhil', 'Akshaj', 'Amrit', 'Anand', 'Anirudh',
      'Arjun', 'Arnav', 'Aryan', 'Atharv', 'Ayush', 'Balan', 'Charan', 'Darshan', 'Deven', 'Dhruv',
      'Gagan', 'Ganesh', 'Gautam', 'Gopal', 'Harish', 'Ishan', 'Jagan', 'Jai', 'Karthik', 'Kiran',
      'Krishna', 'Kumar', 'Lakshman', 'Madhav', 'Mahesh', 'Manish', 'Mohan', 'Nakul', 'Naveen', 'Nikhil',
      
      // Traditional Indian boy names
      'Abhimanyu', 'Aditya', 'Ajay', 'Amit', 'Anil', 'Ashok', 'Balaji', 'Bharat', 'Chandra', 'Deepak',
      'Dinesh', 'Ganesh', 'Gopal', 'Harish', 'Jai', 'Karan', 'Kishore', 'Lalit', 'Manoj', 'Mohan',
      'Mukesh', 'Naresh', 'Nitin', 'Pankaj', 'Prakash', 'Rahul', 'Rajesh', 'Rakesh', 'Ramesh', 'Ravi',
      'Sachin', 'Sanjay', 'Sanjeev', 'Satish', 'Shyam', 'Sudhir', 'Sunil', 'Suresh', 'Vijay', 'Vikram',
      'Vinod', 'Vivek'
    ],
    girl: [
      // North Indian girl names
      'Aadya', 'Aanya', 'Aditi', 'Advika', 'Ahana', 'Akshara', 'Amaya', 'Amrita', 'Ananya', 'Anika',
      'Anushka', 'Anya', 'Aradhya', 'Avni', 'Chhavi', 'Dhriti', 'Diya', 'Divya', 'Drishti', 'Eshika',
      'Geetika', 'Hansika', 'Harshita', 'Ishani', 'Ishita', 'Jhanvi', 'Jiya', 'Kashvi', 'Kavya', 'Khushi',
      'Kiara', 'Krisha', 'Kritika', 'Kyra', 'Lakshmi', 'Mahika', 'Mannat', 'Meera', 'Mira', 'Mishka',
      'Myra', 'Naina', 'Navya', 'Naysa', 'Nidhi', 'Nisha', 'Nitya', 'Ojaswi', 'Pari', 'Pihu',
      
      // South Indian girl names
      'Aadya', 'Aaradhya', 'Aarna', 'Aditi', 'Advika', 'Ahana', 'Akshara', 'Amrita', 'Ananya', 'Anushka',
      'Aparna', 'Avantika', 'Avni', 'Bhavana', 'Chaaya', 'Deepika', 'Devi', 'Dhanya', 'Divya', 'Esha',
      'Ganga', 'Gayatri', 'Gowri', 'Hema', 'Indira', 'Jaya', 'Kalpana', 'Kamala', 'Kaveri', 'Keerthi',
      'Lakshmi', 'Lalitha', 'Lavanya', 'Madhavi', 'Mahi', 'Malini', 'Meena', 'Nandini', 'Padma', 'Pallavi',
      'Pooja', 'Priya', 'Radha', 'Ramya', 'Rani', 'Riya', 'Saanvi', 'Sahana', 'Sarika', 'Shanti',
      
      // Traditional Indian girl names
      'Aarti', 'Anjali', 'Anita', 'Asha', 'Chitra', 'Deepa', 'Geeta', 'Jyoti', 'Kalpana', 'Kamala',
      'Kiran', 'Lata', 'Laxmi', 'Leela', 'Madhu', 'Mamta', 'Manisha', 'Maya', 'Meena', 'Neha',
      'Nirmala', 'Padma', 'Poonam', 'Priya', 'Radha', 'Rajni', 'Rekha', 'Rita', 'Sangeeta', 'Sapna',
      'Sarita', 'Savita', 'Seema', 'Shobha', 'Sita', 'Suman', 'Sunita', 'Uma', 'Usha', 'Vandana'
    ],
    neutral: [
      'Akash', 'Anand', 'Chaman', 'Gyan', 'Indra', 'Jeet', 'Jivan', 'Jyoti', 'Kamal', 'Kiran',
      'Mani', 'Manju', 'Noor', 'Om', 'Prem', 'Raj', 'Roop', 'Santosh', 'Shanti', 'Suman',
      'Swapnil', 'Tarun', 'Tej', 'Trishna', 'Vimal'
    ]
  }
};

module.exports = expandedNames;
