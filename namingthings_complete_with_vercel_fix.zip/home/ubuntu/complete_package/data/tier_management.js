/**
 * Tier Management Module
 * 
 * This file contains functionality for managing different subscription tiers
 * and enforcing tier-based limitations
 */

// Define tier levels and their features
const tiers = {
  free: {
    name: 'Free',
    price: 0,
    nameLimit: 10,
    characterLimit: 500,
    requestsPerDay: 5,
    features: [
      'AI-powered suggestions',
      'Developer & Personal naming',
      'Basic name options'
    ]
  },
  premium: {
    name: 'Premium',
    price: 5,
    nameLimit: 25,
    characterLimit: 2000,
    requestsPerDay: Infinity,
    features: [
      'Enhanced AI suggestions',
      'Advanced naming options',
      'Priority support',
      'No daily request limit',
      'Expanded character limit'
    ]
  },
  enterprise: {
    name: 'Enterprise',
    price: 15,
    nameLimit: 50,
    characterLimit: 5000,
    requestsPerDay: Infinity,
    features: [
      'Premium AI models',
      'API access',
      'Custom integration',
      'Dedicated support',
      'Maximum name suggestions',
      'Highest character limit'
    ]
  }
};

// Function to get tier details
function getTierDetails(tierName) {
  return tiers[tierName] || tiers.free;
}

// Function to check if a feature is available for a tier
function isFeatureAvailable(tierName, featureName) {
  const tier = getTierDetails(tierName);
  
  switch (featureName) {
    case 'nameLimit':
    case 'characterLimit':
    case 'requestsPerDay':
      return tier[featureName];
    default:
      return tier.features.includes(featureName);
  }
}

// Function to enforce character limit based on tier
function enforceCharacterLimit(input, tierName) {
  const tier = getTierDetails(tierName);
  return input.length <= tier.characterLimit;
}

// Function to enforce name suggestion limit based on tier
function enforceNameLimit(tierName) {
  const tier = getTierDetails(tierName);
  return tier.nameLimit;
}

// Function to enforce daily request limit based on tier
function enforceRequestLimit(requestCount, tierName) {
  const tier = getTierDetails(tierName);
  return requestCount <= tier.requestsPerDay;
}

// Function to get all available tiers
function getAllTiers() {
  return Object.keys(tiers).map(key => ({
    id: key,
    ...tiers[key]
  }));
}

module.exports = {
  getTierDetails,
  isFeatureAvailable,
  enforceCharacterLimit,
  enforceNameLimit,
  enforceRequestLimit,
  getAllTiers
};
