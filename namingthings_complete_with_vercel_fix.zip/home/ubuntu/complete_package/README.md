# Naming Things - Improved

A comprehensive tool for generating names for developers (functions, methods, variables) and personal use (babies, pets) with AI assistance.

## New Features and Improvements

This improved version includes several enhancements:

1. **Authentic Native Names**: Added comprehensive collections of authentic native names for various cultures:
   - Nordic, Italian, German, Greek, Hebrew, African, Indian names
   - Japanese, Chinese, and Arabic names with English translations

2. **Name Translation**: Non-Latin script names (Japanese, Chinese, Arabic) now include English translations displayed with hyphens.

3. **Tier-Based Features**: Properly implemented and enforced rules for different subscription tiers:
   - Free: 10 name suggestions, 500 character limit, 5 requests per day
   - Premium: 25 name suggestions, 2000 character limit, unlimited requests
   - Enterprise: 50 name suggestions, 5000 character limit, unlimited requests, API access

4. **User Authentication**: Complete login and registration system to track user accounts and their subscription tiers.

5. **Google Login Integration**: Easy sign-in with Google accounts.

6. **Stripe Payment Integration**: Secure payment processing for premium and enterprise subscriptions.

7. **UI Improvements**: Fixed tier selection display issues and improved overall user experience.

8. **Feedback System**: Added rating system for generated names to improve future suggestions.

## Installation

1. Clone the repository:
```
git clone https://github.com/yourusername/naming-things-improved.git
cd naming-things-improved
```

2. Install dependencies:
```
npm install
```

3. Create a `.env` file based on `.env.example`:
```
cp .env.example .env
```

4. Edit the `.env` file to add your API keys:
```
# AI Model Configuration
MODEL_MODE=local  # 'local', 'openai', or 'hybrid'
OPENAI_API_KEY=your_openai_api_key
OPENAI_MODEL=gpt-4  # or gpt-3.5-turbo
LOCAL_MODEL_PATH=./models

# Authentication
SESSION_SECRET=your_session_secret

# Google OAuth
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret

# Stripe Payment
STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
STRIPE_SECRET_KEY=your_stripe_secret_key
```

5. Download the local AI model (if using local mode):
```
npm run download-models
```

6. Start the server:
```
npm start
```

7. Access the application at http://localhost:3000

## Usage

### Developer Name Generator

1. Select the "Developer Tool" tab
2. Choose between "Description" or "Code" input type
3. Enter a description of the function/method or paste code snippet
4. Click "Generate Names"
5. Rate the generated names to help improve future suggestions

### Personal Name Generator

1. Select the "Personal Names" tab
2. Choose the type (Baby, Pet)
3. Select gender (Boy, Girl, Neutral)
4. Choose origin (e.g., Nordic, Italian, Japanese)
5. Click "Generate Names"
6. Rate the generated names to help improve future suggestions

### Authentication

1. Register a new account or log in with existing credentials
2. Alternatively, use the "Sign in with Google" button for quick access
3. View your current subscription tier in your profile

### Subscription Management

1. Navigate to the pricing page
2. Select a subscription tier (Free, Premium, Enterprise)
3. Complete the payment process for premium tiers
4. Manage your subscription from your profile page

## API Documentation

### Authentication Endpoints

- `POST /api/auth/register`: Register a new user
- `POST /api/auth/login`: Log in an existing user
- `POST /api/auth/google`: Authenticate with Google
- `POST /api/auth/logout`: Log out the current user
- `GET /api/auth/profile`: Get the current user's profile
- `GET /api/auth/subscription`: Get subscription details
- `POST /api/auth/cancel-subscription`: Cancel a subscription

### Name Generation Endpoints

- `POST /api/generate-names`: Generate name suggestions
- `POST /api/feedback`: Submit feedback for generated names

## Technologies Used

- **Frontend**: HTML, CSS, JavaScript
- **Backend**: Node.js, Express
- **AI**: Local model (distilgpt2) and/or OpenAI API
- **Authentication**: Custom JWT implementation, Google OAuth
- **Payment Processing**: Stripe

## License

MIT

## Credits

Created by [Your Name]
