// Load environment variables first, before any other code
require('dotenv').config();

// Set defaults for all required environment variables
process.env.NODE_ENV = process.env.NODE_ENV || 'development';
process.env.MODEL_MODE = process.env.MODEL_MODE || 'local';
process.env.OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-3.5-turbo';
process.env.PORT = process.env.PORT || 3000;

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const session = require('express-session');
const FileStore = require('session-file-store')(session);

// Import rate limiters from middleware module
const { apiLimiter, speedLimiter, bruteForceProtection } = require('./middleware/rateLimit');

// Create logs directory if it doesn't exist
const logsDir = path.join(__dirname, 'logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

// Create log file stream
const logStream = fs.createWriteStream(path.join(logsDir, 'server.log'), { flags: 'a' });

// Helper function to log messages to both console and file
function logMessage(message) {
  const timestamp = new Date().toISOString();
  const logEntry = `[${timestamp}] ${message}`;
  console.log(logEntry);
  logStream.write(logEntry + '\n');
}

// Log environment variables (without sensitive data)
logMessage(`Environment variables loaded: {
  NODE_ENV: ${process.env.NODE_ENV},
  MODEL_MODE: ${process.env.MODEL_MODE},
  OPENAI_MODEL: ${process.env.OPENAI_MODEL},
  OPENAI_API_KEY_EXISTS: ${process.env.OPENAI_API_KEY ? true : false},
  PORT: ${process.env.PORT}
}`);

// Import services
const OpenAIService = require('./services/openaiService');
const EnhancedOpenAIService = require('./services/enhancedOpenAIService');
const LocalAIService = require('./services/localAIService');

// Create server function
function createServer() {
  const app = express();
  
  // Configure session middleware
  const sessionOptions = {
    store: new FileStore({
      path: path.join(__dirname, 'sessions'),
      ttl: 86400, // 1 day
      retries: 0
    }),
    secret: process.env.SESSION_SECRET || 'naming-things-is-hard',
    resave: false,
    saveUninitialized: true,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      maxAge: 24 * 60 * 60 * 1000 // 1 day
    }
  };
  
  app.use(session(sessionOptions));
  
  // Configure middleware
  app.use(cors());
  app.use(bodyParser.json());
  app.use(express.static(path.join(__dirname, 'public')));
  
  // Initialize services
  let openaiService, enhancedOpenAIService, localAIService;
  
  try {
    openaiService = new OpenAIService(process.env.OPENAI_API_KEY);
    enhancedOpenAIService = new EnhancedOpenAIService(process.env.OPENAI_API_KEY);
    localAIService = new LocalAIService('./models');
    
    // Initialize local AI model
    localAIService.initializeModel().catch(err => {
      logMessage(`Error initializing local AI model: ${err.message}`);
    });
  } catch (error) {
    logMessage(`Error initializing services: ${error.message}`);
  }
  
  // Apply rate limiting and throttling to API endpoints
  app.use('/api/', bruteForceProtection); // Apply brute force protection to all API endpoints
  app.use('/api/generate-names', speedLimiter, apiLimiter); // Apply both speed limiter and rate limiter
  app.use('/api/generate-personal-names', speedLimiter, apiLimiter); // Apply both speed limiter and rate limiter
  
  // API routes
  app.get('/api/model-status', async (req, res) => {
    try {
      const openaiStatus = await openaiService.checkStatus();
      const enhancedStatus = await enhancedOpenAIService.checkStatus();
      const localStatus = await localAIService.checkStatus();
      
      const mode = process.env.MODEL_MODE || 'local';
      
      res.json({
        openaiAvailable: openaiStatus.available,
        enhancedAvailable: enhancedStatus.available,
        localAvailable: localStatus.available,
        mode: mode
      });
    } catch (error) {
      logMessage(`Error checking model status: ${error.message}`);
      res.status(500).json({ error: 'Failed to check model status' });
    }
  });
  
  app.post('/api/generate-names', async (req, res) => {
    try {
      // Log the request
      logMessage(`Received request to generate names: ${JSON.stringify(req.body)}`);
      
      // Validate input
      const { input, type, isPremium } = req.body;
      if (!input || !type) {
        logMessage(`Error: Invalid input parameters: ${JSON.stringify(req.body)}`);
        return res.status(400).json({ error: 'Invalid input parameters' });
      }
      
      // Determine number of suggestions based on tier
      const numSuggestions = isPremium ? 25 : 10;
      logMessage(`Generating ${numSuggestions} name suggestions for ${type}`);
      
      // Generate names based on model mode
      let names = [];
      const mode = process.env.MODEL_MODE || 'local';
      
      if (mode === 'openai' && openaiService) {
        logMessage(`Using OpenAI service to generate names for: "${input}"`);
        names = await openaiService.generateNames(input, type, numSuggestions);
        logMessage(`Successfully generated ${names.length} names using OpenAI`);
      } else if (mode === 'enhanced' && enhancedOpenAIService) {
        logMessage(`Using Enhanced OpenAI service to generate names for: "${input}"`);
        names = await enhancedOpenAIService.generateNames(input, type, numSuggestions);
        logMessage(`Successfully generated ${names.length} names using Enhanced OpenAI`);
      } else if (localAIService) {
        logMessage(`Using Local AI service to generate names for: "${input}"`);
        names = await localAIService.generateNames(input, type, numSuggestions);
        logMessage(`Successfully generated ${names.length} names using Local AI`);
      } else {
        // Fallback to dummy names if no service is available
        logMessage('No AI service available, using fallback names');
        names = Array.from({ length: numSuggestions }, (_, i) => `function${i + 1}`);
      }
      
      // Log the generated names
      logMessage(`Generated names: ${JSON.stringify(names)}`);
      
      // Return the names
      res.json({ names });
    } catch (error) {
      logMessage(`Error generating names: ${error.message}`);
      // Return fallback names in case of error
      const fallbackNames = Array.from({ length: 10 }, (_, i) => `function${i + 1}`);
      res.json({ names: fallbackNames });
    }
  });
  
  app.post('/api/generate-personal-names', async (req, res) => {
    try {
      // Log the request
      logMessage(`Received request to generate personal names: ${JSON.stringify(req.body)}`);
      
      // Validate input
      const { type, options, isPremium } = req.body;
      if (!type || !options) {
        logMessage(`Error: Invalid personal name type: ${type}`);
        return res.status(400).json({ error: 'Invalid input parameters' });
      }
      
      // Determine number of suggestions based on tier
      const numSuggestions = isPremium ? 25 : 10;
      logMessage(`Generating ${numSuggestions} ${type} name suggestions`);
      
      // Generate names based on model mode
      let names = [];
      const mode = process.env.MODEL_MODE || 'local';
      
      if (mode === 'openai' && openaiService) {
        logMessage(`Using OpenAI service to generate ${type} names with options: ${JSON.stringify(options)}`);
        names = await openaiService.generatePersonalNames(type, options, numSuggestions);
        logMessage(`Successfully generated ${names.length} ${type} names using OpenAI`);
      } else if (mode === 'enhanced' && enhancedOpenAIService) {
        logMessage(`Using Enhanced OpenAI service to generate ${type} names with options: ${JSON.stringify(options)}`);
        names = await enhancedOpenAIService.generatePersonalNames(type, options, numSuggestions);
        logMessage(`Successfully generated ${names.length} ${type} names using Enhanced OpenAI`);
      } else if (localAIService) {
        logMessage(`Using Local AI service to generate ${type} names with options: ${JSON.stringify(options)}`);
        names = await localAIService.generatePersonalNames(type, options, numSuggestions);
        logMessage(`Successfully generated ${names.length} ${type} names using Local AI`);
      } else {
        // Fallback to dummy names if no service is available
        logMessage('No AI service available, using fallback names');
        names = Array.from({ length: numSuggestions }, (_, i) => `Name${i + 1}`);
      }
      
      // Log the generated names
      logMessage(`Generated ${type} names: ${JSON.stringify(names)}`);
      
      // Return the names
      res.json({ names });
    } catch (error) {
      logMessage(`Error generating personal names: ${error.message}`);
      // Return fallback names in case of error
      const fallbackNames = Array.from({ length: 10 }, (_, i) => `Name${i + 1}`);
      res.json({ names: fallbackNames });
    }
  });
  
  // Serve index.html for all other routes
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  });
  
  return app;
}

// Start server if this file is run directly
if (require.main === module) {
  const app = createServer();
  const PORT = process.env.PORT || 3000;
  
  app.listen(PORT, () => {
    logMessage(`Server running on port ${PORT} in ${process.env.NODE_ENV} mode`);
    logMessage(`Model mode: ${process.env.MODEL_MODE || 'local'}`);
  });
}

module.exports = createServer;
