const fs = require('fs');
const path = require('path');
const https = require('https');
const { promisify } = require('util');

// Configuration
const MODEL_NAME = 'Xenova/distilgpt2';
const MODEL_FILES = [
  'config.json',
  'tokenizer.json',
  'tokenizer_config.json',
  'vocab.json',
  'pytorch_model.bin',
  'merges.txt'
];
const MODEL_DIR = path.join(__dirname, '..', 'models', MODEL_NAME.split('/')[1]);

// Create model directory if it doesn't exist
function createModelDirectory() {
  const dirs = MODEL_DIR.split(path.sep);
  let currentDir = '';
  
  for (const dir of dirs) {
    if (!dir) continue;
    currentDir = currentDir ? path.join(currentDir, dir) : dir;
    
    if (!fs.existsSync(currentDir)) {
      fs.mkdirSync(currentDir);
      console.log(`Created directory: ${currentDir}`);
    }
  }
}

// Download a file from a URL using https module instead of fetch
function downloadFile(url, outputPath) {
  return new Promise((resolve, reject) => {
    console.log(`Downloading ${url} to ${outputPath}...`);
    
    const file = fs.createWriteStream(outputPath);
    
    https.get(url, (response) => {
      if (response.statusCode !== 200) {
        reject(new Error(`Failed to download ${url}: HTTP status code ${response.statusCode}`));
        return;
      }
      
      response.pipe(file);
      
      file.on('finish', () => {
        file.close();
        console.log(`Downloaded ${url} to ${outputPath}`);
        resolve();
      });
    }).on('error', (err) => {
      fs.unlink(outputPath, () => {}); // Delete the file if there was an error
      reject(err);
    });
    
    file.on('error', (err) => {
      fs.unlink(outputPath, () => {}); // Delete the file if there was an error
      reject(err);
    });
  });
}

// Main function to download all model files
async function downloadModel() {
  try {
    console.log(`Starting download of ${MODEL_NAME} model files...`);
    
    // Create model directory
    createModelDirectory();
    
    // Download each model file
    for (const file of MODEL_FILES) {
      const url = `https://huggingface.co/${MODEL_NAME}/resolve/main/${file}`;
      const outputPath = path.join(MODEL_DIR, file);
      
      // Skip if file already exists
      if (fs.existsSync(outputPath)) {
        console.log(`File ${file} already exists, skipping download.`);
        continue;
      }
      
      await downloadFile(url, outputPath);
    }
    
    console.log(`Successfully downloaded all model files for ${MODEL_NAME}`);
  } catch (error) {
    console.error('Error downloading model:', error);
    process.exit(1);
  }
}

// Run the download
downloadModel();
