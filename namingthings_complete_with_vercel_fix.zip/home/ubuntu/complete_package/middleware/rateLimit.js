/**
 * Rate limiting middleware for the naming application
 * Provides protection against abuse while allowing legitimate users to access the service
 */

const rateLimit = require('express-rate-limit');
const slowDown = require('express-slow-down');

/**
 * Helper function to generate a consistent key for rate limiting
 * Uses user ID if available, otherwise falls back to IP address
 */
function generateKey(req) {
  // Use user ID if authenticated, otherwise use IP
  return req.session && req.session.userId ? 
    `user:${req.session.userId}` : 
    req.ip;
}

/**
 * Helper function to determine if rate limiting should be skipped
 * Premium users are exempt from the free tier rate limits
 */
function shouldSkip(req) {
  // Skip rate limiting for premium users
  return req.body && req.body.isPremium === true;
}

// Create API rate limiter - 5 requests per day for free tier
const apiLimiter = rateLimit({
  windowMs: 24 * 60 * 60 * 1000, // 24 hours
  max: 5, // 5 requests per window
  standardHeaders: true,
  legacyHeaders: false,
  message: { 
    error: 'Daily limit reached for free tier. Please upgrade to premium for unlimited requests.',
    upgrade: true
  },
  keyGenerator: generateKey,
  skip: shouldSkip,
  handler: (req, res, next, options) => {
    console.log(`[${new Date().toISOString()}] Rate limit exceeded for ${generateKey(req)}`);
    res.status(429).json(options.message);
  }
});

// Create speed limiter - gradually slows down responses after 3 requests
const speedLimiter = slowDown({
  windowMs: 15 * 60 * 1000, // 15 minutes
  delayAfter: 3, // allow 3 requests per 15 minutes, then...
  // Fix for the delayMs warning - use the new behavior
  delayMs: () => 500, // fixed 500ms delay per request
  maxDelayMs: 2000, // maximum delay is 2 seconds
  keyGenerator: generateKey,
  skip: shouldSkip,
  // Add validation to suppress warning
  validate: {
    delayMs: false
  }
});

// Create brute force protection - 20 requests per minute for all users
const bruteForceProtection = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 20, // 20 requests per minute
  standardHeaders: true,
  legacyHeaders: false,
  message: { 
    error: 'Too many requests, please try again later',
    upgrade: false
  },
  keyGenerator: (req) => req.ip, // Always use IP for brute force protection
  skip: (req) => false, // Don't skip anyone for brute force protection
  handler: (req, res, next, options) => {
    console.log(`[${new Date().toISOString()}] Brute force protection triggered for ${req.ip}`);
    res.status(429).json(options.message);
  }
});

module.exports = {
  apiLimiter,
  speedLimiter,
  bruteForceProtection,
  generateKey,
  shouldSkip
};
