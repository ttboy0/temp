/**
 * Server API Routes for Authentication and Payments
 * 
 * This file contains Express routes for handling user authentication,
 * tier management, and payment processing
 */

const express = require('express');
const router = express.Router();
const userAuth = require('../data/user_authentication');
const tierManagement = require('../data/tier_management');
const paymentIntegration = require('../data/payment_integration');

// Middleware to check if user is authenticated
function requireAuth(req, res, next) {
  const sessionId = req.headers.authorization;
  
  if (!sessionId) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  
  const sessionResult = userAuth.validateSession(sessionId);
  
  if (!sessionResult.valid) {
    return res.status(401).json({ error: sessionResult.message });
  }
  
  // Add user to request object
  req.user = sessionResult.user;
  next();
}

// Register a new user
router.post('/register', (req, res) => {
  const { email, password, name } = req.body;
  
  if (!email || !password || !name) {
    return res.status(400).json({ error: 'Email, password, and name are required' });
  }
  
  const result = userAuth.registerUser(email, password, name);
  
  if (!result.success) {
    return res.status(400).json({ error: result.message });
  }
  
  res.json({ message: result.message, userId: result.userId });
});

// Login user
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }
  
  const result = userAuth.loginUser(email, password);
  
  if (!result.success) {
    return res.status(401).json({ error: result.message });
  }
  
  res.json({
    message: result.message,
    sessionId: result.sessionId,
    user: result.user
  });
});

// Google authentication
router.post('/auth/google', (req, res) => {
  const { googleUserData } = req.body;
  
  if (!googleUserData || !googleUserData.email) {
    return res.status(400).json({ error: 'Invalid Google user data' });
  }
  
  const result = userAuth.googleAuth(googleUserData);
  
  res.json({
    message: result.message,
    sessionId: result.sessionId,
    user: result.user
  });
});

// Logout user
router.post('/logout', (req, res) => {
  const sessionId = req.headers.authorization;
  
  if (!sessionId) {
    return res.status(400).json({ error: 'Session ID is required' });
  }
  
  const result = userAuth.logoutUser(sessionId);
  
  res.json({ message: result.message });
});

// Get current user profile
router.get('/profile', requireAuth, (req, res) => {
  // User is already attached to req by middleware
  res.json({
    user: req.user,
    tierDetails: tierManagement.getTierDetails(req.user.tier)
  });
});

// Create Stripe checkout session
router.post('/create-checkout-session', requireAuth, (req, res) => {
  const { tierName } = req.body;
  const userId = req.user.id;
  
  if (!tierName || !['premium', 'enterprise'].includes(tierName)) {
    return res.status(400).json({ error: 'Valid tier name is required' });
  }
  
  // Create success and cancel URLs
  const successUrl = `${req.headers.origin}/payment-success?session_id={CHECKOUT_SESSION_ID}`;
  const cancelUrl = `${req.headers.origin}/payment-cancel`;
  
  const result = paymentIntegration.createCheckoutSession(
    tierName,
    userId,
    successUrl,
    cancelUrl
  );
  
  if (!result.success) {
    return res.status(400).json({ error: result.message });
  }
  
  res.json(result);
});

// Stripe webhook handler
router.post('/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const event = req.body;
  
  // Handle the event
  const result = paymentIntegration.handleStripeWebhook(event);
  
  if (result.success && result.userId) {
    // Update user tier
    userAuth.updateUserTier(result.userId, result.tierName);
  }
  
  res.json({ received: true });
});

// Get user subscription details
router.get('/subscription', requireAuth, (req, res) => {
  const userId = req.user.id;
  
  const result = paymentIntegration.getUserSubscription(userId);
  
  if (!result.success) {
    return res.status(400).json({ error: result.message });
  }
  
  res.json(result);
});

// Cancel subscription
router.post('/cancel-subscription', requireAuth, (req, res) => {
  const { subscriptionId } = req.body;
  
  if (!subscriptionId) {
    return res.status(400).json({ error: 'Subscription ID is required' });
  }
  
  const result = paymentIntegration.cancelSubscription(subscriptionId);
  
  if (!result.success) {
    return res.status(400).json({ error: result.message });
  }
  
  // Update user tier to free
  userAuth.updateUserTier(req.user.id, 'free');
  
  res.json(result);
});

// Get all available tiers
router.get('/tiers', (req, res) => {
  const tiers = tierManagement.getAllTiers();
  res.json({ tiers });
});

module.exports = router;
