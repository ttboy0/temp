/**
 * Google Login Integration Test
 * 
 * This file contains tests for the Google login integration
 */

const { test, expect } = require('@playwright/test');
const userAuth = require('../data/user_authentication');

test.describe('Google Login Integration', () => {
  test('should authenticate with Google', async () => {
    // Mock Google user data
    const googleUserData = {
      googleId: `google_${Date.now()}`,
      email: `google_user_${Date.now()}@example.com`,
      name: 'Google Test User',
      imageUrl: 'https://example.com/profile.jpg'
    };
    
    // Authenticate with Google
    const result = userAuth.googleAuth(googleUserData);
    
    // Verify result
    expect(result.success).toBe(true);
    expect(result.message).toContain('Google authentication successful');
    expect(result.sessionId).toBeDefined();
    expect(result.user).toBeDefined();
    expect(result.user.email).toBe(googleUserData.email);
    expect(result.user.name).toBe(googleUserData.name);
    expect(result.user.tier).toBe('free'); // Default tier
  });
  
  test('should create new account for first-time Google users', async () => {
    // Generate unique email for this test
    const email = `new_google_user_${Date.now()}@example.com`;
    
    // Mock Google user data for new user
    const googleUserData = {
      googleId: `google_new_${Date.now()}`,
      email: email,
      name: 'New Google User',
      imageUrl: 'https://example.com/new_profile.jpg'
    };
    
    // Authenticate with Google
    const result = userAuth.googleAuth(googleUserData);
    
    // Verify result
    expect(result.success).toBe(true);
    expect(result.user.email).toBe(email);
    
    // Verify session is valid
    const sessionResult = userAuth.validateSession(result.sessionId);
    expect(sessionResult.valid).toBe(true);
    expect(sessionResult.user.email).toBe(email);
  });
  
  test('should link Google account to existing user', async () => {
    // Create a regular user first
    const email = `existing_user_${Date.now()}@example.com`;
    const password = 'password123';
    const name = 'Existing User';
    
    const registerResult = userAuth.registerUser(email, password, name);
    expect(registerResult.success).toBe(true);
    
    // Now authenticate with Google using same email
    const googleUserData = {
      googleId: `google_existing_${Date.now()}`,
      email: email,
      name: name,
      imageUrl: 'https://example.com/existing_profile.jpg'
    };
    
    const googleResult = userAuth.googleAuth(googleUserData);
    
    // Verify result
    expect(googleResult.success).toBe(true);
    expect(googleResult.user.email).toBe(email);
    
    // User should still be able to login with password
    const loginResult = userAuth.loginUser(email, password);
    expect(loginResult.success).toBe(true);
  });
  
  test('should logout Google user correctly', async () => {
    // Mock Google user data
    const googleUserData = {
      googleId: `google_logout_${Date.now()}`,
      email: `google_logout_${Date.now()}@example.com`,
      name: 'Google Logout User',
      imageUrl: 'https://example.com/logout_profile.jpg'
    };
    
    // Authenticate with Google
    const authResult = userAuth.googleAuth(googleUserData);
    expect(authResult.success).toBe(true);
    
    // Logout
    const logoutResult = userAuth.logoutUser(authResult.sessionId);
    expect(logoutResult.success).toBe(true);
    expect(logoutResult.message).toContain('Logout successful');
    
    // Session should be invalid after logout
    const sessionResult = userAuth.validateSession(authResult.sessionId);
    expect(sessionResult.valid).toBe(false);
  });
});
