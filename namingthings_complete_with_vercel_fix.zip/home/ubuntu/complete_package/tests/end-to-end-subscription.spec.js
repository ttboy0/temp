/**
 * End-to-End Subscription Plan Test
 * 
 * This file contains end-to-end tests for user signup for each subscription plan
 */

const { test, expect } = require('@playwright/test');

// Test data
const testUsers = {
  free: {
    email: `free_plan_${Date.now()}@example.com`,
    password: 'password123',
    name: 'Free Plan User'
  },
  premium: {
    email: `premium_plan_${Date.now()}@example.com`,
    password: 'password123',
    name: 'Premium Plan User'
  },
  enterprise: {
    email: `enterprise_plan_${Date.now()}@example.com`,
    password: 'password123',
    name: 'Enterprise Plan User'
  }
};

test.describe('End-to-End Subscription Plan Tests', () => {
  // Setup for each test
  test.beforeEach(async ({ page }) => {
    // Navigate to home page
    await page.goto('http://localhost:3000');
  });

  test('should sign up for free plan and verify features', async ({ page }) => {
    // Click register button
    await page.click('a[href="/register"]');
    
    // Fill registration form
    await page.fill('#register-name', testUsers.free.name);
    await page.fill('#register-email', testUsers.free.email);
    await page.fill('#register-password', testUsers.free.password);
    await page.fill('#register-confirm-password', testUsers.free.password);
    
    // Submit form
    await page.click('button[type="submit"]');
    
    // Wait for registration to complete and redirect to login
    await page.waitForURL('**/login*');
    
    // Login with new account
    await page.fill('#login-email', testUsers.free.email);
    await page.fill('#login-password', testUsers.free.password);
    await page.click('button[type="submit"]');
    
    // Wait for login to complete and redirect to home
    await page.waitForURL('**/');
    
    // Verify user is logged in with free plan
    const userNavName = await page.textContent('#user-nav-name');
    expect(userNavName).toBe(testUsers.free.name);
    
    // Navigate to profile page
    await page.click('#user-nav-name');
    await page.click('a[href="/profile"]');
    
    // Verify user tier is Free
    const userTier = await page.textContent('#user-tier');
    expect(userTier).toContain('Free');
    
    // Test free plan limitations
    // Navigate to developer tool
    await page.click('a[href="/"]');
    await page.click('#developer-tab');
    
    // Enter description
    await page.fill('#input-text', 'A function that calculates the total price including tax');
    await page.click('#generate-btn');
    
    // Verify number of suggestions (should be 10 for free plan)
    const suggestions = await page.$$('.name-suggestion');
    expect(suggestions.length).toBeLessThanOrEqual(10);
  });

  test('should sign up and upgrade to premium plan', async ({ page }) => {
    // Register new user
    await page.click('a[href="/register"]');
    await page.fill('#register-name', testUsers.premium.name);
    await page.fill('#register-email', testUsers.premium.email);
    await page.fill('#register-password', testUsers.premium.password);
    await page.fill('#register-confirm-password', testUsers.premium.password);
    await page.click('button[type="submit"]');
    
    // Login
    await page.waitForURL('**/login*');
    await page.fill('#login-email', testUsers.premium.email);
    await page.fill('#login-password', testUsers.premium.password);
    await page.click('button[type="submit"]');
    
    // Navigate to pricing page
    await page.waitForURL('**/');
    await page.click('a[href="/pricing"]');
    
    // Select premium plan
    await page.click('.pricing-plan[data-tier="premium"] .btn');
    
    // Mock Stripe checkout
    // In a real test, we would interact with Stripe Elements
    // Here we'll mock the successful payment callback
    
    // Mock successful payment by directly calling the success callback
    await page.evaluate(() => {
      // Create a mock session ID
      const mockSessionId = 'cs_test_' + Math.random().toString(36).substr(2, 9);
      
      // Simulate redirect from Stripe with session ID
      window.location.href = '/payment-success?session_id=' + mockSessionId;
    });
    
    // Wait for success page
    await page.waitForSelector('.payment-success');
    
    // Verify success message
    const successMessage = await page.textContent('.payment-success h2');
    expect(successMessage).toContain('Payment Successful');
    
    // Navigate to profile
    await page.click('.payment-success .btn');
    await page.click('#user-nav-name');
    await page.click('a[href="/profile"]');
    
    // Verify user tier is Premium
    const userTier = await page.textContent('#user-tier');
    expect(userTier).toContain('Premium');
    
    // Test premium plan features
    // Navigate to developer tool
    await page.click('a[href="/"]');
    await page.click('#developer-tab');
    
    // Enter longer description (premium allows more characters)
    const longDescription = 'A'.repeat(1500);
    await page.fill('#input-text', longDescription);
    await page.click('#generate-btn');
    
    // Verify number of suggestions (should be 25 for premium plan)
    const suggestions = await page.$$('.name-suggestion');
    expect(suggestions.length).toBeGreaterThan(10);
    expect(suggestions.length).toBeLessThanOrEqual(25);
  });

  test('should sign up and upgrade to enterprise plan', async ({ page }) => {
    // Register new user
    await page.click('a[href="/register"]');
    await page.fill('#register-name', testUsers.enterprise.name);
    await page.fill('#register-email', testUsers.enterprise.email);
    await page.fill('#register-password', testUsers.enterprise.password);
    await page.fill('#register-confirm-password', testUsers.enterprise.password);
    await page.click('button[type="submit"]');
    
    // Login
    await page.waitForURL('**/login*');
    await page.fill('#login-email', testUsers.enterprise.email);
    await page.fill('#login-password', testUsers.enterprise.password);
    await page.click('button[type="submit"]');
    
    // Navigate to pricing page
    await page.waitForURL('**/');
    await page.click('a[href="/pricing"]');
    
    // Select enterprise plan
    await page.click('.pricing-plan[data-tier="enterprise"] .btn');
    
    // Mock Stripe checkout
    await page.evaluate(() => {
      // Create a mock session ID
      const mockSessionId = 'cs_test_' + Math.random().toString(36).substr(2, 9);
      
      // Simulate redirect from Stripe with session ID
      window.location.href = '/payment-success?session_id=' + mockSessionId;
    });
    
    // Wait for success page
    await page.waitForSelector('.payment-success');
    
    // Verify success message
    const successMessage = await page.textContent('.payment-success h2');
    expect(successMessage).toContain('Payment Successful');
    
    // Navigate to profile
    await page.click('.payment-success .btn');
    await page.click('#user-nav-name');
    await page.click('a[href="/profile"]');
    
    // Verify user tier is Enterprise
    const userTier = await page.textContent('#user-tier');
    expect(userTier).toContain('Enterprise');
    
    // Test enterprise plan features
    // Navigate to developer tool
    await page.click('a[href="/"]');
    await page.click('#developer-tab');
    
    // Enter very long description (enterprise allows more characters)
    const veryLongDescription = 'A'.repeat(4000);
    await page.fill('#input-text', veryLongDescription);
    await page.click('#generate-btn');
    
    // Verify number of suggestions (should be 50 for enterprise plan)
    const suggestions = await page.$$('.name-suggestion');
    expect(suggestions.length).toBeGreaterThan(25);
    expect(suggestions.length).toBeLessThanOrEqual(50);
  });
});
