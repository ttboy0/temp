/**
 * Authentic Names Test
 * 
 * This file contains tests for the authentic native names feature
 */

const { test, expect } = require('@playwright/test');
const authenticNames = require('../data/authentic_names');

test.describe('Authentic Native Names', () => {
  test('should have all required cultures', async () => {
    const requiredCultures = ['nordic', 'italian', 'german', 'greek', 'hebrew', 'african', 'indian', 'japanese', 'chinese', 'arabic'];
    
    for (const culture of requiredCultures) {
      expect(authenticNames[culture]).toBeDefined();
      expect(authenticNames[culture].boy.length).toBeGreaterThan(0);
      expect(authenticNames[culture].girl.length).toBeGreaterThan(0);
    }
  });

  test('should have translations for non-Latin script names', async () => {
    const nonLatinCultures = ['japanese', 'chinese', 'arabic'];
    
    for (const culture of nonLatinCultures) {
      for (const name of authenticNames[culture].boy) {
        expect(name).toContain(' - ');
      }
      
      for (const name of authenticNames[culture].girl) {
        expect(name).toContain(' - ');
      }
    }
  });

  test('should have appropriate gender categories for each culture', async () => {
    const cultures = Object.keys(authenticNames);
    
    for (const culture of cultures) {
      expect(authenticNames[culture].boy).toBeDefined();
      expect(authenticNames[culture].girl).toBeDefined();
      expect(authenticNames[culture].neutral).toBeDefined();
    }
  });

  test('should have unique names within each culture', async () => {
    const cultures = Object.keys(authenticNames);
    
    for (const culture of cultures) {
      const allNames = [
        ...authenticNames[culture].boy,
        ...authenticNames[culture].girl,
        ...authenticNames[culture].neutral
      ];
      
      const uniqueNames = new Set(allNames);
      expect(uniqueNames.size).toBe(allNames.length);
    }
  });
});
