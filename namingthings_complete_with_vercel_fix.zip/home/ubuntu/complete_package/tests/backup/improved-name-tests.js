/**
 * Unit tests for the improved name generation functionality
 */

const assert = require('assert');
const path = require('path');
const fs = require('fs');

// Mock environment variables
process.env.MODEL_MODE = 'local';
process.env.LOCAL_MODEL_PATH = './models';

// Import modules to test
const nameRules = require('../data/name_rules');
const expandedNames = require('../data/expanded_names');

describe('Name Generation Improvements Tests', function() {
  this.timeout(10000); // Increase timeout for potential API calls
  
  describe('Name Rules', function() {
    it('should validate names correctly', function() {
      // Valid names
      assert.strictEqual(nameRules.validateName('John', 'baby'), true);
      assert.strictEqual(nameRules.validateName('fetchUserData', 'developer'), true);
      assert.strictEqual(nameRules.validateName('Buddy', 'pet'), true);
      
      // Invalid names (too short for Latin script)
      assert.strictEqual(nameRules.validateName('Jo', 'baby'), false);
      assert.strictEqual(nameRules.validateName('fd', 'developer'), false);
      
      // Valid non-Latin script names (can be shorter)
      assert.strictEqual(nameRules.validateName('李', 'baby'), true, 'Chinese character should be valid');
      assert.strictEqual(nameRules.validateName('蓮', 'baby'), true, 'Japanese character should be valid');
    });
    
    it('should improve names correctly', function() {
      // Expand abbreviations
      assert.strictEqual(nameRules.improveName('Jo', 'baby', 'common', 'english'), 'Joseph');
      assert.strictEqual(nameRules.improveName('Ma', 'baby', 'common', 'english'), 'Matthew');
      
      // Apply capitalization
      assert.strictEqual(nameRules.improveName('robert', 'baby', 'common', 'english'), 'Robert');
      assert.strictEqual(nameRules.improveName('FetchData', 'developer', null, null), 'fetchData');
      
      // Handle style-specific transformations
      const traditionalName = nameRules.improveName('Alexander', 'baby', 'traditional', 'english');
      assert.strictEqual(traditionalName, 'Alexander');
      
      const modernName = nameRules.improveName('Zayden', 'baby', 'modern', 'english');
      assert.strictEqual(modernName, 'Zayden');
    });
    
    it('should detect script type correctly', function() {
      assert.strictEqual(nameRules.detectScriptType('John'), 'latin');
      assert.strictEqual(nameRules.detectScriptType('李明'), 'chinese');
      assert.strictEqual(nameRules.detectScriptType('محمد'), 'arabic');
      assert.strictEqual(nameRules.detectScriptType('大翔'), 'japanese');
    });
  });
  
  describe('Expanded Datasets', function() {
    it('should have expanded Nordic names', function() {
      assert.ok(expandedNames.nordic.boy.length > 20, 'Should have sufficient Nordic boy names');
      assert.ok(expandedNames.nordic.girl.length > 20, 'Should have sufficient Nordic girl names');
      assert.ok(expandedNames.nordic.neutral.length > 10, 'Should have sufficient Nordic neutral names');
      
      // Check for specific Nordic names
      assert.ok(expandedNames.nordic.boy.includes('Thor'), 'Should include Thor');
      assert.ok(expandedNames.nordic.girl.includes('Freya') || expandedNames.nordic.girl.includes('Freja'), 'Should include Freya/Freja');
    });
    
    it('should have expanded Indian names', function() {
      assert.ok(expandedNames.indian.boy.length > 20, 'Should have sufficient Indian boy names');
      assert.ok(expandedNames.indian.girl.length > 20, 'Should have sufficient Indian girl names');
      assert.ok(expandedNames.indian.neutral.length > 10, 'Should have sufficient Indian neutral names');
      
      // Check for specific Indian names
      assert.ok(expandedNames.indian.boy.includes('Vivek'), 'Should include Vivek');
      assert.ok(expandedNames.indian.boy.includes('Sanjay'), 'Should include Sanjay');
      assert.ok(expandedNames.indian.girl.includes('Priya'), 'Should include Priya');
    });
  });
  
  describe('Integration Tests', function() {
    it('should integrate name rules with expanded datasets', function() {
      // Create a simple integration test
      const nordicBoyNames = expandedNames.nordic.boy.slice(0, 5);
      const validatedNames = nordicBoyNames.map(name => 
        nameRules.validateName(name, 'baby') ? nameRules.improveName(name, 'baby', 'traditional', 'nordic') : ''
      ).filter(name => name.length > 0);
      
      assert.ok(validatedNames.length > 0, 'Should have valid Nordic names after processing');
    });
  });
});

// Run the tests if this file is executed directly
if (require.main === module) {
  describe('Running tests...', function() {
    // The tests will run automatically
  });
}
