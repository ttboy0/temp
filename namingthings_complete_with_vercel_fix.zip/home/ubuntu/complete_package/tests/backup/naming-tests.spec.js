const { test, expect } = require('@playwright/test');
const fs = require('fs');
const yaml = require('js-yaml');
const path = require('path');

// Load test configuration from YAML file
const testConfigPath = path.join(__dirname, 'test-config.yaml');
const testConfig = yaml.load(fs.readFileSync(testConfigPath, 'utf8'));

// Base URL for the application
const baseURL = 'http://localhost:3000';

// Test suite for Developer naming functionality
test.describe('Developer Naming Tests', () => {
  // Run before each test
  test.beforeEach(async ({ page }) => {
    // Navigate to the application
    await page.goto(baseURL);
    
    // Wait for the page to load completely
    await page.waitForSelector('#developer-tool', { state: 'visible' });
  });

  // Run tests for each developer test case in the YAML config
  for (const testCase of testConfig.developer_tests) {
    test(testCase.description, async ({ page }) => {
      console.log(`Running test: ${testCase.description}`);
      
      // Select input type (description or code)
      await page.locator(`input[name="input-type"][value="${testCase.input_type}"]`).check();
      
      // Enter the input text
      await page.locator('#input-text').fill(testCase.input_text);
      
      // Take screenshot before clicking button
      await page.screenshot({ path: `before-dev-click-${Date.now()}.png` });
      
      // Click the generate button
      await page.locator('#generate-btn').click();
      
      // Wait for results to appear
      await page.waitForSelector('.results-section', { state: 'visible' });
      
      // Wait for loading indicator to disappear
      await page.waitForSelector('#results-list li.loading', { state: 'detached', timeout: 15000 }).catch(e => {
        console.log('Loading indicator did not disappear, continuing test');
      });
      
      // Take screenshot after results appear
      await page.screenshot({ path: `after-dev-click-${Date.now()}.png` });
      
      // Verify results count
      const resultItems = await page.locator('#results-list li').all();
      expect(resultItems.length).toBeGreaterThanOrEqual(1);
      expect(resultItems.length).toBeLessThanOrEqual(testCase.expected_result_count);
      
      // Get all result texts
      const resultTexts = [];
      for (const item of resultItems) {
        const text = await item.textContent();
        expect(text.trim().length).toBeGreaterThan(0);
        resultTexts.push(text.trim());
      }
      
      console.log(`Generated names: ${resultTexts.join(', ')}`);
      
      // Verify at least one expected name is present in the results
      if (testCase.expected_names && testCase.expected_names.length > 0) {
        const foundMatch = testCase.expected_names.some(expectedName => 
          resultTexts.some(resultText => 
            resultText.toLowerCase().includes(expectedName.toLowerCase())
          )
        );
        
        expect(foundMatch).toBeTruthy();
        
        // Log the matching results for debugging
        const matchingResults = resultTexts.filter(resultText => 
          testCase.expected_names.some(expectedName => 
            resultText.toLowerCase().includes(expectedName.toLowerCase())
          )
        );
        
        console.log(`Found ${matchingResults.length} matching results: ${matchingResults.join(', ')}`);
        
        // Verify the results match what was sent from the model
        expect(matchingResults.length).toBeGreaterThan(0);
      }
      
      // Test copying a name (click the first result)
      await resultItems[0].click();
      
      // Wait for the copied message to appear
      await page.waitForSelector('.copied-message.show', { state: 'visible' });
      
      console.log(`Test completed: ${testCase.description}`);
    });
  }
});

// Test suite for Baby naming functionality
test.describe('Baby Naming Tests', () => {
  // Run before each test
  test.beforeEach(async ({ page }) => {
    // Navigate to the application
    await page.goto(baseURL);
    
    // Switch to the personal naming tool
    await page.locator('#personal-tool-tab').click();
    
    // Wait for the personal tool to be visible
    await page.waitForSelector('#personal-tool', { state: 'visible' });
    
    // Select baby naming
    await page.locator('input[name="personal-type"][value="baby"]').check();
  });

  // Run tests for each baby test case in the YAML config
  for (const testCase of testConfig.baby_tests) {
    test(testCase.description, async ({ page }) => {
      console.log(`Running test: ${testCase.description}`);
      
      // Select gender
      await page.locator('#gender-select').selectOption(testCase.gender);
      
      // Select style
      await page.locator('#style-select').selectOption(testCase.style);
      
      // Select origin
      await page.locator('#origin-select').selectOption(testCase.origin);
      
      // Take screenshot before clicking button
      await page.screenshot({ path: `before-baby-click-${Date.now()}.png` });
      
      // Get current names in the list (if any) to compare later
      const beforeNames = await page.locator('#personal-results-list li').allTextContents();
      console.log(`Names before clicking: ${beforeNames.join(', ')}`);
      
      // Click the generate button
      await page.locator('#generate-personal-btn').click();
      
      // Wait for results to appear (with a longer timeout for non-English languages)
      await page.waitForSelector('#personal-tool .results-section', { 
        state: 'visible',
        timeout: 15000 // 15 seconds timeout for potentially slower responses with non-Latin characters
      });
      
      // Wait for loading indicator to disappear
      await page.waitForSelector('#personal-results-list li.loading', { state: 'detached', timeout: 15000 }).catch(e => {
        console.log('Loading indicator did not disappear, continuing test');
      });
      
      // Take screenshot after results appear
      await page.screenshot({ path: `after-baby-click-${Date.now()}.png` });
      
      // Verify results count
      const resultItems = await page.locator('#personal-results-list li').all();
      expect(resultItems.length).toBeGreaterThanOrEqual(1);
      expect(resultItems.length).toBeLessThanOrEqual(testCase.expected_result_count);
      
      // Get all result texts
      const resultTexts = [];
      for (const item of resultItems) {
        const text = await item.textContent();
        expect(text.trim().length).toBeGreaterThan(0);
        resultTexts.push(text.trim());
      }
      
      console.log(`Generated names: ${resultTexts.join(', ')}`);
      
      // Verify the names have changed from before
      if (beforeNames.length > 0) {
        const namesHaveChanged = !arraysEqual(beforeNames, resultTexts);
        expect(namesHaveChanged).toBeTruthy();
        console.log(`Names have changed: ${namesHaveChanged}`);
      }
      
      // Verify at least one expected name is present in the results
      if (testCase.expected_names && testCase.expected_names.length > 0) {
        const foundMatch = testCase.expected_names.some(expectedName => 
          resultTexts.some(resultText => 
            resultText.includes(expectedName)
          )
        );
        
        expect(foundMatch).toBeTruthy();
        
        // Log the matching results for debugging
        const matchingResults = resultTexts.filter(resultText => 
          testCase.expected_names.some(expectedName => 
            resultText.includes(expectedName)
          )
        );
        
        console.log(`Found ${matchingResults.length} matching results: ${matchingResults.join(', ')}`);
        
        // Verify the results match what was sent from the model
        expect(matchingResults.length).toBeGreaterThan(0);
      }
      
      // Test copying a name (click the first result)
      if (resultItems.length > 0) {
        await resultItems[0].click();
        
        // Wait for the copied message to appear
        await page.waitForSelector('.copied-message.show', { state: 'visible' });
      }
      
      console.log(`Test completed: ${testCase.description}`);
    });
  }
});

// Test suite for Pet naming functionality
test.describe('Pet Naming Tests', () => {
  // Run before each test
  test.beforeEach(async ({ page }) => {
    // Navigate to the application
    await page.goto(baseURL);
    
    // Switch to the personal naming tool
    await page.locator('#personal-tool-tab').click();
    
    // Wait for the personal tool to be visible
    await page.waitForSelector('#personal-tool', { state: 'visible' });
    
    // Select pet naming
    await page.locator('input[name="personal-type"][value="pet"]').check();
  });

  // Run tests for each pet test case in the YAML config
  for (const testCase of testConfig.pet_tests) {
    test(testCase.description, async ({ page }) => {
      console.log(`Running test: ${testCase.description}`);
      
      // Select gender
      await page.locator('#pet-gender-select').selectOption(testCase.gender);
      
      // Select style
      await page.locator('#pet-style-select').selectOption(testCase.style);
      
      // Select theme
      await page.locator('#pet-theme-select').selectOption(testCase.theme);
      
      // Take screenshot before clicking button
      await page.screenshot({ path: `before-pet-click-${Date.now()}.png` });
      
      // Get current names in the list (if any) to compare later
      const beforeNames = await page.locator('#personal-results-list li').allTextContents();
      console.log(`Names before clicking: ${beforeNames.join(', ')}`);
      
      // Click the generate button
      await page.locator('#generate-personal-btn').click();
      
      // Wait for results to appear
      await page.waitForSelector('#personal-tool .results-section', { 
        state: 'visible',
        timeout: 15000 // 15 seconds timeout for potentially slower responses
      });
      
      // Wait for loading indicator to disappear
      await page.waitForSelector('#personal-results-list li.loading', { state: 'detached', timeout: 15000 }).catch(e => {
        console.log('Loading indicator did not disappear, continuing test');
      });
      
      // Take screenshot after results appear
      await page.screenshot({ path: `after-pet-click-${Date.now()}.png` });
      
      // Verify results count
      const resultItems = await page.locator('#personal-results-list li').all();
      expect(resultItems.length).toBeGreaterThanOrEqual(1);
      expect(resultItems.length).toBeLessThanOrEqual(testCase.expected_result_count);
      
      // Get all result texts
      const resultTexts = [];
      for (const item of resultItems) {
        const text = await item.textContent();
        expect(text.trim().length).toBeGreaterThan(0);
        resultTexts.push(text.trim());
      }
      
      console.log(`Generated names: ${resultTexts.join(', ')}`);
      
      // Verify the names have changed from before
      if (beforeNames.length > 0) {
        const namesHaveChanged = !arraysEqual(beforeNames, resultTexts);
        expect(namesHaveChanged).toBeTruthy();
        console.log(`Names have changed: ${namesHaveChanged}`);
      }
      
      // Verify at least one expected name is present in the results
      if (testCase.expected_names && testCase.expected_names.length > 0) {
        const foundMatch = testCase.expected_names.some(expectedName => 
          resultTexts.some(resultText => 
            resultText.toLowerCase().includes(expectedName.toLowerCase())
          )
        );
        
        expect(foundMatch).toBeTruthy();
        
        // Log the matching results for debugging
        const matchingResults = resultTexts.filter(resultText => 
          testCase.expected_names.some(expectedName => 
            resultText.toLowerCase().includes(expectedName.toLowerCase())
          )
        );
        
        console.log(`Found ${matchingResults.length} matching results: ${matchingResults.join(', ')}`);
        
        // Verify the results match what was sent from the model
        expect(matchingResults.length).toBeGreaterThan(0);
      }
      
      // Test copying a name (click the first result)
      if (resultItems.length > 0) {
        await resultItems[0].click();
        
        // Wait for the copied message to appear
        await page.waitForSelector('.copied-message.show', { state: 'visible' });
      }
      
      console.log(`Test completed: ${testCase.description}`);
    });
  }
});

// Helper function to compare arrays
function arraysEqual(a, b) {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}

// Unit tests for specific functionality
test.describe('Unit Tests', () => {
  test('Unit Test: Server responds to API requests', async ({ request }) => {
    const response = await request.get(`${baseURL}/api/model-status`);
    expect(response.ok()).toBeTruthy();
    const data = await response.json();
    expect(data).toHaveProperty('mode');
  });
  
  test('Unit Test: Generate developer names API', async ({ request }) => {
    const response = await request.post(`${baseURL}/api/generate-names`, {
      data: {
        input: 'A function that calculates the average',
        type: 'description',
        isPremium: false,
        timestamp: Date.now(),
        randomSeed: Math.random()
      }
    });
    expect(response.ok()).toBeTruthy();
    const data = await response.json();
    expect(data).toHaveProperty('names');
    expect(data.names.length).toBeGreaterThan(0);
  });
  
  test('Unit Test: Generate baby names API', async ({ request }) => {
    const response = await request.post(`${baseURL}/api/generate-personal-names`, {
      data: {
        type: 'baby',
        gender: 'boy',
        style: 'common',
        origin: 'english',
        isPremium: false,
        timestamp: Date.now(),
        randomSeed: Math.random()
      }
    });
    expect(response.ok()).toBeTruthy();
    const data = await response.json();
    expect(data).toHaveProperty('names');
    expect(data.names.length).toBeGreaterThan(0);
  });
  
  test('Unit Test: Generate pet names API', async ({ request }) => {
    const response = await request.post(`${baseURL}/api/generate-personal-names`, {
      data: {
        type: 'pet',
        gender: 'male',
        style: 'cute',
        origin: 'food',
        isPremium: false,
        timestamp: Date.now(),
        randomSeed: Math.random()
      }
    });
    expect(response.ok()).toBeTruthy();
    const data = await response.json();
    expect(data).toHaveProperty('names');
    expect(data.names.length).toBeGreaterThan(0);
  });
});
