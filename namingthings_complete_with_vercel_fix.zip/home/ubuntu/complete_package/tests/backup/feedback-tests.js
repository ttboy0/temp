/**
 * Integration test for the feedback mechanism
 */

const assert = require('assert');
const path = require('path');
const fs = require('fs');
const http = require('http');

describe('Feedback Mechanism Tests', function() {
  this.timeout(5000); // Increase timeout for HTTP requests
  
  // Mock server for testing feedback API
  let mockServer;
  let mockServerPort = 3001;
  
  before(function(done) {
    // Create a simple mock server to test the feedback API
    mockServer = http.createServer((req, res) => {
      if (req.method === 'POST' && req.url === '/api/feedback') {
        let body = '';
        req.on('data', chunk => {
          body += chunk.toString();
        });
        req.on('end', () => {
          try {
            const feedback = JSON.parse(body);
            
            // Validate feedback data
            if (!feedback.name || !feedback.rating || !feedback.type) {
              res.writeHead(400, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ error: 'Missing required fields' }));
              return;
            }
            
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true, message: 'Feedback recorded successfully' }));
          } catch (error) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Invalid JSON' }));
          }
        });
      } else {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Not found' }));
      }
    });
    
    mockServer.listen(mockServerPort, () => {
      console.log(`Mock server running on port ${mockServerPort}`);
      done();
    });
  });
  
  after(function(done) {
    // Close the mock server after tests
    if (mockServer) {
      mockServer.close(() => {
        console.log('Mock server closed');
        done();
      });
    } else {
      done();
    }
  });
  
  describe('Feedback API', function() {
    it('should accept valid feedback data', function(done) {
      const feedbackData = {
        name: 'TestName',
        rating: 5,
        type: 'baby',
        gender: 'boy',
        style: 'common',
        origin: 'nordic'
      };
      
      const options = {
        hostname: 'localhost',
        port: mockServerPort,
        path: '/api/feedback',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      };
      
      const req = http.request(options, (res) => {
        let data = '';
        
        res.on('data', (chunk) => {
          data += chunk;
        });
        
        res.on('end', () => {
          const response = JSON.parse(data);
          assert.strictEqual(res.statusCode, 200);
          assert.strictEqual(response.success, true);
          done();
        });
      });
      
      req.on('error', (error) => {
        console.error('Error:', error);
        done(error);
      });
      
      req.write(JSON.stringify(feedbackData));
      req.end();
    });
    
    it('should reject feedback without required fields', function(done) {
      const invalidFeedbackData = {
        // Missing name and rating
        type: 'baby',
        gender: 'boy'
      };
      
      const options = {
        hostname: 'localhost',
        port: mockServerPort,
        path: '/api/feedback',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      };
      
      const req = http.request(options, (res) => {
        let data = '';
        
        res.on('data', (chunk) => {
          data += chunk;
        });
        
        res.on('end', () => {
          const response = JSON.parse(data);
          assert.strictEqual(res.statusCode, 400);
          assert.ok(response.error);
          done();
        });
      });
      
      req.on('error', (error) => {
        console.error('Error:', error);
        done(error);
      });
      
      req.write(JSON.stringify(invalidFeedbackData));
      req.end();
    });
  });
  
  describe('Feedback UI Elements', function() {
    // These tests would normally use a browser automation tool like Playwright
    // For simplicity, we'll just verify that the feedback JS and CSS files exist
    
    it('should have feedback.js file', function() {
      const feedbackJsPath = path.join(__dirname, '..', 'public', 'js', 'feedback.js');
      assert.ok(fs.existsSync(feedbackJsPath), 'feedback.js file should exist');
      
      const content = fs.readFileSync(feedbackJsPath, 'utf8');
      assert.ok(content.includes('submitFeedback'), 'feedback.js should contain submitFeedback function');
      assert.ok(content.includes('showFeedbackForm'), 'feedback.js should contain showFeedbackForm function');
    });
    
    it('should have feedback.css file', function() {
      const feedbackCssPath = path.join(__dirname, '..', 'public', 'css', 'feedback.css');
      assert.ok(fs.existsSync(feedbackCssPath), 'feedback.css file should exist');
      
      const content = fs.readFileSync(feedbackCssPath, 'utf8');
      assert.ok(content.includes('.star-rating'), 'feedback.css should contain star-rating styles');
      assert.ok(content.includes('.feedback-form'), 'feedback.css should contain feedback-form styles');
    });
  });
});

// Run the tests if this file is executed directly
if (require.main === module) {
  describe('Running feedback tests...', function() {
    // The tests will run automatically
  });
}
