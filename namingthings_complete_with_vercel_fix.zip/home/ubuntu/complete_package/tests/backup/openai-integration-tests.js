/**
 * OpenAI GPT-4 Integration Tests
 */

const assert = require('assert');
const dotenv = require('dotenv');

// Load environment variables from .env file if it exists
dotenv.config();

// Import the enhanced OpenAI service
const EnhancedOpenAIService = require('../services/enhancedOpenAIService');

describe('OpenAI GPT-4 Integration Tests', function() {
  this.timeout(15000); // Increase timeout for API calls
  
  // Skip tests if no API key is provided
  const apiKey = process.env.OPENAI_API_KEY;
  const shouldSkipTests = !apiKey;
  
  let openaiService;
  
  before(function() {
    if (shouldSkipTests) {
      console.log('Skipping OpenAI tests because no API key is provided');
      this.skip();
    } else {
      openaiService = new EnhancedOpenAIService(apiKey);
    }
  });
  
  describe('Service Initialization', function() {
    it('should initialize with valid API key', function() {
      assert.strictEqual(openaiService.isInitialized(), true);
    });
    
    it('should detect if GPT-4 is available', function() {
      // This will depend on the model specified in the environment
      const isGPT4 = process.env.OPENAI_MODEL && process.env.OPENAI_MODEL.includes('gpt-4');
      assert.strictEqual(openaiService.isGPT4Available(), isGPT4);
    });
  });
  
  describe('Developer Name Generation', function() {
    it('should generate function names from description', async function() {
      const description = 'A function that calculates the average of an array of numbers';
      const names = await openaiService.generateNames(description, 'description', 5);
      
      assert.ok(Array.isArray(names));
      assert.ok(names.length > 0);
      assert.ok(names.every(name => typeof name === 'string' && name.length > 0));
      
      // Check if names are relevant to the description
      const relevantTerms = ['average', 'calc', 'mean', 'array', 'numbers'];
      const hasRelevantName = names.some(name => 
        relevantTerms.some(term => name.toLowerCase().includes(term.toLowerCase()))
      );
      
      assert.ok(hasRelevantName, 'At least one name should be relevant to the description');
    });
    
    it('should generate function names from code snippet', async function() {
      const code = `
        function(arr) {
          let sum = 0;
          for(let i = 0; i < arr.length; i++) {
            sum += arr[i];
          }
          return sum / arr.length;
        }
      `;
      
      const names = await openaiService.generateNames(code, 'code', 5);
      
      assert.ok(Array.isArray(names));
      assert.ok(names.length > 0);
      assert.ok(names.every(name => typeof name === 'string' && name.length > 0));
      
      // Check if names are in camelCase format
      const camelCaseRegex = /^[a-z][a-zA-Z0-9]*$/;
      assert.ok(names.some(name => camelCaseRegex.test(name)), 'At least one name should be in camelCase format');
    });
  });
  
  describe('Personal Name Generation', function() {
    it('should generate baby names', async function() {
      const names = await openaiService.generatePersonalNames('baby', 'boy', 'traditional', 'nordic', null, 5);
      
      assert.ok(Array.isArray(names));
      assert.ok(names.length > 0);
      assert.ok(names.every(name => typeof name === 'string' && name.length > 0));
      
      // Names should be capitalized
      assert.ok(names.every(name => name[0] === name[0].toUpperCase()), 'All names should be capitalized');
    });
    
    it('should generate pet names', async function() {
      const names = await openaiService.generatePersonalNames('pet', 'any', 'cute', null, 'food', 5);
      
      assert.ok(Array.isArray(names));
      assert.ok(names.length > 0);
      assert.ok(names.every(name => typeof name === 'string' && name.length > 0));
    });
  });
});

// Run the tests if this file is executed directly
if (require.main === module) {
  describe('Running OpenAI integration tests...', function() {
    // The tests will run automatically
  });
}
