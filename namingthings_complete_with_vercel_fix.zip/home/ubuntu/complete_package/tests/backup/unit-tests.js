const { expect } = require('chai');
const request = require('supertest');
const app = require('../server');
const fs = require('fs');
const path = require('path');

describe('Naming Things API Tests', function() {
  this.timeout(10000); // Increase timeout for tests that might take longer

  describe('Server Status', () => {
    it('should respond with 200 status code', async () => {
      const response = await request(app).get('/');
      expect(response.status).to.equal(200);
    });
  });

  describe('Model Status API', () => {
    it('should return model status information', async () => {
      const response = await request(app).get('/api/model-status');
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('mode');
      expect(response.body).to.have.property('localAvailable');
      expect(response.body).to.have.property('openaiAvailable');
    });
  });

  describe('Generate Names API', () => {
    it('should generate function names from description', async () => {
      const response = await request(app)
        .post('/api/generate-names')
        .send({
          input: 'A function that calculates the average of an array of numbers',
          type: 'description',
          isPremium: false,
          timestamp: Date.now(),
          randomSeed: Math.random()
        });
      
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('names');
      expect(response.body.names).to.be.an('array');
      expect(response.body.names.length).to.be.at.least(1);
      
      // Check if any of the expected names are present
      const expectedNames = ['calculateAverage', 'computeAverage', 'getAverage', 'findAverage'];
      const foundMatch = expectedNames.some(expectedName => 
        response.body.names.some(name => 
          name.toLowerCase().includes(expectedName.toLowerCase())
        )
      );
      
      expect(foundMatch).to.be.true;
    });

    it('should generate function names from code', async () => {
      const response = await request(app)
        .post('/api/generate-names')
        .send({
          input: 'function(arr) {\n  let sum = 0;\n  for(let i = 0; i < arr.length; i++) {\n    sum += arr[i];\n  }\n  return sum / arr.length;\n}',
          type: 'code',
          isPremium: false,
          timestamp: Date.now(),
          randomSeed: Math.random()
        });
      
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('names');
      expect(response.body.names).to.be.an('array');
      expect(response.body.names.length).to.be.at.least(1);
    });

    it('should handle input validation', async () => {
      const response = await request(app)
        .post('/api/generate-names')
        .send({
          input: '', // Empty input
          type: 'description',
          isPremium: false
        });
      
      expect(response.status).to.equal(400);
      expect(response.body).to.have.property('error');
    });

    it('should enforce character limits for non-premium users', async () => {
      // Generate a string longer than 500 characters
      const longInput = 'A'.repeat(501);
      
      const response = await request(app)
        .post('/api/generate-names')
        .send({
          input: longInput,
          type: 'description',
          isPremium: false
        });
      
      expect(response.status).to.equal(400);
      expect(response.body).to.have.property('error');
      expect(response.body).to.have.property('upgrade');
      expect(response.body.upgrade).to.be.true;
    });

    it('should allow longer inputs for premium users', async () => {
      // Generate a string longer than 500 but less than 2000 characters
      const longInput = 'A'.repeat(1000);
      
      const response = await request(app)
        .post('/api/generate-names')
        .send({
          input: longInput,
          type: 'description',
          isPremium: true
        });
      
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('names');
    });
  });

  describe('Generate Personal Names API', () => {
    it('should generate baby names', async () => {
      const response = await request(app)
        .post('/api/generate-personal-names')
        .send({
          type: 'baby',
          gender: 'boy',
          style: 'common',
          origin: 'english',
          isPremium: false,
          timestamp: Date.now(),
          randomSeed: Math.random()
        });
      
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('names');
      expect(response.body.names).to.be.an('array');
      expect(response.body.names.length).to.be.at.least(1);
      
      // Check if any of the expected names are present
      const expectedNames = ['Liam', 'Noah', 'Oliver', 'Elijah', 'William'];
      const foundMatch = expectedNames.some(expectedName => 
        response.body.names.some(name => 
          name.includes(expectedName)
        )
      );
      
      expect(foundMatch).to.be.true;
    });

    it('should generate pet names', async () => {
      const response = await request(app)
        .post('/api/generate-personal-names')
        .send({
          type: 'pet',
          gender: 'male',
          style: 'common',
          origin: 'food', // Theme is passed as origin
          isPremium: false,
          timestamp: Date.now(),
          randomSeed: Math.random()
        });
      
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('names');
      expect(response.body.names).to.be.an('array');
      expect(response.body.names.length).to.be.at.least(1);
      
      // Check if any of the expected names are present
      const expectedNames = ['Cookie', 'Pepper', 'Ginger', 'Honey', 'Olive'];
      const foundMatch = expectedNames.some(expectedName => 
        response.body.names.some(name => 
          name.includes(expectedName)
        )
      );
      
      expect(foundMatch).to.be.true;
    });

    it('should handle Spanish baby names correctly', async () => {
      const response = await request(app)
        .post('/api/generate-personal-names')
        .send({
          type: 'baby',
          gender: 'boy',
          style: 'common',
          origin: 'spanish',
          isPremium: false,
          timestamp: Date.now(),
          randomSeed: Math.random()
        });
      
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('names');
      expect(response.body.names).to.be.an('array');
      expect(response.body.names.length).to.be.at.least(1);
      
      // Check if any of the expected Spanish names are present
      const expectedNames = ['Santiago', 'Mateo', 'Sebastián', 'Leonardo', 'Emiliano'];
      const foundMatch = expectedNames.some(expectedName => 
        response.body.names.some(name => 
          name.includes(expectedName)
        )
      );
      
      expect(foundMatch).to.be.true;
    });

    it('should not include non-English options for pet names', async () => {
      const response = await request(app)
        .post('/api/generate-personal-names')
        .send({
          type: 'pet',
          gender: 'any',
          style: 'any',
          origin: 'any',
          isPremium: false,
          timestamp: Date.now(),
          randomSeed: Math.random()
        });
      
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('names');
      expect(response.body.names).to.be.an('array');
      
      // Check that no Chinese, Japanese, or Arabic characters are present
      const nonEnglishPatterns = [
        /[\u4e00-\u9fff]/, // Chinese
        /[\u3040-\u30ff]/, // Japanese
        /[\u0600-\u06ff]/, // Arabic
      ];
      
      const containsNonEnglish = response.body.names.some(name => 
        nonEnglishPatterns.some(pattern => pattern.test(name))
      );
      
      expect(containsNonEnglish).to.be.false;
    });

    it('should handle different styles for pet names', async () => {
      const styles = ['common', 'unique', 'cute', 'funny', 'cool'];
      
      for (const style of styles) {
        const response = await request(app)
          .post('/api/generate-personal-names')
          .send({
            type: 'pet',
            gender: 'any',
            style: style,
            origin: 'any',
            isPremium: false,
            timestamp: Date.now(),
            randomSeed: Math.random()
          });
        
        expect(response.status).to.equal(200);
        expect(response.body).to.have.property('names');
        expect(response.body.names).to.be.an('array');
        expect(response.body.names.length).to.be.at.least(1);
      }
    });

    it('should handle different themes for pet names', async () => {
      const themes = ['food', 'nature', 'mythology', 'literature', 'movies', 'colors'];
      
      for (const theme of themes) {
        const response = await request(app)
          .post('/api/generate-personal-names')
          .send({
            type: 'pet',
            gender: 'any',
            style: 'any',
            origin: theme, // Theme is passed as origin
            isPremium: false,
            timestamp: Date.now(),
            randomSeed: Math.random()
          });
        
        expect(response.status).to.equal(200);
        expect(response.body).to.have.property('names');
        expect(response.body.names).to.be.an('array');
        expect(response.body.names.length).to.be.at.least(1);
      }
    });
  });

  describe('AdSense Implementation', () => {
    it('should have conditional AdSense loading in index.html', () => {
      const indexPath = path.join(__dirname, '..', 'public', 'index.html');
      const indexContent = fs.readFileSync(indexPath, 'utf8');
      
      // Check for conditional AdSense loading
      expect(indexContent).to.include('window.location.hostname !== \'localhost\'');
      expect(indexContent).to.include('window.location.hostname !== \'127.0.0.1\'');
      
      // Check for dynamic ad insertion
      expect(indexContent).to.include('initializeAdsense');
      expect(indexContent).to.include('ad-container');
      
      // Check for error handling
      expect(indexContent).to.include('try {');
      expect(indexContent).to.include('catch (e) {');
    });
  });

  describe('Browser Scrolling Fix', () => {
    it('should have preventDefault in button click handlers in main.js', () => {
      const jsPath = path.join(__dirname, '..', 'public', 'js', 'main.js');
      const jsContent = fs.readFileSync(jsPath, 'utf8');
      
      // Check for preventDefault in click handlers
      expect(jsContent).to.include('preventDefault');
    });
  });

  describe('UTF-8 Support', () => {
    it('should have UTF-8 charset declaration in index.html', () => {
      const indexPath = path.join(__dirname, '..', 'public', 'index.html');
      const indexContent = fs.readFileSync(indexPath, 'utf8');
      
      // Check for UTF-8 charset declaration
      expect(indexContent).to.include('<meta charset="UTF-8">');
    });

    it('should handle non-Latin characters in baby names', async () => {
      const nonLatinOrigins = ['chinese', 'japanese', 'arabic'];
      
      for (const origin of nonLatinOrigins) {
        const response = await request(app)
          .post('/api/generate-personal-names')
          .send({
            type: 'baby',
            gender: 'boy',
            style: 'any',
            origin: origin,
            isPremium: false,
            timestamp: Date.now(),
            randomSeed: Math.random()
          });
        
        expect(response.status).to.equal(200);
        expect(response.body).to.have.property('names');
        expect(response.body.names).to.be.an('array');
        expect(response.body.names.length).to.be.at.least(1);
      }
    });
  });
});
