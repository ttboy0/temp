/**
 * Test script for all implemented improvements
 * 
 * This file contains tests for:
 * 1. Authentic native names
 * 2. Name translation feature
 * 3. Tier-based features
 * 4. Authentication system
 * 5. Google login integration
 * 6. Stripe payment integration
 */

const assert = require('assert');
const authenticNames = require('../data/authentic_names');
const nameTranslation = require('../data/name_translation');
const nameIntegration = require('../data/name_integration');
const tierManagement = require('../data/tier_management');
const userAuth = require('../data/user_authentication');
const paymentIntegration = require('../data/payment_integration');

// Test suite
(async function runTests() {
  console.log('Running tests for all implemented improvements...');
  
  try {
    // Test 1: Authentic native names
    testAuthenticNames();
    
    // Test 2: Name translation feature
    testNameTranslation();
    
    // Test 3: Tier-based features
    testTierManagement();
    
    // Test 4: Authentication system
    testAuthentication();
    
    // Test 5: Google login integration
    testGoogleLogin();
    
    // Test 6: Stripe payment integration
    testStripeIntegration();
    
    console.log('\nAll tests passed successfully! ✅');
  } catch (error) {
    console.error('\nTest failed:', error.message);
    process.exit(1);
  }
})();

// Test authentic native names
function testAuthenticNames() {
  console.log('\n1. Testing authentic native names...');
  
  // Test that all required cultures are present
  const requiredCultures = ['nordic', 'italian', 'german', 'greek', 'hebrew', 'african', 'indian', 'japanese', 'chinese', 'arabic'];
  requiredCultures.forEach(culture => {
    assert(authenticNames[culture], `${culture} names should be present`);
    assert(authenticNames[culture].boy.length > 0, `${culture} should have boy names`);
    assert(authenticNames[culture].girl.length > 0, `${culture} should have girl names`);
  });
  
  // Test that non-Latin script names have translations
  ['japanese', 'chinese', 'arabic'].forEach(culture => {
    authenticNames[culture].boy.forEach(name => {
      assert(name.includes(' - '), `${culture} boy name should include translation: ${name}`);
    });
    authenticNames[culture].girl.forEach(name => {
      assert(name.includes(' - '), `${culture} girl name should include translation: ${name}`);
    });
  });
  
  console.log('✅ Authentic native names tests passed');
}

// Test name translation feature
function testNameTranslation() {
  console.log('\n2. Testing name translation feature...');
  
  // Test formatNameWithTranslation
  assert.strictEqual(
    nameTranslation.formatNameWithTranslation('李明 - Li Ming'),
    '李明 - Li Ming',
    'Should keep already formatted names unchanged'
  );
  
  // Test getOriginalName
  assert.strictEqual(
    nameTranslation.getOriginalName('李明 - Li Ming'),
    '李明',
    'Should extract original name correctly'
  );
  
  // Test getTranslation
  assert.strictEqual(
    nameTranslation.getTranslation('李明 - Li Ming'),
    'Li Ming',
    'Should extract translation correctly'
  );
  
  // Test isNonLatinScript
  assert.strictEqual(
    nameTranslation.isNonLatinScript('李明'),
    true,
    'Should detect Chinese as non-Latin script'
  );
  assert.strictEqual(
    nameTranslation.isNonLatinScript('John'),
    false,
    'Should detect English as Latin script'
  );
  
  // Test identifyScript
  assert.strictEqual(
    nameTranslation.identifyScript('李明'),
    'chinese',
    'Should identify Chinese script correctly'
  );
  assert.strictEqual(
    nameTranslation.identifyScript('محمد'),
    'arabic',
    'Should identify Arabic script correctly'
  );
  assert.strictEqual(
    nameTranslation.identifyScript('John'),
    'latin',
    'Should identify Latin script correctly'
  );
  
  console.log('✅ Name translation feature tests passed');
}

// Test tier management
function testTierManagement() {
  console.log('\n3. Testing tier-based features...');
  
  // Test getTierDetails
  const freeTier = tierManagement.getTierDetails('free');
  assert.strictEqual(freeTier.name, 'Free', 'Free tier name should be correct');
  assert.strictEqual(freeTier.price, 0, 'Free tier price should be 0');
  assert.strictEqual(freeTier.nameLimit, 10, 'Free tier should have 10 name limit');
  
  const premiumTier = tierManagement.getTierDetails('premium');
  assert.strictEqual(premiumTier.name, 'Premium', 'Premium tier name should be correct');
  assert.strictEqual(premiumTier.price, 3, 'Premium tier price should be 3');
  assert.strictEqual(premiumTier.nameLimit, 25, 'Premium tier should have 25 name limit');
  
  const enterpriseTier = tierManagement.getTierDetails('enterprise');
  assert.strictEqual(enterpriseTier.name, 'Enterprise', 'Enterprise tier name should be correct');
  assert.strictEqual(enterpriseTier.price, 10, 'Enterprise tier price should be 10');
  assert.strictEqual(enterpriseTier.nameLimit, 50, 'Enterprise tier should have 50 name limit');
  
  // Test isFeatureAvailable
  assert.strictEqual(
    tierManagement.isFeatureAvailable('free', 'nameLimit'),
    10,
    'Free tier should have 10 name limit'
  );
  assert.strictEqual(
    tierManagement.isFeatureAvailable('premium', 'nameLimit'),
    25,
    'Premium tier should have 25 name limit'
  );
  assert.strictEqual(
    tierManagement.isFeatureAvailable('enterprise', 'nameLimit'),
    50,
    'Enterprise tier should have 50 name limit'
  );
  
  // Test enforceCharacterLimit
  assert.strictEqual(
    tierManagement.enforceCharacterLimit('a'.repeat(400), 'free'),
    true,
    'Free tier should allow 400 characters'
  );
  assert.strictEqual(
    tierManagement.enforceCharacterLimit('a'.repeat(600), 'free'),
    false,
    'Free tier should not allow 600 characters'
  );
  assert.strictEqual(
    tierManagement.enforceCharacterLimit('a'.repeat(1500), 'premium'),
    true,
    'Premium tier should allow 1500 characters'
  );
  assert.strictEqual(
    tierManagement.enforceCharacterLimit('a'.repeat(4000), 'enterprise'),
    true,
    'Enterprise tier should allow 4000 characters'
  );
  
  // Test enforceNameLimit
  assert.strictEqual(
    tierManagement.enforceNameLimit('free'),
    10,
    'Free tier should have 10 name limit'
  );
  assert.strictEqual(
    tierManagement.enforceNameLimit('premium'),
    25,
    'Premium tier should have 25 name limit'
  );
  assert.strictEqual(
    tierManagement.enforceNameLimit('enterprise'),
    50,
    'Enterprise tier should have 50 name limit'
  );
  
  // Test enforceRequestLimit
  assert.strictEqual(
    tierManagement.enforceRequestLimit(3, 'free'),
    true,
    'Free tier should allow 3 requests'
  );
  assert.strictEqual(
    tierManagement.enforceRequestLimit(6, 'free'),
    false,
    'Free tier should not allow 6 requests'
  );
  assert.strictEqual(
    tierManagement.enforceRequestLimit(100, 'premium'),
    true,
    'Premium tier should allow unlimited requests'
  );
  
  console.log('✅ Tier-based features tests passed');
}

// Test authentication system
function testAuthentication() {
  console.log('\n4. Testing authentication system...');
  
  // Test user registration
  const registerResult = userAuth.registerUser('test@example.com', 'password123', 'Test User');
  assert.strictEqual(registerResult.success, true, 'User registration should succeed');
  
  // Test duplicate registration
  const duplicateRegisterResult = userAuth.registerUser('test@example.com', 'password123', 'Test User');
  assert.strictEqual(duplicateRegisterResult.success, false, 'Duplicate registration should fail');
  
  // Test user login
  const loginResult = userAuth.loginUser('test@example.com', 'password123');
  assert.strictEqual(loginResult.success, true, 'User login should succeed');
  assert(loginResult.sessionId, 'Login should return a session ID');
  assert(loginResult.user, 'Login should return user data');
  assert.strictEqual(loginResult.user.email, 'test@example.com', 'Login should return correct user email');
  assert.strictEqual(loginResult.user.name, 'Test User', 'Login should return correct user name');
  assert.strictEqual(loginResult.user.tier, 'free', 'New user should have free tier');
  
  // Test invalid login
  const invalidLoginResult = userAuth.loginUser('test@example.com', 'wrongpassword');
  assert.strictEqual(invalidLoginResult.success, false, 'Invalid login should fail');
  
  // Test session validation
  const sessionValidationResult = userAuth.validateSession(loginResult.sessionId);
  assert.strictEqual(sessionValidationResult.valid, true, 'Session validation should succeed');
  assert(sessionValidationResult.user, 'Session validation should return user data');
  
  // Test invalid session
  const invalidSessionValidationResult = userAuth.validateSession('invalid_session_id');
  assert.strictEqual(invalidSessionValidationResult.valid, false, 'Invalid session validation should fail');
  
  // Test logout
  const logoutResult = userAuth.logoutUser(loginResult.sessionId);
  assert.strictEqual(logoutResult.success, true, 'Logout should succeed');
  
  // Test session validation after logout
  const sessionValidationAfterLogoutResult = userAuth.validateSession(loginResult.sessionId);
  assert.strictEqual(sessionValidationAfterLogoutResult.valid, false, 'Session should be invalid after logout');
  
  // Test updating user tier
  const newUser = userAuth.registerUser('premium@example.com', 'password123', 'Premium User');
  const updateTierResult = userAuth.updateUserTier(newUser.userId, 'premium');
  assert.strictEqual(updateTierResult.success, true, 'Updating user tier should succeed');
  
  // Test login after tier update
  const loginAfterTierUpdateResult = userAuth.loginUser('premium@example.com', 'password123');
  assert.strictEqual(loginAfterTierUpdateResult.user.tier, 'premium', 'User tier should be updated');
  
  console.log('✅ Authentication system tests passed');
}

// Test Google login integration
function testGoogleLogin() {
  console.log('\n5. Testing Google login integration...');
  
  // Mock Google user data
  const googleUserData = {
    googleId: 'google_123456789',
    email: 'google_user@example.com',
    name: 'Google User'
  };
  
  // Test Google authentication
  const googleAuthResult = userAuth.googleAuth(googleUserData);
  assert.strictEqual(googleAuthResult.success, true, 'Google authentication should succeed');
  assert(googleAuthResult.sessionId, 'Google authentication should return a session ID');
  assert(googleAuthResult.user, 'Google authentication should return user data');
  assert.strictEqual(googleAuthResult.user.email, 'google_user@example.com', 'Google authentication should return correct user email');
  assert.strictEqual(googleAuthResult.user.name, 'Google User', 'Google authentication should return correct user name');
  assert.strictEqual(googleAuthResult.user.tier, 'free', 'New Google user should have free tier');
  
  // Test session validation for Google user
  const googleSessionValidationResult = userAuth.validateSession(googleAuthResult.sessionId);
  assert.strictEqual(googleSessionValidationResult.valid, true, 'Google user session validation should succeed');
  
  // Test logout for Google user
  const googleLogoutResult = userAuth.logoutUser(googleAuthResult.sessionId);
  assert.strictEqual(googleLogoutResult.success, true, 'Google user logout should succeed');
  
  console.log('✅ Google login integration tests passed');
}

// Test Stripe payment integration
function testStripeIntegration() {
  console.log('\n6. Testing Stripe payment integration...');
  
  // Test Stripe configuration
  assert(paymentIntegration.stripeConfig, 'Stripe configuration should exist');
  assert(paymentIntegration.stripeConfig.publishableKey, 'Stripe publishable key should exist');
  assert(paymentIntegration.stripeConfig.products, 'Stripe products should exist');
  assert(paymentIntegration.stripeConfig.products.premium, 'Premium product should exist');
  assert(paymentIntegration.stripeConfig.products.enterprise, 'Enterprise product should exist');
  
  // Test creating checkout session
  const checkoutResult = paymentIntegration.createCheckoutSession(
    'premium',
    'user_123',
    'https://example.com/success',
    'https://example.com/cancel'
  );
  assert.strictEqual(checkoutResult.success, true, 'Creating checkout session should succeed');
  assert(checkoutResult.sessionId, 'Checkout session should have an ID');
  assert(checkoutResult.checkoutUrl, 'Checkout session should have a URL');
  assert.strictEqual(checkoutResult.tier, 'premium', 'Checkout session should have correct tier');
  
  // Test webhook handling
  const webhookEvent = {
    type: 'checkout.session.completed',
    data: {
      object: {
        client_reference_id: 'user_123',
        metadata: {
          tier: 'premium'
        }
      }
    }
  };
  const webhookResult = paymentIntegration.handleStripeWebhook(webhookEvent);
  assert.strictEqual(webhookResult.success, true, 'Webhook handling should succeed');
  assert.strictEqual(webhookResult.userId, 'user_123', 'Webhook result should have correct user ID');
  assert.strictEqual(webhookResult.tierName, 'premium', 'Webhook result should have correct tier name');
  
  // Test getting subscription details
  const subscriptionResult = paymentIntegration.getUserSubscription('user_123');
  assert.strictEqual(subscriptionResult.success, true, 'Getting subscription details should succeed');
  assert(subscriptionResult.subscription, 'Subscription details should exist');
  assert(subscriptionResult.subscription.id, 'Subscription should have an ID');
  assert.strictEqual(subscriptionResult.subscription.status, 'active', 'Subscription should be active');
  
  // Test cancelling subscription
  const cancelResult = paymentIntegration.cancelSubscription('sub_123');
  assert.strictEqual(cancelResult.success, true, 'Cancelling subscription should succeed');
  
  console.log('✅ Stripe payment integration tests passed');
}
