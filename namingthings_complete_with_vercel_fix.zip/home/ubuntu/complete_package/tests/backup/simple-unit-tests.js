const { expect } = require('chai');
const request = require('supertest');
const app = require('../server');

describe('Naming Things API Tests', function() {
  this.timeout(10000); // Increase timeout for tests that might take longer

  describe('Server Status', () => {
    it('should respond with 200 status code', async () => {
      const response = await request(app).get('/');
      expect(response.status).to.equal(200);
    });
  });

  describe('Model Status API', () => {
    it('should return model status information', async () => {
      const response = await request(app).get('/api/model-status');
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('mode');
      expect(response.body).to.have.property('localAvailable');
      expect(response.body).to.have.property('openaiAvailable');
    });
  });

  describe('Generate Names API', () => {
    it('should generate function names from description', async () => {
      const response = await request(app)
        .post('/api/generate-names')
        .send({
          input: 'A function that calculates the average of an array of numbers',
          type: 'description',
          isPremium: false,
          timestamp: Date.now(),
          randomSeed: Math.random()
        });
      
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('names');
      expect(response.body.names).to.be.an('array');
      expect(response.body.names.length).to.be.at.least(1);
    });

    it('should handle input validation', async () => {
      const response = await request(app)
        .post('/api/generate-names')
        .send({
          input: '', // Empty input
          type: 'description',
          isPremium: false
        });
      
      expect(response.status).to.equal(400);
      expect(response.body).to.have.property('error');
    });
  });

  describe('Generate Personal Names API', () => {
    it('should generate baby names', async () => {
      const response = await request(app)
        .post('/api/generate-personal-names')
        .send({
          type: 'baby',
          gender: 'boy',
          style: 'common',
          origin: 'english',
          isPremium: false,
          timestamp: Date.now(),
          randomSeed: Math.random()
        });
      
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('names');
      expect(response.body.names).to.be.an('array');
      expect(response.body.names.length).to.be.at.least(1);
    });

    it('should generate pet names', async () => {
      const response = await request(app)
        .post('/api/generate-personal-names')
        .send({
          type: 'pet',
          gender: 'male',
          style: 'common',
          origin: 'food', // Theme is passed as origin
          isPremium: false,
          timestamp: Date.now(),
          randomSeed: Math.random()
        });
      
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('names');
      expect(response.body.names).to.be.an('array');
      expect(response.body.names.length).to.be.at.least(1);
    });

    it('should handle Spanish baby names correctly', async () => {
      const response = await request(app)
        .post('/api/generate-personal-names')
        .send({
          type: 'baby',
          gender: 'boy',
          style: 'common',
          origin: 'spanish',
          isPremium: false,
          timestamp: Date.now(),
          randomSeed: Math.random()
        });
      
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('names');
      expect(response.body.names).to.be.an('array');
      expect(response.body.names.length).to.be.at.least(1);
    });
  });
});
