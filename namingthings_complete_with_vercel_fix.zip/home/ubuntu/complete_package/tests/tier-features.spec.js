/**
 * Tier-Based Features Test
 * 
 * This file contains tests for the tier-based features
 */

const { test, expect } = require('@playwright/test');
const tierManagement = require('../data/tier_management');

test.describe('Tier-Based Features', () => {
  test('should have correct tier details', async () => {
    // Free tier
    const freeTier = tierManagement.getTierDetails('free');
    expect(freeTier.name).toBe('Free');
    expect(freeTier.price).toBe(0);
    expect(freeTier.nameLimit).toBe(10);
    expect(freeTier.characterLimit).toBe(500);
    expect(freeTier.requestsPerDay).toBe(5);
    
    // Premium tier
    const premiumTier = tierManagement.getTierDetails('premium');
    expect(premiumTier.name).toBe('Premium');
    expect(premiumTier.price).toBe(5);
    expect(premiumTier.nameLimit).toBe(25);
    expect(premiumTier.characterLimit).toBe(2000);
    expect(premiumTier.requestsPerDay).toBe(Infinity);
    
    // Enterprise tier
    const enterpriseTier = tierManagement.getTierDetails('enterprise');
    expect(enterpriseTier.name).toBe('Enterprise');
    expect(enterpriseTier.price).toBe(15);
    expect(enterpriseTier.nameLimit).toBe(50);
    expect(enterpriseTier.characterLimit).toBe(5000);
    expect(enterpriseTier.requestsPerDay).toBe(Infinity);
  });

  test('should check feature availability correctly', async () => {
    // Name limit
    expect(tierManagement.isFeatureAvailable('free', 'nameLimit')).toBe(10);
    expect(tierManagement.isFeatureAvailable('premium', 'nameLimit')).toBe(25);
    expect(tierManagement.isFeatureAvailable('enterprise', 'nameLimit')).toBe(50);
    
    // Character limit
    expect(tierManagement.isFeatureAvailable('free', 'characterLimit')).toBe(500);
    expect(tierManagement.isFeatureAvailable('premium', 'characterLimit')).toBe(2000);
    expect(tierManagement.isFeatureAvailable('enterprise', 'characterLimit')).toBe(5000);
    
    // Requests per day
    expect(tierManagement.isFeatureAvailable('free', 'requestsPerDay')).toBe(5);
    expect(tierManagement.isFeatureAvailable('premium', 'requestsPerDay')).toBe(Infinity);
    expect(tierManagement.isFeatureAvailable('enterprise', 'requestsPerDay')).toBe(Infinity);
  });

  test('should enforce character limits correctly', async () => {
    // Free tier
    expect(tierManagement.enforceCharacterLimit('a'.repeat(400), 'free')).toBe(true);
    expect(tierManagement.enforceCharacterLimit('a'.repeat(600), 'free')).toBe(false);
    
    // Premium tier
    expect(tierManagement.enforceCharacterLimit('a'.repeat(1500), 'premium')).toBe(true);
    expect(tierManagement.enforceCharacterLimit('a'.repeat(2500), 'premium')).toBe(false);
    
    // Enterprise tier
    expect(tierManagement.enforceCharacterLimit('a'.repeat(4000), 'enterprise')).toBe(true);
    expect(tierManagement.enforceCharacterLimit('a'.repeat(6000), 'enterprise')).toBe(false);
  });

  test('should enforce name limits correctly', async () => {
    expect(tierManagement.enforceNameLimit('free')).toBe(10);
    expect(tierManagement.enforceNameLimit('premium')).toBe(25);
    expect(tierManagement.enforceNameLimit('enterprise')).toBe(50);
  });

  test('should enforce request limits correctly', async () => {
    // Free tier
    expect(tierManagement.enforceRequestLimit(3, 'free')).toBe(true);
    expect(tierManagement.enforceRequestLimit(6, 'free')).toBe(false);
    
    // Premium tier
    expect(tierManagement.enforceRequestLimit(100, 'premium')).toBe(true);
    
    // Enterprise tier
    expect(tierManagement.enforceRequestLimit(1000, 'enterprise')).toBe(true);
  });
});
