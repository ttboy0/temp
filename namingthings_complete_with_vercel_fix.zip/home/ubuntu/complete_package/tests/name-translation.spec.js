/**
 * Name Translation Test
 * 
 * This file contains tests for the name translation feature
 */

const { test, expect } = require('@playwright/test');
const nameTranslation = require('../data/name_translation');

test.describe('Name Translation Feature', () => {
  test('should format names with translations correctly', async () => {
    // Already formatted name should remain unchanged
    expect(nameTranslation.formatNameWithTranslation('李明 - Li Ming')).toBe('李明 - Li Ming');
    
    // Name without translation should remain unchanged
    expect(nameTranslation.formatNameWithTranslation('John')).toBe('John');
  });

  test('should extract original name correctly', async () => {
    // Extract from formatted name
    expect(nameTranslation.getOriginalName('李明 - Li Ming')).toBe('李明');
    
    // Name without translation should remain unchanged
    expect(nameTranslation.getOriginalName('John')).toBe('John');
  });

  test('should extract translation correctly', async () => {
    // Extract from formatted name
    expect(nameTranslation.getTranslation('李明 - Li Ming')).toBe('Li Ming');
    
    // Name without translation should return itself
    expect(nameTranslation.getTranslation('John')).toBe('John');
  });

  test('should detect non-Latin scripts correctly', async () => {
    // Chinese characters
    expect(nameTranslation.isNonLatinScript('李明')).toBe(true);
    
    // Japanese characters
    expect(nameTranslation.isNonLatinScript('健太')).toBe(true);
    
    // Arabic characters
    expect(nameTranslation.isNonLatinScript('محمد')).toBe(true);
    
    // Latin characters
    expect(nameTranslation.isNonLatinScript('John')).toBe(false);
    
    // Formatted name with non-Latin script
    expect(nameTranslation.isNonLatinScript('李明 - Li Ming')).toBe(true);
  });

  test('should identify scripts correctly', async () => {
    // Chinese
    expect(nameTranslation.identifyScript('李明')).toBe('chinese');
    
    // Japanese
    expect(nameTranslation.identifyScript('健太')).toBe('japanese');
    
    // Arabic
    expect(nameTranslation.identifyScript('محمد')).toBe('arabic');
    
    // Latin
    expect(nameTranslation.identifyScript('John')).toBe('latin');
    
    // Formatted name
    expect(nameTranslation.identifyScript('李明 - Li Ming')).toBe('chinese');
  });
});
