/**
 * Authentication System Test
 * 
 * This file contains tests for the authentication system
 */

const { test, expect } = require('@playwright/test');
const userAuth = require('../data/user_authentication');

test.describe('Authentication System', () => {
  let testUserId;
  let testSessionId;
  
  test('should register a new user', async () => {
    const email = `test_${Date.now()}@example.com`;
    const password = 'password123';
    const name = 'Test User';
    
    const result = userAuth.registerUser(email, password, name);
    expect(result.success).toBe(true);
    expect(result.message).toContain('Registration successful');
    expect(result.userId).toBeDefined();
    
    // Save user ID for later tests
    testUserId = result.userId;
  });
  
  test('should prevent duplicate registration', async () => {
    const email = `duplicate_${Date.now()}@example.com`;
    const password = 'password123';
    const name = 'Duplicate User';
    
    // First registration should succeed
    const firstResult = userAuth.registerUser(email, password, name);
    expect(firstResult.success).toBe(true);
    
    // Second registration with same email should fail
    const secondResult = userAuth.registerUser(email, password, name);
    expect(secondResult.success).toBe(false);
    expect(secondResult.message).toContain('already exists');
  });
  
  test('should login a registered user', async () => {
    const email = `login_${Date.now()}@example.com`;
    const password = 'password123';
    const name = 'Login Test User';
    
    // Register user first
    const registerResult = userAuth.registerUser(email, password, name);
    expect(registerResult.success).toBe(true);
    
    // Then login
    const loginResult = userAuth.loginUser(email, password);
    expect(loginResult.success).toBe(true);
    expect(loginResult.message).toContain('Login successful');
    expect(loginResult.sessionId).toBeDefined();
    expect(loginResult.user).toBeDefined();
    expect(loginResult.user.email).toBe(email);
    expect(loginResult.user.name).toBe(name);
    expect(loginResult.user.tier).toBe('free'); // Default tier
    
    // Save session ID for later tests
    testSessionId = loginResult.sessionId;
  });
  
  test('should reject invalid login', async () => {
    const email = `invalid_${Date.now()}@example.com`;
    const password = 'password123';
    const name = 'Invalid Login User';
    
    // Register user first
    const registerResult = userAuth.registerUser(email, password, name);
    expect(registerResult.success).toBe(true);
    
    // Try login with wrong password
    const loginResult = userAuth.loginUser(email, 'wrongpassword');
    expect(loginResult.success).toBe(false);
    expect(loginResult.message).toContain('Invalid email or password');
  });
  
  test('should validate session correctly', async () => {
    const email = `session_${Date.now()}@example.com`;
    const password = 'password123';
    const name = 'Session Test User';
    
    // Register and login user
    userAuth.registerUser(email, password, name);
    const loginResult = userAuth.loginUser(email, password);
    expect(loginResult.success).toBe(true);
    
    // Validate session
    const sessionResult = userAuth.validateSession(loginResult.sessionId);
    expect(sessionResult.valid).toBe(true);
    expect(sessionResult.user).toBeDefined();
    expect(sessionResult.user.email).toBe(email);
    
    // Validate invalid session
    const invalidResult = userAuth.validateSession('invalid_session_id');
    expect(invalidResult.valid).toBe(false);
  });
  
  test('should logout user correctly', async () => {
    const email = `logout_${Date.now()}@example.com`;
    const password = 'password123';
    const name = 'Logout Test User';
    
    // Register and login user
    userAuth.registerUser(email, password, name);
    const loginResult = userAuth.loginUser(email, password);
    expect(loginResult.success).toBe(true);
    
    // Logout
    const logoutResult = userAuth.logoutUser(loginResult.sessionId);
    expect(logoutResult.success).toBe(true);
    expect(logoutResult.message).toContain('Logout successful');
    
    // Session should be invalid after logout
    const sessionResult = userAuth.validateSession(loginResult.sessionId);
    expect(sessionResult.valid).toBe(false);
  });
  
  test('should update user tier correctly', async () => {
    const email = `tier_${Date.now()}@example.com`;
    const password = 'password123';
    const name = 'Tier Test User';
    
    // Register user
    const registerResult = userAuth.registerUser(email, password, name);
    expect(registerResult.success).toBe(true);
    
    // Update tier
    const updateResult = userAuth.updateUserTier(registerResult.userId, 'premium');
    expect(updateResult.success).toBe(true);
    expect(updateResult.message).toContain('User tier updated');
    
    // Login to verify tier update
    const loginResult = userAuth.loginUser(email, password);
    expect(loginResult.success).toBe(true);
    expect(loginResult.user.tier).toBe('premium');
  });
});
