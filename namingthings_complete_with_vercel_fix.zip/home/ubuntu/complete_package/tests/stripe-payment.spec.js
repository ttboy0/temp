/**
 * Stripe Payment Integration Test
 * 
 * This file contains tests for the Stripe payment integration
 */

const { test, expect } = require('@playwright/test');
const paymentIntegration = require('../data/payment_integration');
const userAuth = require('../data/user_authentication');

test.describe('Stripe Payment Integration', () => {
  test('should have valid Stripe configuration', async () => {
    // Verify Stripe configuration
    expect(paymentIntegration.stripeConfig).toBeDefined();
    expect(paymentIntegration.stripeConfig.publishableKey).toBeDefined();
    expect(paymentIntegration.stripeConfig.publishableKey).toContain('pk_test_');
    
    // Verify product configuration
    expect(paymentIntegration.stripeConfig.products).toBeDefined();
    expect(paymentIntegration.stripeConfig.products.premium).toBeDefined();
    expect(paymentIntegration.stripeConfig.products.premium.priceId).toBeDefined();
    expect(paymentIntegration.stripeConfig.products.premium.priceAmount).toBe(500); // $5.00
    
    expect(paymentIntegration.stripeConfig.products.enterprise).toBeDefined();
    expect(paymentIntegration.stripeConfig.products.enterprise.priceId).toBeDefined();
    expect(paymentIntegration.stripeConfig.products.enterprise.priceAmount).toBe(1500); // $15.00
  });
  
  test('should create checkout session for premium tier', async () => {
    // Create a test user
    const email = `stripe_premium_${Date.now()}@example.com`;
    const password = 'password123';
    const name = 'Stripe Premium Test User';
    
    const registerResult = userAuth.registerUser(email, password, name);
    expect(registerResult.success).toBe(true);
    
    // Create checkout session
    const checkoutResult = paymentIntegration.createCheckoutSession(
      'premium',
      registerResult.userId,
      'https://example.com/success',
      'https://example.com/cancel'
    );
    
    // Verify checkout session
    expect(checkoutResult.success).toBe(true);
    expect(checkoutResult.sessionId).toBeDefined();
    expect(checkoutResult.checkoutUrl).toBeDefined();
    expect(checkoutResult.tier).toBe('premium');
    expect(checkoutResult.amount).toBe(500); // $5.00
    expect(checkoutResult.currency).toBe('usd');
  });
  
  test('should create checkout session for enterprise tier', async () => {
    // Create a test user
    const email = `stripe_enterprise_${Date.now()}@example.com`;
    const password = 'password123';
    const name = 'Stripe Enterprise Test User';
    
    const registerResult = userAuth.registerUser(email, password, name);
    expect(registerResult.success).toBe(true);
    
    // Create checkout session
    const checkoutResult = paymentIntegration.createCheckoutSession(
      'enterprise',
      registerResult.userId,
      'https://example.com/success',
      'https://example.com/cancel'
    );
    
    // Verify checkout session
    expect(checkoutResult.success).toBe(true);
    expect(checkoutResult.sessionId).toBeDefined();
    expect(checkoutResult.checkoutUrl).toBeDefined();
    expect(checkoutResult.tier).toBe('enterprise');
    expect(checkoutResult.amount).toBe(1500); // $15.00
    expect(checkoutResult.currency).toBe('usd');
  });
  
  test('should handle webhook events correctly', async () => {
    // Create a test user
    const email = `webhook_${Date.now()}@example.com`;
    const password = 'password123';
    const name = 'Webhook Test User';
    
    const registerResult = userAuth.registerUser(email, password, name);
    expect(registerResult.success).toBe(true);
    
    // Mock checkout.session.completed webhook event
    const webhookEvent = {
      type: 'checkout.session.completed',
      data: {
        object: {
          client_reference_id: registerResult.userId,
          metadata: {
            tier: 'premium'
          }
        }
      }
    };
    
    // Process webhook event
    const webhookResult = paymentIntegration.handleStripeWebhook(webhookEvent);
    
    // Verify webhook handling
    expect(webhookResult.success).toBe(true);
    expect(webhookResult.userId).toBe(registerResult.userId);
    expect(webhookResult.tierName).toBe('premium');
    
    // Update user tier based on webhook
    const updateResult = userAuth.updateUserTier(webhookResult.userId, webhookResult.tierName);
    expect(updateResult.success).toBe(true);
    
    // Verify user tier was updated
    const loginResult = userAuth.loginUser(email, password);
    expect(loginResult.success).toBe(true);
    expect(loginResult.user.tier).toBe('premium');
  });
  
  test('should get subscription details', async () => {
    // Create a test user
    const email = `subscription_${Date.now()}@example.com`;
    const password = 'password123';
    const name = 'Subscription Test User';
    
    const registerResult = userAuth.registerUser(email, password, name);
    expect(registerResult.success).toBe(true);
    
    // Get subscription details
    const subscriptionResult = paymentIntegration.getUserSubscription(registerResult.userId);
    
    // Verify subscription details
    expect(subscriptionResult.success).toBe(true);
    expect(subscriptionResult.subscription).toBeDefined();
    expect(subscriptionResult.subscription.id).toBeDefined();
    expect(subscriptionResult.subscription.status).toBe('active');
    expect(subscriptionResult.subscription.currentPeriodEnd).toBeInstanceOf(Date);
  });
  
  test('should cancel subscription', async () => {
    // Create a test user
    const email = `cancel_${Date.now()}@example.com`;
    const password = 'password123';
    const name = 'Cancel Subscription Test User';
    
    const registerResult = userAuth.registerUser(email, password, name);
    expect(registerResult.success).toBe(true);
    
    // Update user to premium tier
    userAuth.updateUserTier(registerResult.userId, 'premium');
    
    // Get subscription details
    const subscriptionResult = paymentIntegration.getUserSubscription(registerResult.userId);
    expect(subscriptionResult.success).toBe(true);
    
    // Cancel subscription
    const cancelResult = paymentIntegration.cancelSubscription(subscriptionResult.subscription.id);
    
    // Verify cancellation
    expect(cancelResult.success).toBe(true);
    expect(cancelResult.message).toContain('cancelled successfully');
    
    // Update user tier to free
    userAuth.updateUserTier(registerResult.userId, 'free');
    
    // Verify user tier was updated
    const loginResult = userAuth.loginUser(email, password);
    expect(loginResult.success).toBe(true);
    expect(loginResult.user.tier).toBe('free');
  });
});
