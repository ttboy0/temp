// End-to-end tests for the NamingThings application
const { test, expect } = require('@playwright/test');

test.describe('NamingThings Application', () => {
  test.beforeEach(async ({ page }) => {
    // Navigate to the application
    await page.goto('http://localhost:3000');
    
    // Wait for the page to load completely
    await page.waitForSelector('h1:has-text("The Ultimate Naming Solution")');
  });
  
  test('should display the application title', async ({ page }) => {
    const title = await page.textContent('h1');
    expect(title).toBe('The Ultimate Naming Solution');
  });
  
  test('should generate function names from description', async ({ page }) => {
    // Enter a description
    await page.fill('#input-text', 'A function that finds the maximum value in a list of numbers');
    
    // Select description radio button (should be selected by default)
    await page.check('input[name="input-type"][value="description"]');
    
    // Click generate button
    await page.click('#generate-btn');
    
    // Wait for results to appear
    await page.waitForSelector('#results-list li', { timeout: 10000 });
    
    // Check that results are displayed
    const results = await page.$$eval('#results-list li', items => items.map(item => item.textContent));
    expect(results.length).toBeGreaterThan(0);
  });
  
  test('should generate function names from code snippet', async ({ page }) => {
    // Enter a code snippet
    await page.fill('#input-text', 'function(arr) { return Math.max(...arr); }');
    
    // Select code snippet radio button
    await page.check('input[name="input-type"][value="code"]');
    
    // Click generate button
    await page.click('#generate-btn');
    
    // Wait for results to appear
    await page.waitForSelector('#results-list li', { timeout: 10000 });
    
    // Check that results are displayed
    const results = await page.$$eval('#results-list li', items => items.map(item => item.textContent));
    expect(results.length).toBeGreaterThan(0);
  });
  
  test('should show error when description is empty', async ({ page }) => {
    // Leave the input empty
    await page.fill('#input-text', '');
    
    // Click generate button
    await page.click('#generate-btn');
    
    // Check for alert
    page.on('dialog', async dialog => {
      expect(dialog.message()).toContain('Please enter a description or code snippet');
      await dialog.accept();
    });
  });
  
  test('should display model status indicator', async ({ page }) => {
    // Check that model status indicator is displayed
    const statusText = await page.textContent('#model-status-text');
    expect(statusText).toBeTruthy();
    
    // Status should either be checking, ready, error, or fallback
    const statusIndicator = await page.$eval('#model-status-indicator', el => {
      return el.classList.contains('active') || 
             el.classList.contains('loading') || 
             el.classList.contains('error') || 
             el.classList.contains('warning');
    });
    
    expect(statusIndicator).toBe(true);
  });
  
  test('should navigate to Babies & Pet Names tab', async ({ page }) => {
    // Click on Babies & Pet Names tab
    await page.click('a:has-text("Babies & Pet Names")');
    
    // Check that Babies & Pet Names section is displayed
    const personalToolVisible = await page.isVisible('#personal-tool');
    expect(personalToolVisible).toBe(true);
    
    // Check that Code Names section is hidden
    const developerToolVisible = await page.isVisible('#developer-tool');
    expect(developerToolVisible).toBe(false);
  });
  
  test('should generate baby names', async ({ page }) => {
    // Navigate to Babies & Pet Names tab
    await page.click('a:has-text("Babies & Pet Names")');
    
    // Select baby radio button (should be selected by default)
    await page.check('input[name="personal-type"][value="baby"]');
    
    // Select options
    await page.selectOption('#gender-select', 'boy');
    await page.selectOption('#style-select', 'modern');
    await page.selectOption('#origin-select', 'any');
    
    // Click generate button
    await page.click('#generate-personal-btn');
    
    // Wait for results to appear
    await page.waitForSelector('#personal-results-list li', { timeout: 10000 });
    
    // Check that results are displayed
    const results = await page.$$eval('#personal-results-list li', items => items.map(item => item.textContent));
    expect(results.length).toBeGreaterThan(0);
  });
  
  test('should generate pet names', async ({ page }) => {
    // Navigate to Babies & Pet Names tab
    await page.click('a:has-text("Babies & Pet Names")');
    
    // Select pet radio button
    await page.check('input[name="personal-type"][value="pet"]');
    
    // Check that pet options are displayed
    const petOptionsVisible = await page.isVisible('#pet-options');
    expect(petOptionsVisible).toBe(true);
    
    // Select options
    await page.selectOption('#pet-gender-select', 'any');
    await page.selectOption('#pet-style-select', 'cute');
    await page.selectOption('#pet-theme-select', 'food');
    
    // Click generate button
    await page.click('#generate-personal-btn');
    
    // Wait for results to appear
    await page.waitForSelector('#personal-results-list li', { timeout: 10000 });
    
    // Check that results are displayed
    const results = await page.$$eval('#personal-results-list li', items => items.map(item => item.textContent));
    expect(results.length).toBeGreaterThan(0);
  });
  
  test('should copy name to clipboard when clicked', async ({ page }) => {
    // Enter a description
    await page.fill('#input-text', 'A function that finds the maximum value in a list of numbers');
    
    // Click generate button
    await page.click('#generate-btn');
    
    // Wait for results to appear
    await page.waitForSelector('#results-list li', { timeout: 10000 });
    
    // Click on the first result
    await page.click('#results-list li:first-child');
    
    // Check that copied message is displayed
    const copiedMessageVisible = await page.isVisible('.copied-message.show');
    expect(copiedMessageVisible).toBe(true);
  });
  
  test('should update character count as user types', async ({ page }) => {
    // Check initial character count
    const initialCount = await page.textContent('.character-count');
    expect(initialCount).toBe('0/500 characters');
    
    // Enter text
    await page.fill('#input-text', 'Test description');
    
    // Check updated character count
    const updatedCount = await page.textContent('.character-count');
    expect(updatedCount).toBe('15/500 characters');
  });
  
  test('should navigate to privacy policy page', async ({ page }) => {
    // Click on Privacy Policy link in footer
    await page.click('footer a:has-text("Privacy Policy")');
    
    // Check that privacy policy page is displayed
    const privacyTitleVisible = await page.isVisible('h1:has-text("Privacy Policy")');
    expect(privacyTitleVisible).toBe(true);
  });
});
