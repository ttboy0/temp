// Unit tests for openaiService.js
const OpenAIService = require('../services/openaiService');

// Mock the OpenAI API
jest.mock('openai', () => {
  return {
    OpenAI: jest.fn().mockImplementation(() => ({
      models: {
        list: jest.fn().mockResolvedValue({})
      },
      chat: {
        completions: {
          create: jest.fn().mockResolvedValue({
            choices: [
              {
                message: {
                  content: "findMaximum\ngetMaxValue\nfindLargestNumber\ncomputeMaximum\ndetermineMaxValue\nfunction1\nfunction2\nfunction3\nfunction4\nfunction5"
                }
              }
            ]
          })
        }
      }
    }))
  };
});

// Mock fs module
jest.mock('fs', () => ({
  existsSync: jest.fn().mockReturnValue(true),
  mkdirSync: jest.fn(),
  createWriteStream: jest.fn().mockReturnValue({
    write: jest.fn()
  })
}));

// Mock path module
jest.mock('path', () => ({
  join: jest.fn().mockReturnValue('/mock/path')
}));

// Mock dotenv
jest.mock('dotenv', () => ({
  config: jest.fn()
}));

describe('OpenAIService', () => {
  let originalEnv;
  
  beforeEach(() => {
    // Save original environment and set test environment
    originalEnv = process.env;
    process.env = { 
      ...process.env,
      OPENAI_API_KEY: 'test-api-key',
      OPENAI_MODEL: 'gpt-3.5-turbo'
    };
    
    // Clear all mocks
    jest.clearAllMocks();
  });
  
  afterEach(() => {
    // Restore original environment
    process.env = originalEnv;
  });
  
  test('constructor initializes with API key and model', () => {
    const service = new OpenAIService('test-api-key');
    expect(service.model).toBe('gpt-3.5-turbo');
  });
  
  test('checkStatus returns available status when API is accessible', async () => {
    const service = new OpenAIService('test-api-key');
    const status = await service.checkStatus();
    
    expect(status).toEqual({
      available: true,
      model: 'gpt-3.5-turbo',
      message: 'OpenAI API is accessible'
    });
  });
  
  test('generateNames returns parsed names from OpenAI response', async () => {
    const service = new OpenAIService('test-api-key');
    const description = 'A function that finds the maximum value in a list of numbers';
    // Updated to match free tier limit of 10 names
    const names = await service.generateNames(description, 'description', 10);
    
    expect(names).toEqual([
      'findMaximum',
      'getMaxValue',
      'findLargestNumber',
      'computeMaximum',
      'determineMaxValue',
      'function1',
      'function2',
      'function3',
      'function4',
      'function5'
    ]);
  });
  
  test('generateNames handles code snippets', async () => {
    const service = new OpenAIService('test-api-key');
    const codeSnippet = 'function(arr) { return Math.max(...arr); }';
    // Updated to match free tier limit of 10 names
    const names = await service.generateNames(codeSnippet, 'code', 10);
    
    expect(names).toEqual([
      'findMaximum',
      'getMaxValue',
      'findLargestNumber',
      'computeMaximum',
      'determineMaxValue',
      'function1',
      'function2',
      'function3',
      'function4',
      'function5'
    ]);
  });
  
  test('generatePersonalNames returns parsed names for baby names', async () => {
    const service = new OpenAIService('test-api-key');
    const options = {
      gender: 'boy',
      style: 'modern',
      origin: 'any'
    };
    
    // Updated to match free tier limit of 10 names
    const names = await service.generatePersonalNames('baby', options, 10);
    
    expect(names).toEqual([
      'findMaximum',
      'getMaxValue',
      'findLargestNumber',
      'computeMaximum',
      'determineMaxValue',
      'function1',
      'function2',
      'function3',
      'function4',
      'function5'
    ]);
  });
  
  test('generatePersonalNames returns parsed names for pet names', async () => {
    const service = new OpenAIService('test-api-key');
    const options = {
      gender: 'any',
      style: 'cute',
      theme: 'food'
    };
    
    // Updated to match free tier limit of 10 names
    const names = await service.generatePersonalNames('pet', options, 10);
    
    expect(names).toEqual([
      'findMaximum',
      'getMaxValue',
      'findLargestNumber',
      'computeMaximum',
      'determineMaxValue',
      'function1',
      'function2',
      'function3',
      'function4',
      'function5'
    ]);
  });
  
  test('constructor throws error when API key is missing', () => {
    expect(() => {
      new OpenAIService();
    }).toThrow('OpenAI API key not found');
  });
  
  test('checkStatus returns unavailable status when API is not accessible', async () => {
    const service = new OpenAIService('test-api-key');
    service.openai = {
      models: {
        list: jest.fn().mockRejectedValue(new Error('API error'))
      }
    };
    
    const status = await service.checkStatus();
    
    expect(status).toEqual({
      available: false,
      model: 'gpt-3.5-turbo',
      message: 'API error'
    });
  });
  
  test('generateNames throws error when OpenAI API fails', async () => {
    const service = new OpenAIService('test-api-key');
    service.openai = {
      chat: {
        completions: {
          create: jest.fn().mockRejectedValue(new Error('API error'))
        }
      }
    };
    
    await expect(service.generateNames('test description')).rejects.toThrow('Failed to generate names with OpenAI: API error');
  });
});
