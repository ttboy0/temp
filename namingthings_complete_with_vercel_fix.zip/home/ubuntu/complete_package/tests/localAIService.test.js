// Unit tests for localAIService.js
const LocalAIService = require('../services/localAIService');

// Mock the @xenova/transformers pipeline
jest.mock('@xenova/transformers', () => ({
  pipeline: jest.fn().mockResolvedValue((prompt, options) => {
    return [
      {
        generated_text: prompt + "\nfindMaximum\ngetMaxValue\nfindLargestNumber\ncomputeMaximum\ndetermineMaxValue\nfunction1\nfunction2\nfunction3\nfunction4\nfunction5"
      }
    ];
  })
}));

// Mock fs module
jest.mock('fs', () => ({
  existsSync: jest.fn().mockReturnValue(true),
  mkdirSync: jest.fn(),
  createWriteStream: jest.fn().mockReturnValue({
    write: jest.fn()
  })
}));

// Mock path module
jest.mock('path', () => ({
  join: jest.fn().mockReturnValue('/mock/path')
}));

// Mock dotenv
jest.mock('dotenv', () => ({
  config: jest.fn()
}));

describe('LocalAIService', () => {
  beforeEach(() => {
    // Clear all mocks
    jest.clearAllMocks();
  });
  
  test('constructor initializes with model path', () => {
    const service = new LocalAIService('./models');
    expect(service.modelPath).toBe('./models');
    expect(service.initialized).toBe(false);
    expect(service.initializing).toBe(false);
  });
  
  test('initializeModel sets initialized to true when successful', async () => {
    const service = new LocalAIService('./models');
    await service.initializeModel();
    
    expect(service.initialized).toBe(true);
    expect(service.initializing).toBe(false);
  });
  
  test('isInitialized returns initialization status', () => {
    const service = new LocalAIService('./models');
    expect(service.isInitialized()).toBe(false);
    
    service.initialized = true;
    expect(service.isInitialized()).toBe(true);
  });
  
  test('checkStatus returns status with model information', async () => {
    const service = new LocalAIService('./models');
    service.initialized = true;
    
    const status = await service.checkStatus();
    
    expect(status).toEqual({
      available: true,
      modelInitialized: true,
      modelPath: './models',
      message: 'Local AI model is ready'
    });
  });
  
  test('generateNames returns extracted function names', async () => {
    const service = new LocalAIService('./models');
    service.initialized = true;
    
    const description = 'A function that finds the maximum value in a list of numbers';
    // Updated to match free tier limit of 10 names
    const names = await service.generateNames(description, 'description', 10);
    
    expect(names).toEqual([
      'findMaximum',
      'getMaxValue',
      'findLargestNumber',
      'computeMaximum',
      'determineMaxValue',
      'function1',
      'function2',
      'function3',
      'function4',
      'function5'
    ]);
  });
  
  test('extractFunctionNames processes raw text into function names', () => {
    const service = new LocalAIService('./models');
    const rawText = `
      findMaximum
      GetMaxValue
      find_largest_number
      computeMaximum
      DetermineMaxValue
      function1
      function2
      function3
      function4
      function5
    `;
    
    // Updated to match free tier limit of 10 names
    const names = service.extractFunctionNames(rawText, 10);
    
    // Expect camelCase conversion for all names
    expect(names).toContain('findMaximum');
    expect(names).toContain('getMaxValue');
    expect(names).toContain('findLargestNumber');
    expect(names).toContain('computeMaximum');
    expect(names).toContain('determineMaxValue');
    expect(names).toContain('function1');
    expect(names).toContain('function2');
    expect(names).toContain('function3');
    expect(names).toContain('function4');
    expect(names).toContain('function5');
  });
  
  test('generateNames throws error when model is not initialized', async () => {
    const service = new LocalAIService('./models');
    service.initialized = false;
    service.initializing = false;
    
    // Mock initializeModel to fail
    service.initializeModel = jest.fn().mockImplementation(async () => {
      service.initialized = false;
      service.initializing = false;
    });
    
    await expect(service.generateNames('test description')).rejects.toThrow('Local AI model is not initialized yet');
  });
  
  test('generatePersonalNames returns baby names', async () => {
    const service = new LocalAIService('./models');
    service.initialized = true;
    
    // Mock the generateBabyNames method with 10 names
    service.generateBabyNames = jest.fn().mockReturnValue([
      'Liam', 'Noah', 'Oliver', 'Elijah', 'William',
      'Name1', 'Name2', 'Name3', 'Name4', 'Name5'
    ]);
    
    const options = {
      gender: 'boy',
      style: 'modern',
      origin: 'any'
    };
    
    // Updated to match free tier limit of 10 names
    const names = await service.generatePersonalNames('baby', options, 10);
    
    expect(names).toEqual([
      'Liam', 'Noah', 'Oliver', 'Elijah', 'William',
      'Name1', 'Name2', 'Name3', 'Name4', 'Name5'
    ]);
    expect(service.generateBabyNames).toHaveBeenCalledWith(options, 10);
  });
  
  test('generatePersonalNames returns pet names', async () => {
    const service = new LocalAIService('./models');
    service.initialized = true;
    
    // Mock the generatePetNames method with 10 names
    service.generatePetNames = jest.fn().mockReturnValue([
      'Cookie', 'Pepper', 'Ginger', 'Oreo', 'Biscuit',
      'Pet1', 'Pet2', 'Pet3', 'Pet4', 'Pet5'
    ]);
    
    const options = {
      gender: 'any',
      style: 'cute',
      theme: 'food'
    };
    
    // Updated to match free tier limit of 10 names
    const names = await service.generatePersonalNames('pet', options, 10);
    
    expect(names).toEqual([
      'Cookie', 'Pepper', 'Ginger', 'Oreo', 'Biscuit',
      'Pet1', 'Pet2', 'Pet3', 'Pet4', 'Pet5'
    ]);
    expect(service.generatePetNames).toHaveBeenCalledWith(options, 10);
  });
});
