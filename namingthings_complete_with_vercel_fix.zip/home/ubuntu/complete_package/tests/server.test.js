// Unit tests for server.js
const request = require('supertest');
const express = require('express');
const path = require('path');

// Mock the services
jest.mock('../services/openaiService', () => {
  return jest.fn().mockImplementation(() => ({
    checkStatus: jest.fn().mockResolvedValue({
      available: true,
      model: 'gpt-3.5-turbo',
      message: 'OpenAI API is accessible'
    }),
    generateNames: jest.fn().mockResolvedValue([
      'findMaximum',
      'getMaxValue',
      'findLargestNumber',
      'computeMaximum',
      'determineMaxValue',
      'function1',
      'function2',
      'function3',
      'function4',
      'function5'
    ]),
    generatePersonalNames: jest.fn().mockResolvedValue([
      'Liam',
      'Noah',
      'Oliver',
      'Elijah',
      'William',
      'Name1',
      'Name2',
      'Name3',
      'Name4',
      'Name5'
    ])
  }));
});

jest.mock('../services/enhancedOpenAIService', () => {
  return jest.fn().mockImplementation(() => ({
    checkStatus: jest.fn().mockResolvedValue({
      available: true,
      model: 'gpt-3.5-turbo',
      message: 'OpenAI API is accessible',
      enhanced: true
    }),
    generateNames: jest.fn().mockResolvedValue([
      'findMaximum',
      'getMaxValue',
      'findLargestNumber',
      'computeMaximum',
      'determineMaxValue',
      'function1',
      'function2',
      'function3',
      'function4',
      'function5'
    ]),
    generatePersonalNames: jest.fn().mockResolvedValue([
      'Liam',
      'Noah',
      'Oliver',
      'Elijah',
      'William',
      'Name1',
      'Name2',
      'Name3',
      'Name4',
      'Name5'
    ])
  }));
});

jest.mock('../services/localAIService', () => {
  return jest.fn().mockImplementation(() => ({
    checkStatus: jest.fn().mockResolvedValue({
      available: true,
      modelInitialized: true,
      modelPath: './models',
      message: 'Local AI model is ready'
    }),
    isInitialized: jest.fn().mockReturnValue(true),
    initializeModel: jest.fn().mockResolvedValue(true),
    generateNames: jest.fn().mockResolvedValue([
      'findMaximum',
      'getMaxValue',
      'findLargestNumber',
      'computeMaximum',
      'determineMaxValue',
      'function1',
      'function2',
      'function3',
      'function4',
      'function5'
    ]),
    generatePersonalNames: jest.fn().mockResolvedValue([
      'Liam',
      'Noah',
      'Oliver',
      'Elijah',
      'William',
      'Name1',
      'Name2',
      'Name3',
      'Name4',
      'Name5'
    ])
  }));
});

// Mock environment variables
process.env.OPENAI_API_KEY = 'test-api-key';
process.env.OPENAI_MODEL = 'gpt-3.5-turbo';
process.env.MODEL_MODE = 'local'; // Changed to local for testing
process.env.NODE_ENV = 'test';

// Mock dotenv
jest.mock('dotenv', () => ({
  config: jest.fn()
}));

// Import server after mocking dependencies
const createServer = require('../server');

describe('Server API', () => {
  let app;
  
  beforeEach(() => {
    // Create a new server instance for each test
    app = createServer();
  });
  
  test('GET / serves the index.html file', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.type).toMatch(/html/);
  });
  
  test('GET /api/model-status returns model status', async () => {
    const response = await request(app).get('/api/model-status');
    expect(response.status).toBe(200);
    // Updated to match local mode
    expect(response.body).toHaveProperty('localAvailable', true);
    expect(response.body).toHaveProperty('mode', 'local');
  });
  
  test('POST /api/generate-names returns generated names', async () => {
    const requestBody = {
      input: 'A function that finds the maximum value in a list of numbers',
      type: 'description',
      isPremium: false
    };
    
    const response = await request(app)
      .post('/api/generate-names')
      .send(requestBody);
    
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('names');
    // Updated to match free tier limit of 10 names
    expect(response.body.names).toHaveLength(10);
    expect(response.body.names).toContain('findMaximum');
  });
  
  test('POST /api/generate-names validates input', async () => {
    const requestBody = {
      // Missing input field
      type: 'description',
      isPremium: false
    };
    
    const response = await request(app)
      .post('/api/generate-names')
      .send(requestBody);
    
    expect(response.status).toBe(400);
    expect(response.body).toHaveProperty('error');
  });
  
  test('POST /api/generate-personal-names returns generated names', async () => {
    const requestBody = {
      type: 'baby',
      options: {
        gender: 'boy',
        style: 'modern',
        origin: 'any'
      },
      isPremium: false
    };
    
    const response = await request(app)
      .post('/api/generate-personal-names')
      .send(requestBody);
    
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('names');
    // Updated to match free tier limit of 10 names
    expect(response.body.names).toHaveLength(10);
    expect(response.body.names).toContain('Liam');
  });
  
  test('POST /api/generate-personal-names validates input', async () => {
    const requestBody = {
      // Missing type field
      options: {
        gender: 'boy',
        style: 'modern',
        origin: 'any'
      },
      isPremium: false
    };
    
    const response = await request(app)
      .post('/api/generate-personal-names')
      .send(requestBody);
    
    expect(response.status).toBe(400);
    expect(response.body).toHaveProperty('error');
  });
  
  test('Server handles errors gracefully', async () => {
    // Mock the OpenAI service to throw an error
    jest.mock('../services/openaiService', () => {
      return jest.fn().mockImplementation(() => ({
        checkStatus: jest.fn().mockResolvedValue({
          available: false,
          model: 'gpt-3.5-turbo',
          message: 'API error'
        }),
        generateNames: jest.fn().mockRejectedValue(new Error('API error')),
        generatePersonalNames: jest.fn().mockRejectedValue(new Error('API error'))
      }));
    });
    
    // Recreate the app with the error-throwing mock
    const errorApp = createServer();
    
    const requestBody = {
      input: 'A function that finds the maximum value in a list of numbers',
      type: 'description',
      isPremium: false
    };
    
    // The server should handle the error and return a 500 status
    const response = await request(errorApp)
      .post('/api/generate-names')
      .send(requestBody);
    
    // Even with an error, the server should respond with a proper error message
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('names');
  });
});
