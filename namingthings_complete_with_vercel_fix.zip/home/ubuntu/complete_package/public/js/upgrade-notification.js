// Event listener for upgrade button
document.addEventListener('DOMContentLoaded', function() {
    const upgradeBtn = document.getElementById('upgrade-btn');
    if (upgradeBtn) {
        upgradeBtn.addEventListener('click', function(e) {
            e.preventDefault();
            alert('This feature is coming soon');
            console.log('FRONTEND: Upgrade button clicked, showed coming soon message');
        });
    }
});
