    // DOM Elements - Developer Tool
    const inputText = document.getElementById('input-text');
    const generateBtn = document.getElementById('generate-btn');
    const resultsList = document.getElementById('results-list');
    const resultsSection = document.querySelector('#developer-tool .results-section');
    const characterCount = document.querySelector('.character-count');
    const errorMessage = document.querySelector('.error-message');
    const modelStatusIndicator = document.getElementById('model-status-indicator');
    const modelStatusText = document.getElementById('model-status-text');
    const radioButtons = document.querySelectorAll('input[name="input-type"]');
    const upgradeBtn = document.getElementById('upgrade-btn');
    
    // DOM Elements - Personal Names Tool
    const personalTypeRadios = document.querySelectorAll('input[name="personal-type"]');
    const babyOptions = document.getElementById('baby-options');
    const petOptions = document.getElementById('pet-options');
    const generatePersonalBtn = document.getElementById('generate-personal-btn');
    const personalResultsList = document.getElementById('personal-results-list');
    const personalResultsSection = document.querySelector('#personal-tool .results-section');
    
    // Configuration
    const MAX_FREE_CHARS = 500;
    const MAX_PREMIUM_CHARS = 2000;
    let isPremium = false; // Default to free plan
    let modelStatus = 'checking'; // 'checking', 'ready', 'error', 'fallback'
    let isGeneratingPersonalNames = false; // Flag to prevent multiple simultaneous requests
    let personalNameRequestTimeout = null; // For debouncing
    let isGeneratingDeveloperNames = false; // Flag to prevent multiple simultaneous requests
    let clickTimeouts = {}; // For tracking click timeouts to prevent double-clicks
    
    // Enhanced logging - Log initialization
    console.log('FRONTEND: DOM loaded, initializing Naming Things application');
    console.log('FRONTEND: DOM elements found:', {
        inputText: !!inputText,
        generateBtn: !!generateBtn,
        resultsList: !!resultsList,
        resultsSection: !!resultsSection,
        characterCount: !!characterCount,
        errorMessage: !!errorMessage,
        modelStatusIndicator: !!modelStatusIndicator,
        modelStatusText: !!modelStatusText,
        radioButtons: !!radioButtons && radioButtons.length,
        personalTypeRadios: !!personalTypeRadios && personalTypeRadios.length,
        babyOptions: !!babyOptions,
        petOptions: !!petOptions,
        generatePersonalBtn: !!generatePersonalBtn,
        personalResultsList: !!personalResultsList,
        personalResultsSection: !!personalResultsSection
    });
    
    // Check model status on page load
    checkModelStatus();
    
    // Event Listeners - Developer Tool
    if (inputText) {
        inputText.addEventListener('input', updateCharacterCount);
        console.log('FRONTEND: Input text listener added');
    }
    
    if (generateBtn) {
        generateBtn.addEventListener('click', function(e) {
            // Prevent default to stop form submission behavior
            e.preventDefault();
            console.log('FRONTEND: Generate button clicked');
            
            // Prevent double-clicks
            if (debounceClick('generate-btn')) {
                generateNames();
            }
        });
    } else {
        console.error('FRONTEND: Developer generate button not found in the DOM');
    }
    
    // Event Listeners - Personal Names Tool
    if (personalTypeRadios && personalTypeRadios.length > 0) {
        personalTypeRadios.forEach(radio => {
            radio.addEventListener('change', togglePersonalOptions);
            console.log('FRONTEND: Personal type radio listener added');
        });
    } else {
        console.error('FRONTEND: Personal type radio buttons not found in the DOM');
    }
    
    // Direct DOM query for the generate personal button to ensure it's found
    const directGeneratePersonalBtn = document.getElementById('generate-personal-btn');
    
    if (directGeneratePersonalBtn) {
        console.log('FRONTEND: Found generate personal button via direct query');
        
        // Remove any existing event listeners to prevent duplicates
        const newGeneratePersonalBtn = directGeneratePersonalBtn.cloneNode(true);
        directGeneratePersonalBtn.parentNode.replaceChild(newGeneratePersonalBtn, directGeneratePersonalBtn);
        
        // Add event listener to the new button
        newGeneratePersonalBtn.addEventListener('click', function(e) {
            console.log('FRONTEND: Generate personal button clicked');
            
            // Prevent default to stop form submission behavior
            e.preventDefault();
            
            // Prevent double-clicks
            if (debounceClick('generate-personal-btn')) {
                generatePersonalNames(false); // false means not from dropdown change
            }
        });
    } else {
        console.error('FRONTEND: Generate Personal Button not found via direct query');
    }
    
    // Add event listeners for select elements to update UI without triggering API calls
    const genderSelect = document.getElementById('gender-select');
    const styleSelect = document.getElementById('style-select');
    const originSelect = document.getElementById('origin-select');
    const petGenderSelect = document.getElementById('pet-gender-select');
    const petStyleSelect = document.getElementById('pet-style-select');
    const petThemeSelect = document.getElementById('pet-theme-select');
    
    // Fix: Check if elements exist before adding event listeners
    // MODIFIED: Removed debouncePersonalNameGeneration to prevent API calls on dropdown changes
    if (genderSelect) genderSelect.addEventListener('change', updatePersonalSelectionUI);
    if (styleSelect) styleSelect.addEventListener('change', updatePersonalSelectionUI);
    if (originSelect) originSelect.addEventListener('change', updatePersonalSelectionUI);
    if (petGenderSelect) petGenderSelect.addEventListener('change', updatePersonalSelectionUI);
    if (petStyleSelect) petStyleSelect.addEventListener('change', updatePersonalSelectionUI);
    if (petThemeSelect) petThemeSelect.addEventListener('change', updatePersonalSelectionUI);
    
    // New function to update UI without triggering API calls
    function updatePersonalSelectionUI() {
        console.log('FRONTEND: Personal selection changed, updating UI only');
        // You could add code here to update any UI elements based on the selection
        // For example, showing a preview of the selected options
    }
    
    // Debounce function for personal name generation - REMOVED API call trigger
    function debouncePersonalNameGeneration() {
        console.log('FRONTEND: Debouncing personal name generation - API call disabled on dropdown change');
        // No longer triggers API calls on dropdown changes
    }
    
    // Debounce function to prevent double-clicks
    function debounceClick(id) {
        if (clickTimeouts[id]) {
            console.log('FRONTEND: Debouncing click for', id);
            return false; // Don't process if a click is already being processed
        }
        
        clickTimeouts[id] = setTimeout(() => {
            clickTimeouts[id] = null;
        }, 500); // 500ms debounce time
        
        return true;
    }
    
    // Functions - Common
    function checkModelStatus() {
        // Update UI to show checking status
        updateModelStatusUI('checking', 'Checking AI model status...');
        console.log('FRONTEND: Checking model status');
        
        // Fetch model status from server
        fetch('/api/model-status')
            .then(response => {
                console.log('FRONTEND: Model status response received, status:', response.status);
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('FRONTEND: Model status data:', data);
                if (data.openaiAvailable) {
                    updateModelStatusUI('ready', 'Using AI for name generation');
                    modelStatus = 'ready';
                } else if (data.localAvailable && data.localModelInitialized) {
                    updateModelStatusUI('ready', 'Using AI for name generation');
                    modelStatus = 'ready';
                } else if (data.mode === 'hybrid') {
                    updateModelStatusUI('ready', 'Using AI for name generation');
                    modelStatus = 'ready';
                } else {
                    updateModelStatusUI('fallback', 'Using pattern recognition (AI model unavailable)');
                    modelStatus = 'fallback';
                }
            })
            .catch(error => {
                console.error('FRONTEND: Error checking model status:', error);
                updateModelStatusUI('error', 'Unable to connect to AI server. Using pattern recognition.');
                modelStatus = 'error';
            });
    }
    
    function updateModelStatusUI(status, message) {
        if (!modelStatusIndicator || !modelStatusText) {
            console.error('FRONTEND: Model status elements not found');
            return;
        }
        
        console.log('FRONTEND: Updating model status UI:', status, message);
        
        // Remove all status classes
        modelStatusIndicator.classList.remove('status-checking', 'status-ready', 'status-error', 'status-fallback');
        
        // Add appropriate class based on status
        modelStatusIndicator.classList.add(`status-${status}`);
        
        // Update status text
        modelStatusText.textContent = message;
    }
    
    function updateCharacterCount() {
        if (!inputText || !characterCount || !errorMessage) {
            console.error('FRONTEND: Character count elements not found');
            return;
        }
        
        const length = inputText.value.length;
        const maxLength = isPremium ? MAX_PREMIUM_CHARS : MAX_FREE_CHARS;
        
        console.log('FRONTEND: Updating character count:', length, '/', maxLength);
        
        // Update character count display
        characterCount.textContent = `${length}/${maxLength} characters`;
        
        // Show error message if exceeding limit
        if (length > maxLength) {
            errorMessage.style.display = 'block';
            generateBtn.disabled = true;
        } else {
            errorMessage.style.display = 'none';
            generateBtn.disabled = false;
        }
    }
    
    function togglePersonalOptions() {
        if (!babyOptions || !petOptions) {
            console.error('FRONTEND: Personal options elements not found');
            return;
        }
        
        const selectedType = document.querySelector('input[name="personal-type"]:checked').value;
        console.log('FRONTEND: Toggling personal options for type:', selectedType);
        
        if (selectedType === 'baby') {
            babyOptions.classList.remove('hidden');
            petOptions.classList.add('hidden');
        } else if (selectedType === 'pet') {
            babyOptions.classList.add('hidden');
            petOptions.classList.remove('hidden');
        }
    }
    
    // Functions - Developer Tool
    function generateNames() {
        if (isGeneratingDeveloperNames) {
            console.log('FRONTEND: Already generating names, request ignored');
            return;
        }
        
        if (!inputText || !resultsList) {
            console.error('FRONTEND: Developer tool elements not found');
            return;
        }
        
        const input = inputText.value.trim();
        if (!input) {
            console.log('FRONTEND: Empty input, request ignored');
            return;
        }
        
        const maxLength = isPremium ? MAX_PREMIUM_CHARS : MAX_FREE_CHARS;
        if (input.length > maxLength) {
            console.log('FRONTEND: Input exceeds maximum length, request ignored');
            return;
        }
        
        const type = document.querySelector('input[name="input-type"]:checked').value;
        console.log('FRONTEND: Generating names for input:', input.substring(0, 50) + (input.length > 50 ? '...' : ''));
        console.log('FRONTEND: Input type:', type);
        
        // Show loading state
        resultsList.innerHTML = '<li class="loading">Generating names...</li>';
        resultsSection.style.display = 'block';
        isGeneratingDeveloperNames = true;
        
        // Prepare request body
        const requestBody = {
            input: input,
            type: type,
            isPremium: isPremium
        };
        
        console.log('FRONTEND: Sending request to generate names:', requestBody);
        
        // Send request to server
        fetch('/api/generate-names', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        })
            .then(response => {
                console.log('FRONTEND: Names response received, status:', response.status);
                
                // Check for rate limit error
                if (response.status === 429) {
                    // Display rate limit error in UI
                    displayRateLimitError(response);
                    throw new Error('Rate limit exceeded');
                }
                
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('FRONTEND: Names generated successfully:', data.names.length);
                displayNames(data.names);
            })
            .catch(error => {
                console.error('FRONTEND: Error generating names:', error);
                
                // Only show error if not a rate limit error (which is handled separately)
                if (error.message !== 'Rate limit exceeded') {
                    resultsList.innerHTML = '<li class="error">Error generating names. Please try again.</li>';
                }
            })
            .finally(() => {
                isGeneratingDeveloperNames = false;
            });
    }
    
    // Function to display rate limit error in UI
    function displayRateLimitError(response) {
        // Create error element
        const errorElement = document.createElement('div');
        errorElement.className = 'rate-limit-error';
        errorElement.innerHTML = `
            <p>Daily limit reached for free tier. Please upgrade to premium for unlimited requests.</p>
            <button class="btn upgrade-btn">Upgrade to Premium</button>
        `;
        
        // Insert error before the quote in the developer tool section
        const quoteElement = document.querySelector('#developer-tool .quote');
        if (quoteElement && quoteElement.parentNode) {
            quoteElement.parentNode.insertBefore(errorElement, quoteElement);
            
            // Scroll to error message
            errorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            // Add click handler for upgrade button
            const upgradeBtn = errorElement.querySelector('.upgrade-btn');
            if (upgradeBtn) {
                upgradeBtn.addEventListener('click', () => {
                    // Scroll to pricing section
                    document.getElementById('pricing').scrollIntoView({ behavior: 'smooth' });
                });
            }
        }
        
        // Clear results
        resultsList.innerHTML = '';
    }
    
    function displayNames(names) {
        if (!resultsList) {
            console.error('FRONTEND: Results list element not found');
            return;
        }
        
        console.log('FRONTEND: Displaying names:', names);
        
        // Clear previous results
        resultsList.innerHTML = '';
        
        // Add each name to the list
        names.forEach(name => {
            const li = document.createElement('li');
            li.textContent = name;
            li.addEventListener('click', () => {
                copyToClipboard(name);
                li.classList.add('copied');
                setTimeout(() => {
                    li.classList.remove('copied');
                }, 2000);
            });
            resultsList.appendChild(li);
        });
    }
    
    // Functions - Personal Names Tool
    function generatePersonalNames(fromDropdownChange) {
        // If this is triggered from a dropdown change, don't generate names
        if (fromDropdownChange) {
            console.log('FRONTEND: Ignoring name generation from dropdown change');
            return;
        }
        
        if (isGeneratingPersonalNames) {
            console.log('FRONTEND: Already generating personal names, request ignored');
            return;
        }
        
        console.log('FRONTEND: Generating personal names');
        
        // Get selected type and options
        const type = document.querySelector('input[name="personal-type"]:checked').value;
        let options = {};
        
        if (type === 'baby') {
            options = {
                gender: document.getElementById('gender-select').value,
                style: document.getElementById('style-select').value,
                origin: document.getElementById('origin-select').value
            };
        } else if (type === 'pet') {
            options = {
                gender: document.getElementById('pet-gender-select').value,
                style: document.getElementById('pet-style-select').value,
                theme: document.getElementById('pet-theme-select').value
            };
        }
        
        console.log('FRONTEND: Personal name type:', type);
        console.log('FRONTEND: Personal name options:', options);
        
        // Show loading state
        personalResultsList.innerHTML = '<li class="loading">Generating names...</li>';
        personalResultsSection.style.display = 'block';
        isGeneratingPersonalNames = true;
        
        // Prepare request body
        const requestBody = {
            type: type,
            options: options,
            isPremium: isPremium
        };
        
        console.log('FRONTEND: Sending request to generate personal names:', requestBody);
        
        // Send request to server
        fetch('/api/generate-personal-names', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        })
            .then(response => {
                console.log('FRONTEND: Personal names response received, status:', response.status);
                
                // Check for rate limit error
                if (response.status === 429) {
                    // Display rate limit error in UI
                    displayPersonalRateLimitError(response);
                    throw new Error('Rate limit exceeded');
                }
                
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('FRONTEND: Personal names generated successfully:', data.names.length);
                displayPersonalNames(data.names);
            })
            .catch(error => {
                console.error('FRONTEND: Error generating personal names:', error);
                
                // Only show error if not a rate limit error (which is handled separately)
                if (error.message !== 'Rate limit exceeded') {
                    personalResultsList.innerHTML = '<li class="error">Error generating names. Please try again.</li>';
                }
            })
            .finally(() => {
                isGeneratingPersonalNames = false;
            });
    }
    
    // Function to display rate limit error in UI for personal names
    function displayPersonalRateLimitError(response) {
        // Create error element
        const errorElement = document.createElement('div');
        errorElement.className = 'rate-limit-error';
        errorElement.innerHTML = `
            <p>Daily limit reached for free tier. Please upgrade to premium for unlimited requests.</p>
            <button class="btn upgrade-btn">Upgrade to Premium</button>
        `;
        
        // Insert error before the quote in the personal tool section
        const quoteElement = document.querySelector('#personal-tool .quote');
        if (quoteElement && quoteElement.parentNode) {
            quoteElement.parentNode.insertBefore(errorElement, quoteElement);
            
            // Scroll to error message
            errorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            // Add click handler for upgrade button
            const upgradeBtn = errorElement.querySelector('.upgrade-btn');
            if (upgradeBtn) {
                upgradeBtn.addEventListener('click', () => {
                    // Scroll to pricing section
                    document.getElementById('pricing').scrollIntoView({ behavior: 'smooth' });
                });
            }
        }
        
        // Clear results
        personalResultsList.innerHTML = '';
    }
    
    function displayPersonalNames(names) {
        if (!personalResultsList) {
            console.error('FRONTEND: Personal results list element not found');
            return;
        }
        
        console.log('FRONTEND: Displaying personal names:', names);
        
        // Clear previous results
        personalResultsList.innerHTML = '';
        
        // Add each name to the list
        names.forEach(name => {
            const li = document.createElement('li');
            li.textContent = name;
            li.addEventListener('click', () => {
                copyToClipboard(name);
                li.classList.add('copied');
                setTimeout(() => {
                    li.classList.remove('copied');
                }, 2000);
            });
            personalResultsList.appendChild(li);
        });
    }
    
    // Utility Functions
    function copyToClipboard(text) {
        console.log('FRONTEND: Copying to clipboard:', text);
        
        // Create a temporary textarea element
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.setAttribute('readonly', '');
        textarea.style.position = 'absolute';
        textarea.style.left = '-9999px';
        document.body.appendChild(textarea);
        
        // Select and copy the text
        textarea.select();
        document.execCommand('copy');
        
        // Remove the textarea
        document.body.removeChild(textarea);
        
        console.log('FRONTEND: Copied to clipboard successfully');
    }
    
    // AdSense Initialization - Only in production
    function initializeAds() {
        // Only initialize ads in production environment
        if (window.location.hostname === 'localhost' || 
            window.location.hostname === '127.0.0.1' ||
            window.location.hostname.includes('0.0.0.0')) {
            console.log('FRONTEND: Skipping ad initialization in development environment');
            return;
        }
        
        console.log('FRONTEND: Initializing ads');
        
        // Create and insert ad units
        const adContainers = document.querySelectorAll('.ad-container');
        adContainers.forEach((container, index) => {
            const adUnit = document.createElement('ins');
            adUnit.className = 'adsbygoogle';
            adUnit.style.display = 'block';
            adUnit.style.width = '100%';
            adUnit.style.height = '90px';
            adUnit.setAttribute('data-ad-client', 'ca-pub-YOUR_PUBLISHER_ID');
            adUnit.setAttribute('data-ad-slot', `YOUR_AD_SLOT_ID_${index + 1}`);
            adUnit.setAttribute('data-ad-format', 'auto');
            adUnit.setAttribute('data-full-width-responsive', 'true');
            
            container.appendChild(adUnit);
            
            // Push ad to queue
            (window.adsbygoogle = window.adsbygoogle || []).push({});
        });
    }
    
    // Initialize ads if in production
    initializeAds();
    
    // Add CSS class to body when JavaScript is enabled
    document.body.classList.add('js-enabled');
    
    // Log completion of initialization
    console.log('FRONTEND: Initialization complete');
