/**
 * Stripe Payment Integration
 * 
 * This file handles Stripe payment processing for premium and enterprise tiers
 */

// Stripe configuration
let stripeConfig = {
  publishableKey: 'pk_test_mockStripePublishableKey', // Replace with actual key in production
  priceIds: {
    premium: 'price_premium_monthly',
    enterprise: 'price_enterprise_monthly'
  }
};

// Stripe instance
let stripe;

// Initialize Stripe
function initStripe() {
  // Load Stripe.js script
  const script = document.createElement('script');
  script.src = 'https://js.stripe.com/v3/';
  script.async = true;
  script.onload = onStripeScriptLoad;
  document.head.appendChild(script);
}

// Handle Stripe script load
function onStripeScriptLoad() {
  // Initialize Stripe with publishable key
  stripe = Stripe(stripeConfig.publishableKey);
  
  // Check for payment success or cancel query parameters
  const urlParams = new URLSearchParams(window.location.search);
  const sessionId = urlParams.get('session_id');
  
  if (sessionId) {
    // Handle successful payment
    handlePaymentSuccess(sessionId);
  }
  
  // Initialize upgrade buttons
  initUpgradeButtons();
}

// Initialize upgrade buttons
function initUpgradeButtons() {
  const upgradeButtons = document.querySelectorAll('[data-tier]');
  
  upgradeButtons.forEach(button => {
    button.addEventListener('click', function(e) {
      e.preventDefault();
      
      const tier = this.getAttribute('data-tier');
      if (!tier || tier === 'free') return;
      
      // Check if user is logged in
      if (!isUserLoggedIn()) {
        // Redirect to login page
        window.location.href = '/login.html?redirect=pricing';
        return;
      }
      
      // Create checkout session
      createCheckoutSession(tier);
    });
  });
}

// Create Stripe checkout session
function createCheckoutSession(tier) {
  // Get session ID from localStorage
  const sessionId = localStorage.getItem('sessionId');
  
  if (!sessionId) {
    showError('You must be logged in to upgrade.');
    return;
  }
  
  // Show loading state
  showLoading(true);
  
  // Create checkout session on server
  fetch('/api/auth/create-checkout-session', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': sessionId
    },
    body: JSON.stringify({ tierName: tier })
  })
  .then(response => response.json())
  .then(data => {
    showLoading(false);
    
    if (data.error) {
      showError(data.error);
      return;
    }
    
    // Redirect to Stripe Checkout
    return stripe.redirectToCheckout({ sessionId: data.sessionId });
  })
  .then(result => {
    if (result && result.error) {
      showError(result.error.message);
    }
  })
  .catch(error => {
    showLoading(false);
    console.error('Checkout error:', error);
    showError('An error occurred while creating checkout session. Please try again.');
  });
}

// Handle successful payment
function handlePaymentSuccess(sessionId) {
  // Show success message
  const successElement = document.createElement('div');
  successElement.className = 'payment-success';
  successElement.innerHTML = `
    <div class="success-icon">✓</div>
    <h2>Payment Successful!</h2>
    <p>Your subscription has been activated. Thank you for your purchase!</p>
    <button class="btn" onclick="window.location.href='/'">Continue to Dashboard</button>
  `;
  
  // Add to page
  const mainContent = document.querySelector('main') || document.body;
  mainContent.innerHTML = '';
  mainContent.appendChild(successElement);
  
  // Update user profile
  updateUserProfile();
}

// Update user profile after successful payment
function updateUserProfile() {
  // Get session ID from localStorage
  const sessionId = localStorage.getItem('sessionId');
  
  if (!sessionId) return;
  
  // Fetch updated user profile
  fetch('/api/auth/profile', {
    headers: {
      'Authorization': sessionId
    }
  })
  .then(response => response.json())
  .then(data => {
    // Update current user data
    if (window.currentUser) {
      window.currentUser = data.user;
    }
    
    // Update UI if updateUIForLoggedInUser function exists
    if (typeof updateUIForLoggedInUser === 'function') {
      updateUIForLoggedInUser();
    }
  })
  .catch(error => {
    console.error('Profile update error:', error);
  });
}

// Get subscription details
function getSubscriptionDetails() {
  // Get session ID from localStorage
  const sessionId = localStorage.getItem('sessionId');
  
  if (!sessionId) return Promise.reject('Not logged in');
  
  // Fetch subscription details
  return fetch('/api/auth/subscription', {
    headers: {
      'Authorization': sessionId
    }
  })
  .then(response => response.json())
  .then(data => {
    if (data.error) {
      throw new Error(data.error);
    }
    
    return data.subscription;
  });
}

// Cancel subscription
function cancelSubscription(subscriptionId) {
  // Get session ID from localStorage
  const sessionId = localStorage.getItem('sessionId');
  
  if (!sessionId) {
    showError('You must be logged in to cancel your subscription.');
    return Promise.reject('Not logged in');
  }
  
  // Show loading state
  showLoading(true);
  
  // Cancel subscription on server
  return fetch('/api/auth/cancel-subscription', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': sessionId
    },
    body: JSON.stringify({ subscriptionId })
  })
  .then(response => response.json())
  .then(data => {
    showLoading(false);
    
    if (data.error) {
      showError(data.error);
      throw new Error(data.error);
    }
    
    // Show success message
    showSuccess('Your subscription has been cancelled. You will be downgraded to the free plan at the end of your billing period.');
    
    // Update user profile
    updateUserProfile();
    
    return data;
  })
  .catch(error => {
    showLoading(false);
    console.error('Subscription cancellation error:', error);
    showError('An error occurred while cancelling your subscription. Please try again.');
    throw error;
  });
}

// Check if user is logged in
function isUserLoggedIn() {
  return !!localStorage.getItem('sessionId');
}

// Show loading state
function showLoading(isLoading) {
  // Create or get loading element
  let loadingElement = document.querySelector('.payment-loading');
  
  if (!loadingElement && isLoading) {
    loadingElement = document.createElement('div');
    loadingElement.className = 'payment-loading';
    loadingElement.innerHTML = '<div class="spinner"></div><p>Processing payment...</p>';
    document.body.appendChild(loadingElement);
  }
  
  if (loadingElement) {
    loadingElement.style.display = isLoading ? 'flex' : 'none';
  }
}

// Show error message
function showError(message) {
  // Create toast notification
  const toast = document.createElement('div');
  toast.className = 'toast toast-error';
  toast.textContent = message;
  
  // Add to page
  document.body.appendChild(toast);
  
  // Show toast
  setTimeout(() => {
    toast.classList.add('show');
  }, 100);
  
  // Remove after 5 seconds
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => {
      document.body.removeChild(toast);
    }, 300);
  }, 5000);
}

// Show success message
function showSuccess(message) {
  // Create toast notification
  const toast = document.createElement('div');
  toast.className = 'toast toast-success';
  toast.textContent = message;
  
  // Add to page
  document.body.appendChild(toast);
  
  // Show toast
  setTimeout(() => {
    toast.classList.add('show');
  }, 100);
  
  // Remove after 5 seconds
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => {
      document.body.removeChild(toast);
    }, 300);
  }, 5000);
}

// Initialize Stripe when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  // Initialize Stripe
  initStripe();
});
