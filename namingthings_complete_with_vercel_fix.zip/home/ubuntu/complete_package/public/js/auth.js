/**
 * Authentication and User Management JavaScript
 * 
 * This file handles user authentication, registration, Google login,
 * and user profile management
 */

// DOM Elements
let loginForm;
let registerForm;
let googleLoginBtn;
let logoutBtn;
let userProfileSection;
let userNameDisplay;
let userEmailDisplay;
let userTierDisplay;
let upgradeButtons;

// Current user session data
let currentUser = null;
let sessionId = null;

// Initialize authentication functionality
document.addEventListener('DOMContentLoaded', function() {
    // Check for existing session
    checkExistingSession();
    
    // Initialize auth forms
    initAuthForms();
    
    // Initialize Google login
    initGoogleLogin();
    
    // Initialize upgrade buttons
    initUpgradeButtons();
});

// Check for existing session in localStorage
function checkExistingSession() {
    sessionId = localStorage.getItem('sessionId');
    
    if (sessionId) {
        // Validate session with server
        fetch('/api/auth/profile', {
            headers: {
                'Authorization': sessionId
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Session invalid');
            }
            return response.json();
        })
        .then(data => {
            // Set current user and update UI
            currentUser = data.user;
            updateUIForLoggedInUser();
        })
        .catch(error => {
            console.error('Session validation error:', error);
            // Clear invalid session
            localStorage.removeItem('sessionId');
            sessionId = null;
        });
    } else {
        updateUIForLoggedOutUser();
    }
}

// Initialize authentication forms
function initAuthForms() {
    loginForm = document.getElementById('login-form');
    registerForm = document.getElementById('register-form');
    
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
    
    // Get logout button
    logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
}

// Initialize Google login
function initGoogleLogin() {
    googleLoginBtn = document.getElementById('google-login-btn');
    
    if (googleLoginBtn) {
        googleLoginBtn.addEventListener('click', handleGoogleLogin);
    }
    
    // Load Google Sign-In API
    loadGoogleSignInAPI();
}

// Load Google Sign-In API
function loadGoogleSignInAPI() {
    // In a real implementation, this would load the Google Sign-In API
    console.log('Loading Google Sign-In API...');
    
    // Mock implementation for demo purposes
    window.onGoogleSignInApiLoaded = function() {
        console.log('Google Sign-In API loaded');
        
        // Initialize Google Sign-In
        window.initGoogleSignIn = function() {
            console.log('Google Sign-In initialized');
        };
        
        // Mock Google Sign-In function
        window.googleSignIn = function() {
            // This would normally be handled by Google's API
            const mockGoogleUser = {
                email: 'user@example.com',
                name: 'Example User',
                googleId: 'google_' + Math.random().toString(36).substr(2, 9)
            };
            
            handleGoogleAuthResponse(mockGoogleUser);
        };
    };
    
    // Simulate API loading
    setTimeout(function() {
        if (typeof window.onGoogleSignInApiLoaded === 'function') {
            window.onGoogleSignInApiLoaded();
        }
    }, 1000);
}

// Initialize upgrade buttons
function initUpgradeButtons() {
    upgradeButtons = document.querySelectorAll('.upgrade-btn');
    
    if (upgradeButtons) {
        upgradeButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                const tier = this.getAttribute('data-tier');
                if (tier) {
                    handleUpgrade(tier);
                }
            });
        });
    }
}

// Handle login form submission
function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    // Validate inputs
    if (!email || !password) {
        showAuthError('Please enter both email and password');
        return;
    }
    
    // Send login request to server
    fetch('/api/auth/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            showAuthError(data.error);
            return;
        }
        
        // Store session and user data
        sessionId = data.sessionId;
        currentUser = data.user;
        
        // Save session to localStorage
        localStorage.setItem('sessionId', sessionId);
        
        // Update UI
        updateUIForLoggedInUser();
        
        // Redirect to home page
        window.location.href = '/';
    })
    .catch(error => {
        console.error('Login error:', error);
        showAuthError('An error occurred during login. Please try again.');
    });
}

// Handle register form submission
function handleRegister(e) {
    e.preventDefault();
    
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;
    
    // Validate inputs
    if (!name || !email || !password || !confirmPassword) {
        showAuthError('Please fill in all fields');
        return;
    }
    
    if (password !== confirmPassword) {
        showAuthError('Passwords do not match');
        return;
    }
    
    // Send register request to server
    fetch('/api/auth/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, email, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            showAuthError(data.error);
            return;
        }
        
        // Show success message
        showAuthSuccess('Registration successful! Please log in.');
        
        // Redirect to login page
        setTimeout(() => {
            window.location.href = '/login.html';
        }, 2000);
    })
    .catch(error => {
        console.error('Registration error:', error);
        showAuthError('An error occurred during registration. Please try again.');
    });
}

// Handle Google login button click
function handleGoogleLogin() {
    // In a real implementation, this would trigger Google's OAuth flow
    console.log('Initiating Google login...');
    
    // Call mock Google Sign-In function
    if (typeof window.googleSignIn === 'function') {
        window.googleSignIn();
    } else {
        showAuthError('Google Sign-In is not available. Please try again later.');
    }
}

// Handle Google authentication response
function handleGoogleAuthResponse(googleUserData) {
    // Send Google user data to server
    fetch('/api/auth/google', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ googleUserData })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            showAuthError(data.error);
            return;
        }
        
        // Store session and user data
        sessionId = data.sessionId;
        currentUser = data.user;
        
        // Save session to localStorage
        localStorage.setItem('sessionId', sessionId);
        
        // Update UI
        updateUIForLoggedInUser();
        
        // Redirect to home page
        window.location.href = '/';
    })
    .catch(error => {
        console.error('Google authentication error:', error);
        showAuthError('An error occurred during Google authentication. Please try again.');
    });
}

// Handle logout button click
function handleLogout() {
    // Send logout request to server
    fetch('/api/auth/logout', {
        method: 'POST',
        headers: {
            'Authorization': sessionId
        }
    })
    .then(response => response.json())
    .then(data => {
        // Clear session and user data
        localStorage.removeItem('sessionId');
        sessionId = null;
        currentUser = null;
        
        // Update UI
        updateUIForLoggedOutUser();
        
        // Redirect to home page
        window.location.href = '/';
    })
    .catch(error => {
        console.error('Logout error:', error);
        // Force logout on client side even if server request fails
        localStorage.removeItem('sessionId');
        sessionId = null;
        currentUser = null;
        updateUIForLoggedOutUser();
        window.location.href = '/';
    });
}

// Handle upgrade button click
function handleUpgrade(tier) {
    // Check if user is logged in
    if (!sessionId) {
        // Redirect to login page
        window.location.href = '/login.html?redirect=pricing';
        return;
    }
    
    // Create checkout session
    fetch('/api/auth/create-checkout-session', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': sessionId
        },
        body: JSON.stringify({ tierName: tier })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert('Error: ' + data.error);
            return;
        }
        
        // Redirect to Stripe checkout
        window.location.href = data.checkoutUrl;
    })
    .catch(error => {
        console.error('Checkout error:', error);
        alert('An error occurred while creating checkout session. Please try again.');
    });
}

// Update UI for logged in user
function updateUIForLoggedInUser() {
    // Get user profile elements
    userProfileSection = document.getElementById('user-profile');
    userNameDisplay = document.getElementById('user-name');
    userEmailDisplay = document.getElementById('user-email');
    userTierDisplay = document.getElementById('user-tier');
    
    // Update navigation
    const authNav = document.getElementById('auth-nav');
    const userNav = document.getElementById('user-nav');
    
    if (authNav) authNav.style.display = 'none';
    if (userNav) {
        userNav.style.display = 'flex';
        
        // Update user name in nav
        const userNavName = document.getElementById('user-nav-name');
        if (userNavName && currentUser) {
            userNavName.textContent = currentUser.name;
        }
    }
    
    // Update user profile section if available
    if (userProfileSection && currentUser) {
        userProfileSection.style.display = 'block';
        
        if (userNameDisplay) userNameDisplay.textContent = currentUser.name;
        if (userEmailDisplay) userEmailDisplay.textContent = currentUser.email;
        if (userTierDisplay) {
            userTierDisplay.textContent = currentUser.tier.charAt(0).toUpperCase() + currentUser.tier.slice(1);
            
            // Add tier badge
            userTierDisplay.innerHTML += `<span class="tier-badge ${currentUser.tier}">${currentUser.tier}</span>`;
        }
    }
    
    // Update pricing page buttons if on pricing page
    updatePricingPageForUser();
}

// Update UI for logged out user
function updateUIForLoggedOutUser() {
    // Update navigation
    const authNav = document.getElementById('auth-nav');
    const userNav = document.getElementById('user-nav');
    
    if (authNav) authNav.style.display = 'flex';
    if (userNav) userNav.style.display = 'none';
    
    // Hide user profile section
    userProfileSection = document.getElementById('user-profile');
    if (userProfileSection) {
        userProfileSection.style.display = 'none';
    }
    
    // Update pricing page buttons if on pricing page
    updatePricingPageForUser();
}

// Update pricing page for current user
function updatePricingPageForUser() {
    const pricingPlans = document.querySelectorAll('.pricing-plan');
    
    if (!pricingPlans.length) return; // Not on pricing page
    
    pricingPlans.forEach(plan => {
        const tierName = plan.getAttribute('data-tier');
        const actionButton = plan.querySelector('.btn');
        
        if (!tierName || !actionButton) return;
        
        if (currentUser) {
            // User is logged in
            if (tierName === currentUser.tier) {
                // Current tier
                actionButton.textContent = 'Current Plan';
                actionButton.classList.remove('btn-primary');
                actionButton.classList.add('btn-outline');
                actionButton.removeAttribute('data-tier');
            } else if (tierName === 'free') {
                // Free tier (downgrade)
                actionButton.textContent = 'Downgrade';
                actionButton.classList.remove('btn-primary');
                actionButton.classList.add('btn-outline');
                actionButton.setAttribute('data-tier', tierName);
            } else {
                // Upgrade tier
                actionButton.textContent = 'Upgrade';
                actionButton.classList.add('btn-primary');
                actionButton.classList.remove('btn-outline');
                actionButton.setAttribute('data-tier', tierName);
            }
        } else {
            // User is not logged in
            if (tierName === 'free') {
                actionButton.textContent = 'Current Plan';
                actionButton.classList.remove('btn-primary');
                actionButton.classList.add('btn-outline');
                actionButton.removeAttribute('data-tier');
            } else {
                actionButton.textContent = 'Sign Up';
                actionButton.classList.add('btn-primary');
                actionButton.classList.remove('btn-outline');
                actionButton.setAttribute('data-tier', tierName);
            }
        }
    });
}

// Show authentication error message
function showAuthError(message) {
    const errorElement = document.querySelector('.auth-error');
    
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
        
        // Hide after 5 seconds
        setTimeout(() => {
            errorElement.style.display = 'none';
        }, 5000);
    } else {
        // Fallback to alert if error element not found
        alert('Error: ' + message);
    }
}

// Show authentication success message
function showAuthSuccess(message) {
    const successElement = document.querySelector('.auth-success');
    
    if (successElement) {
        successElement.textContent = message;
        successElement.style.display = 'block';
        
        // Hide after 5 seconds
        setTimeout(() => {
            successElement.style.display = 'none';
        }, 5000);
    } else {
        // Fallback to alert if success element not found
        alert(message);
    }
}
