/**
 * Google Authentication Integration
 * 
 * This file handles Google Sign-In integration for the application
 */

// Google OAuth configuration
const googleConfig = {
  clientId: '123456789012-abcdefghijklmnopqrstuvwxyz123456.apps.googleusercontent.com', // Replace with actual client ID in production
  scope: 'profile email',
  cookiePolicy: 'single_host_origin'
};

// Initialize Google Sign-In
function initGoogleAuth() {
  // Load the Google Sign-In API script
  const script = document.createElement('script');
  script.src = 'https://apis.google.com/js/platform.js';
  script.async = true;
  script.defer = true;
  script.onload = onGoogleScriptLoad;
  document.head.appendChild(script);
}

// Handle Google script load
function onGoogleScriptLoad() {
  // Initialize Google Sign-In
  gapi.load('auth2', () => {
    const auth2 = gapi.auth2.init({
      client_id: googleConfig.clientId,
      cookiepolicy: googleConfig.cookiePolicy,
      scope: googleConfig.scope
    });
    
    // Attach Google Sign-In to buttons
    attachSignin(document.getElementById('google-login-btn'));
    
    // Check if user is already signed in
    if (auth2.isSignedIn.get()) {
      const googleUser = auth2.currentUser.get();
      handleGoogleUser(googleUser);
    }
  });
}

// Attach Google Sign-In to button
function attachSignin(element) {
  if (!element) return;
  
  gapi.auth2.getAuthInstance().attachClickHandler(element, {},
    (googleUser) => {
      // Handle successful sign-in
      handleGoogleUser(googleUser);
    },
    (error) => {
      // Handle sign-in error
      console.error('Google Sign-In error:', error);
      showAuthError('Google Sign-In failed. Please try again.');
    }
  );
}

// Handle Google user data
function handleGoogleUser(googleUser) {
  // Get user profile information
  const profile = googleUser.getBasicProfile();
  
  // Create user data object
  const userData = {
    googleId: profile.getId(),
    name: profile.getName(),
    email: profile.getEmail(),
    imageUrl: profile.getImageUrl()
  };
  
  // Send to server for authentication
  authenticateWithGoogle(userData);
}

// Authenticate with Google on server
function authenticateWithGoogle(userData) {
  fetch('/api/auth/google', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ googleUserData: userData })
  })
  .then(response => response.json())
  .then(data => {
    if (data.error) {
      showAuthError(data.error);
      return;
    }
    
    // Store session and user data
    sessionId = data.sessionId;
    currentUser = data.user;
    
    // Save session to localStorage
    localStorage.setItem('sessionId', sessionId);
    
    // Update UI
    updateUIForLoggedInUser();
    
    // Redirect to home page
    window.location.href = '/';
  })
  .catch(error => {
    console.error('Google authentication error:', error);
    showAuthError('An error occurred during Google authentication. Please try again.');
  });
}

// Sign out from Google
function signOutFromGoogle() {
  const auth2 = gapi.auth2.getAuthInstance();
  if (auth2) {
    auth2.signOut().then(() => {
      console.log('User signed out from Google.');
    });
  }
}

// Initialize Google Auth when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  // Initialize Google Auth
  initGoogleAuth();
  
  // Add event listener for logout to also sign out from Google
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', function() {
      // Sign out from Google before regular logout
      signOutFromGoogle();
    });
  }
});
