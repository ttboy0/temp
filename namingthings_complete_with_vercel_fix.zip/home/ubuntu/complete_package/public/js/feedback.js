/**
 * JavaScript for feedback functionality
 * This file adds feedback buttons to the name results
 */

document.addEventListener('DOMContentLoaded', function() {
    // Link the feedback CSS
    const feedbackCssLink = document.createElement('link');
    feedbackCssLink.rel = 'stylesheet';
    feedbackCssLink.href = 'css/feedback.css';
    document.head.appendChild(feedbackCssLink);
    
    // Initialize feedback system
    initFeedbackSystem();
});

// Initialize the feedback system
function initFeedbackSystem() {
    // Override the displayResults function to include feedback buttons
    if (typeof window.originalDisplayResults === 'undefined') {
        window.originalDisplayResults = window.displayResults;
        
        window.displayResults = function(names) {
            // Call the original function first
            window.originalDisplayResults(names);
            
            // Then add feedback buttons to each name
            addFeedbackButtonsToResults('results-list', 'developer');
        };
    }
    
    // Override the displayPersonalResults function to include feedback buttons
    if (typeof window.originalDisplayPersonalResults === 'undefined') {
        window.originalDisplayPersonalResults = window.displayPersonalResults;
        
        window.displayPersonalResults = function(names) {
            // Call the original function first
            window.originalDisplayPersonalResults(names);
            
            // Then add feedback buttons to each name
            addFeedbackButtonsToResults('personal-results-list', 'personal');
        };
    }
    
    // Add global event listener for feedback form submissions
    document.addEventListener('click', function(e) {
        if (e.target && e.target.classList.contains('submit-feedback')) {
            e.preventDefault();
            submitFeedback(e.target);
        }
    });
}

// Add feedback buttons to results
function addFeedbackButtonsToResults(listId, nameType) {
    const resultsList = document.getElementById(listId);
    if (!resultsList) return;
    
    const items = resultsList.querySelectorAll('li');
    items.forEach((item, index) => {
        // Skip if already has feedback button
        if (item.querySelector('.feedback-btn')) return;
        
        // Get the name text
        const nameText = item.textContent.trim();
        
        // Create feedback button
        const feedbackBtn = document.createElement('button');
        feedbackBtn.className = 'feedback-btn';
        feedbackBtn.innerHTML = '<i class="fas fa-star"></i> Rate';
        feedbackBtn.setAttribute('data-name', nameText);
        feedbackBtn.setAttribute('data-type', nameType);
        feedbackBtn.setAttribute('data-index', index);
        
        // Create name actions container if it doesn't exist
        let actionsContainer = item.querySelector('.name-actions');
        if (!actionsContainer) {
            // Convert the li to a structured format
            const nameTextSpan = document.createElement('span');
            nameTextSpan.className = 'name-text';
            nameTextSpan.textContent = nameText;
            nameTextSpan.onclick = function() {
                copyToClipboard(nameText);
            };
            
            actionsContainer = document.createElement('div');
            actionsContainer.className = 'name-actions';
            
            // Clear the item and add the new structure
            item.textContent = '';
            item.className = 'name-item';
            item.appendChild(nameTextSpan);
            item.appendChild(actionsContainer);
        }
        
        // Add feedback button to actions
        actionsContainer.appendChild(feedbackBtn);
        
        // Add click event to show feedback form
        feedbackBtn.addEventListener('click', function() {
            showFeedbackForm(this);
        });
    });
}

// Show feedback form for a name
function showFeedbackForm(button) {
    // Remove any existing open feedback forms
    const existingForms = document.querySelectorAll('.feedback-form.show');
    existingForms.forEach(form => {
        form.classList.remove('show');
    });
    
    // Get data attributes
    const name = button.getAttribute('data-name');
    const type = button.getAttribute('data-type');
    const nameItem = button.closest('.name-item');
    
    // Check if form already exists
    let feedbackForm = nameItem.querySelector('.feedback-form');
    
    if (!feedbackForm) {
        // Create feedback form
        feedbackForm = document.createElement('div');
        feedbackForm.className = 'feedback-form';
        feedbackForm.innerHTML = `
            <div class="feedback-container">
                <span>Rate this name:</span>
                <div class="star-rating">
                    <input type="radio" id="star5-${name}" name="rating-${name}" value="5" />
                    <label for="star5-${name}">★</label>
                    <input type="radio" id="star4-${name}" name="rating-${name}" value="4" />
                    <label for="star4-${name}">★</label>
                    <input type="radio" id="star3-${name}" name="rating-${name}" value="3" />
                    <label for="star3-${name}">★</label>
                    <input type="radio" id="star2-${name}" name="rating-${name}" value="2" />
                    <label for="star2-${name}">★</label>
                    <input type="radio" id="star1-${name}" name="rating-${name}" value="1" />
                    <label for="star1-${name}">★</label>
                </div>
                <button class="submit-feedback" data-name="${name}" data-type="${type}">Submit</button>
                <span class="feedback-message">Thank you for your feedback!</span>
            </div>
        `;
        
        // Add form to name item
        nameItem.appendChild(feedbackForm);
    }
    
    // Show the form
    feedbackForm.classList.add('show');
}

// Submit feedback to the server
function submitFeedback(button) {
    const name = button.getAttribute('data-name');
    const type = button.getAttribute('data-type');
    const nameItem = button.closest('.name-item');
    const feedbackForm = nameItem.querySelector('.feedback-form');
    
    // Get selected rating
    const selectedRating = feedbackForm.querySelector(`input[name="rating-${name}"]:checked`);
    if (!selectedRating) {
        alert('Please select a rating');
        return;
    }
    
    const rating = parseInt(selectedRating.value);
    
    // Get additional metadata based on type
    let metadata = {};
    
    if (type === 'personal') {
        // For personal names, get gender, style, origin/theme
        const personalType = document.querySelector('input[name="personal-type"]:checked').value;
        
        if (personalType === 'baby') {
            metadata = {
                gender: document.getElementById('gender-select').value,
                style: document.getElementById('style-select').value,
                origin: document.getElementById('origin-select').value
            };
        } else { // pet
            metadata = {
                gender: document.getElementById('pet-gender-select').value,
                style: document.getElementById('pet-style-select').value,
                theme: document.getElementById('pet-theme-select').value
            };
        }
        
        metadata.subtype = personalType;
    } else { // developer
        // For developer names, get input type
        metadata = {
            inputType: document.querySelector('input[name="input-type"]:checked').value
        };
    }
    
    // Prepare feedback data
    const feedbackData = {
        name: name,
        rating: rating,
        type: type,
        ...metadata,
        timestamp: Date.now()
    };
    
    // Send feedback to server
    fetch('/api/feedback', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(feedbackData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        // Show success message
        const feedbackMessage = feedbackForm.querySelector('.feedback-message');
        feedbackMessage.classList.add('show');
        
        // Hide message after 3 seconds
        setTimeout(() => {
            feedbackMessage.classList.remove('show');
            // Hide form after message fades
            setTimeout(() => {
                feedbackForm.classList.remove('show');
            }, 300);
        }, 3000);
    })
    .catch(error => {
        console.error('Error submitting feedback:', error);
        alert('Failed to submit feedback. Please try again.');
    });
}
