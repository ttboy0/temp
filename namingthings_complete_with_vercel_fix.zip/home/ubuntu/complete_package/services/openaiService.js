const { OpenAI } = require('openai');
const fs = require('fs');
const path = require('path');

// Create logs directory if it doesn't exist
const logsDir = path.join(__dirname, '..', 'logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

// Create log file stream
const logStream = fs.createWriteStream(path.join(logsDir, 'openai-service.log'), { flags: 'a' });

// Helper function to log messages to both console and file
function logMessage(message) {
  const timestamp = new Date().toISOString();
  const logEntry = `[${timestamp}] ${message}`;
  console.log(logEntry);
  logStream.write(logEntry + '\n');
}

class OpenAIService {
  constructor(apiKey) {
    logMessage('OPENAI_SERVICE: Initializing OpenAI service');
    
    this.apiKey = apiKey || process.env.OPENAI_API_KEY;
    
    // Check if API key exists
    if (!this.apiKey) {
      logMessage('OPENAI_SERVICE: ERROR - OpenAI API key not found');
      throw new Error('OpenAI API key not found');
    }
    
    this.openai = new OpenAI({
      apiKey: this.apiKey
    });
    this.model = process.env.OPENAI_MODEL || "gpt-3.5-turbo";
    this.initialized = true;
    
    logMessage(`OPENAI_SERVICE: Initialized with model: ${this.model}`);
  }

  isInitialized() {
    return this.initialized;
  }
  
  async checkStatus() {
    try {
      logMessage('OPENAI_SERVICE: Checking OpenAI service status');
      
      // Simple models list request to check if API is accessible
      await this.openai.models.list();
      
      logMessage('OPENAI_SERVICE: Status check successful - OpenAI API is accessible');
      
      return {
        available: true,
        model: this.model,
        message: 'OpenAI API is accessible'
      };
    } catch (error) {
      logMessage(`OPENAI_SERVICE: Status check failed - ${error.message}`);
      
      return {
        available: false,
        model: this.model,
        message: error.message
      };
    }
  }

  async generateNames(input, type, numSuggestions = 10, seed = Math.random()) {
    logMessage(`OPENAI_SERVICE: Generating names for input: "${input}"`);
    logMessage(`OPENAI_SERVICE: Type: ${type}, Count: ${numSuggestions}, Seed: ${seed}`);
    
    try {
      // Create a prompt based on the input type
      let prompt;
      if (type === 'description') {
        prompt = `You are a senior developer helping to name functions. Generate ${numSuggestions} function names for this description: "${input}". 
        Return only the function names in camelCase format, one per line, with no additional text or explanation.`;
      } else { // code snippet
        prompt = `You are a senior developer helping to name functions. Generate ${numSuggestions} function names for this code:
        \`\`\`
        ${input}
        \`\`\`
        Return only the function names in camelCase format, one per line, with no additional text or explanation.`;
      }
      
      logMessage(`OPENAI_SERVICE: Sending prompt to OpenAI API: ${prompt}`);
      
      // Use seed to adjust temperature for variation
      const seedBasedTemperature = 0.5 + (seed * 0.5); // Range from 0.5 to 1.0
      
      // Generate text using OpenAI
      const completion = await this.openai.chat.completions.create({
        model: this.model,
        messages: [
          { role: "system", content: "You are a helpful assistant that generates function names for developers." },
          { role: "user", content: prompt }
        ],
        temperature: seedBasedTemperature,
        max_tokens: 150,
        seed: Math.floor(seed * 1000000) // Convert seed to integer for OpenAI
      });
      
      logMessage(`OPENAI_SERVICE: Received response from OpenAI API: ${JSON.stringify(completion)}`);
      
      // Extract function names from the generated text
      const generatedText = completion.choices[0].message.content;
      logMessage(`OPENAI_SERVICE: Raw content from OpenAI: ${generatedText}`);
      
      const names = generatedText
        .split('\n')
        .map(name => name.trim())
        .filter(name => name.length > 0)
        .slice(0, numSuggestions);
      
      logMessage(`OPENAI_SERVICE: Parsed ${names.length} names from response: ${JSON.stringify(names)}`);
      
      return names;
    } catch (error) {
      logMessage(`OPENAI_SERVICE: Error generating names - ${error.message}`);
      console.error('OpenAI service error:', error);
      throw new Error('Failed to generate names with OpenAI: ' + error.message);
    }
  }
  
  async generatePersonalNames(type, options, numSuggestions = 10) {
    logMessage(`OPENAI_SERVICE: Generating personal names of type: ${type}`);
    logMessage(`OPENAI_SERVICE: Options: ${JSON.stringify(options)}, Count: ${numSuggestions}`);
    
    try {
      // Construct prompt based on name type and options
      let prompt;
      if (type === 'baby') {
        prompt = `You are a helpful assistant providing baby name suggestions.
        Please suggest ${numSuggestions} ${options.gender} baby names with ${options.style} style 
        ${options.origin !== 'any' ? `from ${options.origin} origin` : ''}.
        Only provide the names, one per line, without any additional explanation.`;
      } else {
        prompt = `You are a helpful assistant providing pet name suggestions.
        Please suggest ${numSuggestions} ${options.gender !== 'any' ? options.gender : ''} pet names with ${options.style} style 
        ${options.theme !== 'any' ? `with a ${options.theme} theme` : ''}.
        Only provide the names, one per line, without any additional explanation.`;
      }
      
      logMessage(`OPENAI_SERVICE: Sending prompt to OpenAI API: ${prompt}`);
      
      // Generate text using OpenAI
      const completion = await this.openai.chat.completions.create({
        model: this.model,
        messages: [
          { role: "system", content: "You are a helpful assistant that suggests baby and pet names." },
          { role: "user", content: prompt }
        ],
        temperature: 0.8,
        max_tokens: 150
      });
      
      logMessage(`OPENAI_SERVICE: Received response from OpenAI API: ${JSON.stringify(completion)}`);
      
      // Extract names from the generated text
      const generatedText = completion.choices[0].message.content;
      logMessage(`OPENAI_SERVICE: Raw content from OpenAI: ${generatedText}`);
      
      const names = generatedText
        .split('\n')
        .map(name => name.trim())
        .filter(name => name.length > 0)
        .map(name => {
          // Remove any numbering or bullet points
          return name.replace(/^\d+[\.\)]\s*/, '').replace(/^-\s*/, '');
        })
        .slice(0, numSuggestions);
      
      logMessage(`OPENAI_SERVICE: Parsed ${names.length} personal names from response: ${JSON.stringify(names)}`);
      
      return names;
    } catch (error) {
      logMessage(`OPENAI_SERVICE: Error generating personal names - ${error.message}`);
      console.error('OpenAI service error:', error);
      throw new Error('Failed to generate personal names with OpenAI: ' + error.message);
    }
  }
}

module.exports = OpenAIService;
