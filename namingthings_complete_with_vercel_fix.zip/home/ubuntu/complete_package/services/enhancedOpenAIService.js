/**
 * Enhanced OpenAI Service with GPT-4 support and comprehensive logging
 * This service provides integration with OpenAI's GPT-4 model for improved name generation
 */

const { OpenAI } = require('openai');
const fs = require('fs');
const path = require('path');

// Create logs directory if it doesn't exist
const logsDir = path.join(__dirname, '..', 'logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

// Create log file stream
const logStream = fs.createWriteStream(path.join(logsDir, 'enhanced-openai-service.log'), { flags: 'a' });

// Helper function to log messages to both console and file
function logMessage(message) {
  const timestamp = new Date().toISOString();
  const logEntry = `[${timestamp}] ${message}`;
  console.log(logEntry);
  logStream.write(logEntry + '\n');
}

class EnhancedOpenAIService {
  constructor(apiKey) {
    logMessage('ENHANCED_OPENAI_SERVICE: Initializing Enhanced OpenAI service');
    
    this.apiKey = apiKey || process.env.OPENAI_API_KEY;
    
    // Check if API key exists
    if (!this.apiKey) {
      logMessage('ENHANCED_OPENAI_SERVICE: ERROR - OpenAI API key not found');
      throw new Error('OpenAI API key not found');
    }
    
    this.openai = new OpenAI({
      apiKey: this.apiKey
    });
    this.initialized = !!this.apiKey;
    this.modelName = process.env.OPENAI_MODEL || 'gpt-3.5-turbo'; // Default to GPT-3.5 if not specified
    
    logMessage(`ENHANCED_OPENAI_SERVICE: Initialized with model: ${this.modelName}`);
  }

  isInitialized() {
    return this.initialized;
  }

  isGPT4Available() {
    return this.initialized && this.modelName.includes('gpt-4');
  }
  
  async checkStatus() {
    try {
      logMessage('ENHANCED_OPENAI_SERVICE: Checking Enhanced OpenAI service status');
      
      // Simple models list request to check if API is accessible
      await this.openai.models.list();
      
      logMessage('ENHANCED_OPENAI_SERVICE: Status check successful - OpenAI API is accessible');
      
      return {
        available: true,
        model: this.modelName,
        message: 'OpenAI API is accessible',
        enhanced: true
      };
    } catch (error) {
      logMessage(`ENHANCED_OPENAI_SERVICE: Status check failed - ${error.message}`);
      
      return {
        available: false,
        model: this.modelName,
        message: error.message,
        enhanced: true
      };
    }
  }

  async generateNames(input, type, numSuggestions = 10, seed = Math.random()) {
    logMessage(`ENHANCED_OPENAI_SERVICE: Generating names for input: "${input}"`);
    logMessage(`ENHANCED_OPENAI_SERVICE: Type: ${type}, Count: ${numSuggestions}, Seed: ${seed}`);
    
    if (!this.initialized) {
      logMessage('ENHANCED_OPENAI_SERVICE: ERROR - OpenAI service is not initialized with a valid API key');
      throw new Error('OpenAI service is not initialized with a valid API key');
    }

    try {
      // Create a prompt based on the input type
      let prompt;
      if (type === 'description') {
        prompt = `You are a senior developer helping to name functions. Generate ${numSuggestions} function names for this description: "${input}". 
        Return only the function names in camelCase format, one per line, with no additional text or explanation.`;
      } else { // code snippet
        prompt = `You are a senior developer helping to name functions. Generate ${numSuggestions} function names for this code:
        \`\`\`
        ${input}
        \`\`\`
        Return only the function names in camelCase format, one per line, with no additional text or explanation.`;
      }
      
      logMessage(`ENHANCED_OPENAI_SERVICE: Sending prompt to OpenAI API: ${prompt}`);
      
      // Use seed to adjust temperature for variation
      const seedBasedTemperature = 0.5 + (seed * 0.5); // Range from 0.5 to 1.0
      
      // Generate text using OpenAI
      const completion = await this.openai.chat.completions.create({
        model: this.modelName,
        messages: [
          { role: "system", content: "You are a helpful assistant that generates function names for developers." },
          { role: "user", content: prompt }
        ],
        temperature: seedBasedTemperature,
        max_tokens: 150,
        seed: Math.floor(seed * 1000000) // Convert seed to integer for OpenAI
      });
      
      logMessage(`ENHANCED_OPENAI_SERVICE: Received response from OpenAI API: ${JSON.stringify(completion)}`);
      
      // Extract function names from the generated text
      const generatedText = completion.choices[0].message.content;
      logMessage(`ENHANCED_OPENAI_SERVICE: Raw content from OpenAI: ${generatedText}`);
      
      const names = generatedText
        .split('\n')
        .map(name => name.trim())
        .filter(name => name.length > 0)
        .slice(0, numSuggestions);
      
      logMessage(`ENHANCED_OPENAI_SERVICE: Parsed ${names.length} names from response: ${JSON.stringify(names)}`);
      
      return names;
    } catch (error) {
      logMessage(`ENHANCED_OPENAI_SERVICE: Error generating names - ${error.message}`);
      console.error('OpenAI service error:', error);
      throw new Error('Failed to generate names with OpenAI: ' + error.message);
    }
  }

  async generatePersonalNames(type, options, numSuggestions = 10) {
    logMessage(`ENHANCED_OPENAI_SERVICE: Generating personal names of type: ${type}`);
    logMessage(`ENHANCED_OPENAI_SERVICE: Options: ${JSON.stringify(options)}, Count: ${numSuggestions}`);
    
    if (!this.initialized) {
      logMessage('ENHANCED_OPENAI_SERVICE: ERROR - OpenAI service is not initialized with a valid API key');
      throw new Error('OpenAI service is not initialized with a valid API key');
    }

    try {
      // Extract options
      const { gender, style, origin, theme } = options;
      
      // Create a prompt based on the personal name type
      let prompt;
      if (type === 'baby') {
        prompt = `Generate ${numSuggestions} ${gender} baby names that are ${style} in style and of ${origin !== 'any' ? origin : 'any'} origin. 
        Return only the names, one per line, with no additional text or explanation.`;
      } else { // pet
        prompt = `Generate ${numSuggestions} ${gender !== 'any' ? gender : ''} pet names that are ${style} in style ${theme !== 'any' ? `and related to ${theme}` : ''}. 
        Return only the names, one per line, with no additional text or explanation.`;
      }
      
      logMessage(`ENHANCED_OPENAI_SERVICE: Sending prompt to OpenAI API: ${prompt}`);
      
      // Generate text using OpenAI
      const completion = await this.openai.chat.completions.create({
        model: this.modelName,
        messages: [
          { 
            role: "system", 
            content: type === 'baby' 
              ? `You are a helpful assistant that generates culturally appropriate baby names.` 
              : `You are a helpful assistant that generates creative pet names.`
          },
          { role: "user", content: prompt }
        ],
        temperature: 0.8,
        max_tokens: 150
      });
      
      logMessage(`ENHANCED_OPENAI_SERVICE: Received response from OpenAI API: ${JSON.stringify(completion)}`);
      
      // Extract names from the generated text
      const generatedText = completion.choices[0].message.content;
      logMessage(`ENHANCED_OPENAI_SERVICE: Raw content from OpenAI: ${generatedText}`);
      
      const names = generatedText
        .split('\n')
        .map(name => name.trim())
        .filter(name => name.length > 0)
        .map(name => {
          // Remove any numbering or bullet points
          return name.replace(/^\d+[\.\)]\s*/, '').replace(/^-\s*/, '');
        })
        .slice(0, numSuggestions);
      
      logMessage(`ENHANCED_OPENAI_SERVICE: Parsed ${names.length} personal names from response: ${JSON.stringify(names)}`);
      
      return names;
    } catch (error) {
      logMessage(`ENHANCED_OPENAI_SERVICE: Error generating personal names - ${error.message}`);
      console.error('OpenAI service error for personal names:', error);
      throw new Error('Failed to generate personal names with OpenAI: ' + error.message);
    }
  }
}

module.exports = EnhancedOpenAIService;
