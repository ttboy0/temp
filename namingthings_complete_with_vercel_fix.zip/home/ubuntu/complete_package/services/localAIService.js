const { pipeline } = require('@xenova/transformers');
const fs = require('fs');
const path = require('path');

// Create logs directory if it doesn't exist
const logsDir = path.join(__dirname, '..', 'logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

// Create log file stream
const logStream = fs.createWriteStream(path.join(logsDir, 'local-ai-service.log'), { flags: 'a' });

// Helper function to log messages to both console and file
function logMessage(message) {
  const timestamp = new Date().toISOString();
  const logEntry = `[${timestamp}] ${message}`;
  console.log(logEntry);
  logStream.write(logEntry + '\n');
}

class LocalAIService {
  constructor(modelPath) {
    logMessage('LOCAL_AI_SERVICE: Initializing Local AI service');
    this.modelPath = modelPath;
    this.initialized = false;
    this.initializing = false;
    this.generator = null;
    logMessage(`LOCAL_AI_SERVICE: Model path set to ${modelPath}`);
    this.initializeModel();
  }

  async initializeModel() {
    if (this.initializing) {
      logMessage('LOCAL_AI_SERVICE: Model initialization already in progress');
      return;
    }
    
    this.initializing = true;
    logMessage('LOCAL_AI_SERVICE: Starting model initialization');
    
    try {
      logMessage('LOCAL_AI_SERVICE: Loading text-generation pipeline');
      // Initialize the model in the background
      this.generator = await pipeline('text-generation', 'Xenova/distilgpt2');
      this.initialized = true;
      logMessage('LOCAL_AI_SERVICE: Local AI model initialized successfully');
    } catch (error) {
      logMessage(`LOCAL_AI_SERVICE: Failed to initialize local AI model: ${error.message}`);
      console.error('Failed to initialize local AI model:', error);
      this.initialized = false;
    } finally {
      this.initializing = false;
    }
  }

  isInitialized() {
    return this.initialized;
  }
  
  async checkStatus() {
    logMessage('LOCAL_AI_SERVICE: Checking Local AI service status');
    
    // Check if model is initialized
    if (!this.initialized && !this.initializing) {
      logMessage('LOCAL_AI_SERVICE: Model not initialized, attempting to initialize');
      // Try to initialize again if not already initializing
      await this.initializeModel();
    }
    
    const status = {
      available: this.initialized,
      modelInitialized: this.initialized,
      modelPath: this.modelPath,
      message: this.initialized ? 'Local AI model is ready' : 'Local AI model is not initialized'
    };
    
    logMessage(`LOCAL_AI_SERVICE: Status check result: ${JSON.stringify(status)}`);
    
    return status;
  }

  async generateNames(input, type, numSuggestions = 10, seed = Math.random()) {
    logMessage(`LOCAL_AI_SERVICE: Generating names for input: "${input}"`);
    logMessage(`LOCAL_AI_SERVICE: Type: ${type}, Count: ${numSuggestions}, Seed: ${seed}`);
    
    if (!this.initialized) {
      if (!this.initializing) {
        logMessage('LOCAL_AI_SERVICE: Model not initialized, attempting to initialize');
        // Try to initialize again if not already initializing
        await this.initializeModel();
      }
      
      if (!this.initialized) {
        logMessage('LOCAL_AI_SERVICE: Model initialization failed, cannot generate names');
        throw new Error('Local AI model is not initialized yet');
      }
    }

    try {
      // Create a prompt based on the input type
      let prompt;
      if (type === 'description') {
        prompt = `Generate function names for: ${input}\nFunction names:`;
      } else { // code snippet
        prompt = `Generate function names for this code:\n${input}\nFunction names:`;
      }
      
      logMessage(`LOCAL_AI_SERVICE: Using prompt: ${prompt}`);
      
      // Use seed to adjust temperature for variation
      const seedBasedTemperature = 0.5 + (seed * 0.5); // Range from 0.5 to 1.0
      
      // Generate text using the local model
      logMessage('LOCAL_AI_SERVICE: Generating text with local model');
      const result = await this.generator(prompt, {
        max_new_tokens: 100,
        temperature: seedBasedTemperature,
        num_return_sequences: 1,
        seed: Math.floor(seed * 10000) // Convert seed to integer for model
      });
      
      // Extract function names from the generated text
      const generatedText = result[0].generated_text.substring(prompt.length);
      logMessage(`LOCAL_AI_SERVICE: Raw generated text: ${generatedText}`);
      
      // Process the text to extract function names
      const names = this.extractFunctionNames(generatedText, numSuggestions);
      logMessage(`LOCAL_AI_SERVICE: Extracted ${names.length} function names: ${JSON.stringify(names)}`);
      
      return names;
    } catch (error) {
      logMessage(`LOCAL_AI_SERVICE: Error generating names - ${error.message}`);
      console.error('Local AI service error:', error);
      throw new Error('Failed to generate names with local AI: ' + error.message);
    }
  }

  extractFunctionNames(text, numSuggestions) {
    logMessage(`LOCAL_AI_SERVICE: Extracting function names from text of length ${text.length}`);
    
    // Split by common delimiters and clean up
    const possibleNames = text
      .split(/[\n,;.(){}[\]"'\s]+/)
      .map(name => name.trim())
      .filter(name => name.length > 0 && /^[a-zA-Z][a-zA-Z0-9]*$/.test(name))
      .filter(name => name.length < 30); // Avoid extremely long names
    
    logMessage(`LOCAL_AI_SERVICE: Found ${possibleNames.length} possible names after splitting and filtering`);
    
    // Convert to camelCase if needed
    const camelCaseNames = possibleNames.map(name => {
      // If already camelCase or starts with lowercase, keep as is
      if (/^[a-z][a-zA-Z0-9]*$/.test(name)) {
        return name;
      }
      // Convert PascalCase to camelCase
      if (/^[A-Z][a-zA-Z0-9]*$/.test(name)) {
        return name.charAt(0).toLowerCase() + name.slice(1);
      }
      // Convert snake_case to camelCase
      if (name.includes('_')) {
        return name.split('_')
          .map((part, index) => index === 0 ? part : part.charAt(0).toUpperCase() + part.slice(1))
          .join('');
      }
      return name;
    });
    
    // Remove duplicates and limit to requested number
    const finalNames = [...new Set(camelCaseNames)].slice(0, numSuggestions);
    logMessage(`LOCAL_AI_SERVICE: Final extracted names (${finalNames.length}): ${JSON.stringify(finalNames)}`);
    
    return finalNames;
  }
  
  async generatePersonalNames(type, options, numSuggestions = 10) {
    logMessage(`LOCAL_AI_SERVICE: Generating personal names of type: ${type}`);
    logMessage(`LOCAL_AI_SERVICE: Options: ${JSON.stringify(options)}, Count: ${numSuggestions}`);
    
    // Fallback implementation for personal names
    // In a real implementation, this would use the local model
    
    try {
      // Generate names using predefined lists as fallback
      let names = [];
      
      if (type === 'baby') {
        names = this.generateBabyNames(options, numSuggestions);
      } else {
        names = this.generatePetNames(options, numSuggestions);
      }
      
      logMessage(`LOCAL_AI_SERVICE: Generated ${names.length} personal names: ${JSON.stringify(names)}`);
      
      return names;
    } catch (error) {
      logMessage(`LOCAL_AI_SERVICE: Error generating personal names - ${error.message}`);
      throw new Error(`Failed to generate personal names: ${error.message}`);
    }
  }
  
  generateBabyNames(options, count) {
    logMessage(`LOCAL_AI_SERVICE: Generating baby names with options: ${JSON.stringify(options)}`);
    
    // Predefined lists of baby names by gender
    const boyNames = ['Liam', 'Noah', 'Oliver', 'Elijah', 'William', 'James', 'Benjamin', 'Lucas', 'Henry', 'Alexander', 'Mason', 'Michael', 'Ethan', 'Daniel', 'Jacob', 'Logan', 'Jackson', 'Levi', 'Sebastian', 'Mateo'];
    
    const girlNames = ['Olivia', 'Emma', 'Charlotte', 'Amelia', 'Ava', 'Sophia', 'Isabella', 'Mia', 'Evelyn', 'Harper', 'Luna', 'Camila', 'Gianna', 'Elizabeth', 'Eleanor', 'Ella', 'Abigail', 'Sofia', 'Avery', 'Scarlett'];
    
    const neutralNames = ['Riley', 'Jordan', 'Casey', 'Reese', 'Quinn', 'Finley', 'River', 'Dakota', 'Skyler', 'Tatum', 'Sawyer', 'Phoenix', 'Charlie', 'Blake', 'Hayden', 'Taylor', 'Morgan', 'Rowan', 'Cameron', 'Avery'];
    
    // Select names based on gender
    let namePool = [];
    if (options.gender === 'boy') {
      namePool = boyNames;
    } else if (options.gender === 'girl') {
      namePool = girlNames;
    } else {
      namePool = neutralNames;
    }
    
    // Shuffle the names
    const shuffledNames = [...namePool].sort(() => Math.random() - 0.5);
    
    // Return the requested number of names
    const result = shuffledNames.slice(0, count);
    logMessage(`LOCAL_AI_SERVICE: Selected ${result.length} baby names: ${JSON.stringify(result)}`);
    
    return result;
  }
  
  generatePetNames(options, count) {
    logMessage(`LOCAL_AI_SERVICE: Generating pet names with options: ${JSON.stringify(options)}`);
    
    // Predefined lists of pet names by theme
    const foodNames = ['Cookie', 'Pepper', 'Ginger', 'Oreo', 'Biscuit', 'Honey', 'Olive', 'Mocha', 'Cocoa', 'Peanut', 'Muffin', 'Taco', 'Nacho', 'Noodle', 'Pickles', 'Waffles', 'Beans', 'Kiwi', 'Coconut', 'Marshmallow'];
    
    const natureNames = ['Luna', 'Sky', 'River', 'Willow', 'Storm', 'Sunny', 'Misty', 'Autumn', 'Daisy', 'Pebble', 'Forest', 'Maple', 'Breeze', 'Coral', 'Clover', 'Fern', 'Jasper', 'Moss', 'Sage', 'Timber'];
    
    const colorNames = ['Shadow', 'Midnight', 'Rusty', 'Amber', 'Ebony', 'Ivory', 'Ruby', 'Jade', 'Onyx', 'Sapphire', 'Silver', 'Goldie', 'Copper', 'Slate', 'Ash', 'Raven', 'Blaze', 'Indigo', 'Scarlet', 'Sienna'];
    
    // Select names based on theme
    let namePool = [];
    if (options.theme === 'food') {
      namePool = foodNames;
    } else if (options.theme === 'nature') {
      namePool = natureNames;
    } else if (options.theme === 'colors') {
      namePool = colorNames;
    } else {
      // Mix all themes if no specific theme is selected
      namePool = [...foodNames, ...natureNames, ...colorNames];
    }
    
    // Shuffle the names
    const shuffledNames = [...namePool].sort(() => Math.random() - 0.5);
    
    // Return the requested number of names
    const result = shuffledNames.slice(0, count);
    logMessage(`LOCAL_AI_SERVICE: Selected ${result.length} pet names: ${JSON.stringify(result)}`);
    
    return result;
  }
}

module.exports = LocalAIService;
