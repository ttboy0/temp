// Vercel API route for model status check
// Save this file as /api/model-status.js in your project root

const { OpenAI } = require('openai');

// Helper function to log messages
function logMessage(message) {
  console.log(`[${new Date().toISOString()}] ${message}`);
}

// Serverless function handler for Vercel
module.exports = async (req, res) => {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Credentials', true);
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader('Access-Control-Allow-Headers', 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version');

  // Handle OPTIONS request
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  try {
    logMessage('Checking OpenAI service status');
    
    const apiKey = process.env.OPENAI_API_KEY;
    let openaiAvailable = false;
    
    if (apiKey) {
      try {
        const openai = new OpenAI({ apiKey });
        
        // Simple models list request to check if API is accessible
        await openai.models.list();
        openaiAvailable = true;
        
        logMessage('Status check successful - OpenAI API is accessible');
      } catch (error) {
        logMessage(`Status check failed - ${error.message}`);
        openaiAvailable = false;
      }
    } else {
      logMessage('OpenAI API key not found');
      openaiAvailable = false;
    }
    
    // Return status information
    return res.status(200).json({
      openaiAvailable: openaiAvailable,
      enhancedAvailable: openaiAvailable, // Same as openaiAvailable for simplicity
      localAvailable: false, // Local model not available in Vercel
      mode: process.env.MODEL_MODE || 'openai'
    });
  } catch (error) {
    logMessage(`Error checking model status: ${error.message}`);
    
    // Return fallback status
    return res.status(200).json({
      openaiAvailable: false,
      enhancedAvailable: false,
      localAvailable: false,
      mode: 'fallback'
    });
  }
};
