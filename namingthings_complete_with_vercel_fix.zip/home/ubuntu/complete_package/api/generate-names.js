// Vercel API route for function name generation
// Save this file as /api/generate-names.js in your project root

const { OpenAI } = require('openai');

// Helper function to log messages
function logMessage(message) {
  console.log(`[${new Date().toISOString()}] ${message}`);
}

// Fallback function names for different scenarios
const FALLBACK_FUNCTION_NAMES = {
  // Common function name patterns
  description: [
    "findMaxValue", 
    "calculateTotal", 
    "processData", 
    "validateInput", 
    "formatOutput", 
    "convertToString", 
    "parseUserInput", 
    "filterResults", 
    "sortItems", 
    "getAverage"
  ],
  // For code snippets
  code: [
    "processArray", 
    "handleUserInput", 
    "calculateResult", 
    "transformData", 
    "validateForm", 
    "fetchUserData", 
    "updateUIState", 
    "renderComponent", 
    "initializeSystem", 
    "cleanupResources"
  ]
};

// Serverless function handler for Vercel
module.exports = async (req, res) => {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Credentials', true);
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader('Access-Control-Allow-Headers', 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version');

  // Handle OPTIONS request
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Log the request
    logMessage(`Received request to generate function names: ${JSON.stringify(req.body)}`);
    
    // Validate input
    const { input, type, isPremium } = req.body;
    if (!input || !type) {
      logMessage(`Error: Invalid input parameters: ${JSON.stringify(req.body)}`);
      return res.status(400).json({ error: 'Invalid input parameters' });
    }
    
    // Determine number of suggestions based on tier
    const numSuggestions = isPremium ? 25 : 10;
    logMessage(`Generating ${numSuggestions} name suggestions for ${type}`);
    
    // Try to use OpenAI if API key is available
    let names = [];
    const apiKey = process.env.OPENAI_API_KEY;
    
    if (apiKey) {
      try {
        logMessage('Attempting to use OpenAI API');
        const openai = new OpenAI({ apiKey });
        
        // Create a prompt based on the input type
        let prompt;
        if (type === 'description') {
          prompt = `You are a senior developer helping to name functions. Generate ${numSuggestions} function names for this description: "${input}". 
          Return only the function names in camelCase format, one per line, with no additional text or explanation.`;
        } else { // code snippet
          prompt = `You are a senior developer helping to name functions. Generate ${numSuggestions} function names for this code:
          \`\`\`
          ${input}
          \`\`\`
          Return only the function names in camelCase format, one per line, with no additional text or explanation.`;
        }
        
        // Use seed to adjust temperature for variation
        const seed = Math.random();
        const seedBasedTemperature = 0.5 + (seed * 0.5); // Range from 0.5 to 1.0
        
        // Generate text using OpenAI
        const completion = await openai.chat.completions.create({
          model: process.env.OPENAI_MODEL || "gpt-3.5-turbo",
          messages: [
            { role: "system", content: "You are a helpful assistant that generates function names for developers." },
            { role: "user", content: prompt }
          ],
          temperature: seedBasedTemperature,
          max_tokens: 150,
          seed: Math.floor(seed * 1000000) // Convert seed to integer for OpenAI
        });
        
        // Extract function names from the generated text
        const generatedText = completion.choices[0].message.content;
        
        names = generatedText
          .split('\n')
          .map(name => name.trim())
          .filter(name => name.length > 0)
          .slice(0, numSuggestions);
        
        logMessage(`Successfully generated ${names.length} names using OpenAI`);
      } catch (openaiError) {
        logMessage(`OpenAI error: ${openaiError.message}`);
        // Will fall back to predefined names below
      }
    }
    
    // If OpenAI failed or returned no names, use fallback
    if (names.length === 0) {
      logMessage('Using fallback function names');
      
      // Choose appropriate fallback list based on input type
      const fallbackList = FALLBACK_FUNCTION_NAMES[type] || FALLBACK_FUNCTION_NAMES.description;
      
      // Create variations of the fallback names to meet the required number
      names = [...fallbackList];
      
      // If we need more names than we have in our fallback list
      if (names.length < numSuggestions) {
        // Add variations with numbers
        for (let i = 0; i < fallbackList.length && names.length < numSuggestions; i++) {
          names.push(`${fallbackList[i]}Data`);
        }
        
        for (let i = 0; i < fallbackList.length && names.length < numSuggestions; i++) {
          names.push(`get${fallbackList[i].charAt(0).toUpperCase() + fallbackList[i].slice(1)}`);
        }
        
        // Add numbered variations if we still need more
        let counter = 2;
        while (names.length < numSuggestions) {
          for (let i = 0; i < fallbackList.length && names.length < numSuggestions; i++) {
            names.push(`${fallbackList[i]}${counter}`);
          }
          counter++;
        }
      }
      
      // Ensure we have exactly the right number of names
      names = names.slice(0, numSuggestions);
    }
    
    // Return the names
    return res.status(200).json({ names });
  } catch (error) {
    logMessage(`Error generating function names: ${error.message}`);
    
    // Last resort fallback
    const fallbackNames = Array.from({ length: 10 }, (_, i) => `function${i + 1}`);
    return res.status(200).json({ names: fallbackNames });
  }
};
