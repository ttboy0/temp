// Vercel API route for personal names generation
// Save this file as /api/generate-personal-names.js in your project root

const { OpenAI } = require('openai');

// Helper function to log messages
function logMessage(message) {
  console.log(`[${new Date().toISOString()}] ${message}`);
}

// Fallback name lists
const FALLBACK_NAMES = {
  baby: {
    boy: ["James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph", "Thomas", "Charles"],
    girl: ["Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Barbara", "Susan", "Jessica", "Sarah", "Karen"],
    neutral: ["Alex", "Jordan", "Taylor", "Casey", "Riley", "Avery", "Quinn", "Morgan", "Skyler", "Dakota"]
  },
  pet: {
    common: ["Buddy", "Max", "Charlie", "Jack", "Cooper", "Rocky", "Bear", "Duke", "Tucker", "Oliver"],
    unique: ["Apollo", "Zeus", "Nova", "Echo", "Orion", "Phoenix", "Luna", "Athena", "Titan", "Zephyr"],
    cute: ["Mochi", "Biscuit", "Peanut", "Cupcake", "Marshmallow", "Pudding", "Waffle", "Cookie", "Sprinkles", "Jellybean"],
    funny: ["Sir Barksalot", "Professor Whiskers", "Captain Floof", "Mister Wiggles", "Lady Meowington", "Sergeant Snuggles", "Doctor Woof", "Princess Paws", "Count Fluffula", "Baron von Treats"],
    cool: ["Shadow", "Blaze", "Storm", "Onyx", "Raven", "Rebel", "Phantom", "Viper", "Maverick", "Rogue"]
  }
};

// Serverless function handler for Vercel
module.exports = async (req, res) => {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Credentials', true);
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader('Access-Control-Allow-Headers', 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version');

  // Handle OPTIONS request
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Log the request
    logMessage(`Received request to generate personal names: ${JSON.stringify(req.body)}`);
    
    // Validate input
    const { type, options, isPremium } = req.body;
    if (!type || !options) {
      logMessage(`Error: Invalid personal name type: ${type}`);
      return res.status(400).json({ error: 'Invalid input parameters' });
    }
    
    // Determine number of suggestions based on tier
    const numSuggestions = isPremium ? 25 : 10;
    logMessage(`Generating ${numSuggestions} ${type} name suggestions`);
    
    // Try to use OpenAI if API key is available
    let names = [];
    const apiKey = process.env.OPENAI_API_KEY;
    
    if (apiKey) {
      try {
        logMessage('Attempting to use OpenAI API');
        const openai = new OpenAI({ apiKey });
        
        // Construct prompt based on name type and options
        let prompt;
        if (type === 'baby') {
          prompt = `You are a helpful assistant providing baby name suggestions.
          Please suggest ${numSuggestions} ${options.gender} baby names with ${options.style} style 
          ${options.origin !== 'any' ? `from ${options.origin} origin` : ''}.
          Only provide the names, one per line, without any additional explanation.`;
        } else {
          prompt = `You are a helpful assistant providing pet name suggestions.
          Please suggest ${numSuggestions} ${options.gender !== 'any' ? options.gender : ''} pet names with ${options.style} style 
          ${options.theme !== 'any' ? `with a ${options.theme} theme` : ''}.
          Only provide the names, one per line, without any additional explanation.`;
        }
        
        // Generate text using OpenAI
        const completion = await openai.chat.completions.create({
          model: process.env.OPENAI_MODEL || "gpt-3.5-turbo",
          messages: [
            { role: "system", content: "You are a helpful assistant that suggests baby and pet names." },
            { role: "user", content: prompt }
          ],
          temperature: 0.8,
          max_tokens: 150
        });
        
        // Extract names from the generated text
        const generatedText = completion.choices[0].message.content;
        
        names = generatedText
          .split('\n')
          .map(name => name.trim())
          .filter(name => name.length > 0)
          .map(name => {
            // Remove any numbering or bullet points
            return name.replace(/^\d+[\.\)]\s*/, '').replace(/^-\s*/, '');
          })
          .slice(0, numSuggestions);
        
        logMessage(`Successfully generated ${names.length} names using OpenAI`);
      } catch (openaiError) {
        logMessage(`OpenAI error: ${openaiError.message}`);
        // Will fall back to predefined names below
      }
    }
    
    // If OpenAI failed or returned no names, use fallback
    if (names.length === 0) {
      logMessage('Using fallback names');
      
      if (type === 'baby') {
        if (options.gender === 'boy') {
          names = FALLBACK_NAMES.baby.boy;
        } else if (options.gender === 'girl') {
          names = FALLBACK_NAMES.baby.girl;
        } else {
          names = FALLBACK_NAMES.baby.neutral;
        }
      } else { // pet names
        if (FALLBACK_NAMES.pet[options.style]) {
          names = FALLBACK_NAMES.pet[options.style];
        } else {
          names = FALLBACK_NAMES.pet.common;
        }
      }
      
      // Ensure we have the right number of names
      if (names.length < numSuggestions) {
        // Repeat names if we don't have enough
        names = [...names, ...names, ...names].slice(0, numSuggestions);
      } else if (names.length > numSuggestions) {
        names = names.slice(0, numSuggestions);
      }
    }
    
    // Return the names
    return res.status(200).json({ names });
  } catch (error) {
    logMessage(`Error generating personal names: ${error.message}`);
    
    // Last resort fallback
    const fallbackNames = Array.from({ length: 10 }, (_, i) => `Name${i + 1}`);
    return res.status(200).json({ names: fallbackNames });
  }
};
