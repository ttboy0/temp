#!/bin/bash

# Script to update package.json with new dependencies and scripts

# Update package.json
cat > /home/ubuntu/naming_things_improved/package.json << 'EOL'
{
  "name": "naming-things",
  "version": "1.1.0",
  "description": "The ultimate AI-powered naming solution for developers, parents, and pet owners",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "download-models": "node scripts/download-models.js",
    "test": "npx playwright test",
    "test:unit": "mocha tests/simple-unit-tests.js tests/improved-name-tests.js tests/feedback-tests.js",
    "test:openai": "mocha tests/openai-integration-tests.js"
  },
  "engines": {
    "node": ">=16.0.0"
  },
  "keywords": [
    "naming",
    "developer",
    "function",
    "baby",
    "pet",
    "ai",
    "generator"
  ],
  "author": "Naming Things Team",
  "license": "MIT",
  "dependencies": {
    "@xenova/transformers": "^2.6.0",
    "body-parser": "^1.20.2",
    "cors": "^2.8.5",
    "dotenv": "^16.0.3",
    "express": "^4.18.2",
    "openai": "^4.0.0"
  },
  "devDependencies": {
    "@playwright/test": "^1.32.3",
    "chai": "^4.3.7",
    "mocha": "^10.2.0",
    "supertest": "^6.3.3"
  }
}
EOL

echo "Updated package.json with new dependencies and scripts"
