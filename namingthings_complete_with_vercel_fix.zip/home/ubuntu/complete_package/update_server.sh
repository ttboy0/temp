#!/bin/bash

# Script to integrate all improvements into the main server.js file

# Create a backup of the original server.js
cp /home/ubuntu/naming_things_improved/server.js /home/ubuntu/naming_things_improved/server.js.bak

# Create the updated server.js file
cat > /home/ubuntu/naming_things_improved/server.js << 'EOL'
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

// Import expanded datasets and name rules
const expandedNames = require('./data/expanded_names');
const nameRules = require('./data/name_rules');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json({ limit: '2mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '2mb' }));
app.use(express.static('public'));

// Model configuration
const MODEL_CONFIG = {
  mode: process.env.MODEL_MODE || 'local', // 'local', 'openai', or 'hybrid'
  openaiApiKey: process.env.OPENAI_API_KEY || '',
  openaiModel: process.env.OPENAI_MODEL || 'gpt-3.5-turbo',
  localModelPath: process.env.LOCAL_MODEL_PATH || './models'
};

// Initialize AI service based on configuration
let aiService;
if (MODEL_CONFIG.mode === 'openai' || MODEL_CONFIG.mode === 'hybrid') {
  const EnhancedOpenAIService = require('./services/enhancedOpenAIService');
  aiService = new EnhancedOpenAIService(MODEL_CONFIG.openaiApiKey);
}

if (MODEL_CONFIG.mode === 'local' || MODEL_CONFIG.mode === 'hybrid') {
  const LocalAIService = require('./services/localAIService');
  aiService = new LocalAIService(MODEL_CONFIG.localModelPath);
}

// API endpoint to check model status
app.get('/api/model-status', (req, res) => {
  try {
    const status = {
      mode: MODEL_CONFIG.mode,
      openaiAvailable: MODEL_CONFIG.mode === 'openai' || MODEL_CONFIG.mode === 'hybrid',
      localAvailable: MODEL_CONFIG.mode === 'local' || MODEL_CONFIG.mode === 'hybrid',
      localModelInitialized: false,
      openaiModel: MODEL_CONFIG.openaiModel
    };
    
    if (status.localAvailable) {
      // Check if model files exist
      const modelDir = path.join(__dirname, MODEL_CONFIG.localModelPath.replace('./', ''));
      status.localModelInitialized = fs.existsSync(modelDir);
    }
    
    res.json(status);
  } catch (error) {
    console.error('Error checking model status:', error);
    res.status(500).json({ error: 'Failed to check model status' });
  }
});

// API endpoint to generate function names
app.post('/api/generate-names', async (req, res) => {
  try {
    const { input, type, isPremium = false, timestamp, randomSeed } = req.body;
    
    // Add a random seed based on timestamp to ensure different results each time
    const seed = randomSeed || Math.random();
    
    // Validate input
    if (!input) {
      return res.status(400).json({ error: 'Input is required' });
    }
    
    if (!type || !['description', 'code'].includes(type)) {
      return res.status(400).json({ error: 'Valid input type (description or code) is required' });
    }
    
    // Check input length limits
    const maxLength = isPremium ? 2000 : 500;
    if (input.length > maxLength) {
      return res.status(400).json({ 
        error: `Input exceeds maximum length of ${maxLength} characters for your plan`,
        upgrade: true
      });
    }
    
    // Determine number of suggestions based on premium status
    const numSuggestions = isPremium ? 25 : 10;
    
    try {
      // Try to generate names using AI service
      let names = [];
      let usingAI = false;
      
      if (MODEL_CONFIG.mode === 'openai' || MODEL_CONFIG.mode === 'hybrid') {
        try {
          // Add seed to ensure different results each time
          names = await aiService.generateNames(input, type, numSuggestions, seed);
          usingAI = true;
        } catch (error) {
          console.error('Error generating names with OpenAI:', error);
          
          // If in hybrid mode, fall back to local model
          if (MODEL_CONFIG.mode === 'hybrid') {
            try {
              const LocalAIService = require('./services/localAIService');
              const localService = new LocalAIService(MODEL_CONFIG.localModelPath);
              names = await localService.generateNames(input, type, numSuggestions, seed);
              usingAI = true;
            } catch (localError) {
              console.error('Error generating names with local model:', localError);
              // Fall back to pattern recognition
              names = generateFallbackNames(input, type, numSuggestions, seed);
              usingAI = false;
            }
          } else {
            // Fall back to pattern recognition
            names = generateFallbackNames(input, type, numSuggestions, seed);
            usingAI = false;
          }
        }
      } else if (MODEL_CONFIG.mode === 'local') {
        try {
          names = await aiService.generateNames(input, type, numSuggestions, seed);
          usingAI = true;
        } catch (error) {
          console.error('Error generating names with local model:', error);
          // Fall back to pattern recognition
          names = generateFallbackNames(input, type, numSuggestions, seed);
          usingAI = false;
        }
      }
      
      // Apply name rules for validation and improvement
      names = names.map(name => {
        // Validate and improve name based on rules
        if (!nameRules.validateName(name, 'developer')) {
          return '';
        }
        return nameRules.improveName(name, 'developer', null, null);
      }).filter(name => name.length > 0);
      
      // If we couldn't extract enough names, supplement with fallbacks
      if (names.length < numSuggestions) {
        const fallbacks = generateFallbackNames(input, type, numSuggestions, seed);
        while (names.length < numSuggestions && fallbacks.length > 0) {
          names.push(fallbacks.shift());
        }
      }
      
      // Shuffle the names slightly based on seed to ensure different results
      if (seed) {
        names = shuffleArray(names, seed);
      }
      
      // Return only the requested number of suggestions
      return res.json({ 
        names: names.slice(0, numSuggestions),
        ai: usingAI,
        mode: usingAI ? MODEL_CONFIG.mode : 'fallback',
        timestamp: Date.now() // Return current timestamp
      });
    } catch (error) {
      console.error('Error generating names with AI service:', error);
      
      // If AI generation fails, fall back to pattern recognition
      const fallbackNames = generateFallbackNames(input, type, numSuggestions, seed);
      return res.json({ 
        names: fallbackNames.slice(0, numSuggestions),
        fallback: true,
        message: 'Using pattern recognition due to AI service error.',
        timestamp: Date.now() // Return current timestamp
      });
    }
  } catch (error) {
    console.error('Error in generate-names endpoint:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// API endpoint to generate personal names (baby or pet)
app.post('/api/generate-personal-names', async (req, res) => {
  try {
    const { 
      type, // 'baby' or 'pet'
      gender, // For baby: 'boy', 'girl', 'neutral'; For pet: 'male', 'female', 'any'
      style, // For baby: 'common', 'unique', 'traditional', 'modern'; For pet: 'common', 'unique', 'cute', 'funny', 'cool'
      origin, // For baby: 'any', 'english', 'french', etc.; For pet: 'any' (pet names don't have origin)
      theme, // For pet: 'any', 'food', 'nature', 'mythology', 'literature', 'movies', 'colors'
      isPremium = false,
      timestamp,
      randomSeed
    } = req.body;
    
    // Add a random seed based on timestamp to ensure different results each time
    const seed = randomSeed || Math.random();
    
    // Validate input
    if (!type || !['baby', 'pet'].includes(type)) {
      return res.status(400).json({ error: 'Valid type (baby or pet) is required' });
    }
    
    // Validate gender based on type
    if (type === 'baby' && !['boy', 'girl', 'neutral'].includes(gender)) {
      return res.status(400).json({ error: 'Valid gender (boy, girl, or neutral) is required for baby names' });
    }
    
    if (type === 'pet' && !['male', 'female', 'any'].includes(gender)) {
      return res.status(400).json({ error: 'Valid gender (male, female, or any) is required for pet names' });
    }
    
    // Validate style based on type
    if (type === 'baby' && !['common', 'unique', 'traditional', 'modern'].includes(style)) {
      return res.status(400).json({ error: 'Valid style (common, unique, traditional, or modern) is required for baby names' });
    }
    
    if (type === 'pet' && !['common', 'unique', 'cute', 'funny', 'cool'].includes(style)) {
      return res.status(400).json({ error: 'Valid style (common, unique, cute, funny, or cool) is required for pet names' });
    }
    
    // Validate origin for baby names
    const validOrigins = ['any', 'english', 'french', 'spanish', 'italian', 'german', 'nordic', 'greek', 'hebrew', 'arabic', 'indian', 'chinese', 'japanese', 'african'];
    if (type === 'baby' && !validOrigins.includes(origin)) {
      return res.status(400).json({ error: 'Valid origin is required for baby names' });
    }
    
    // Validate theme for pet names
    const validThemes = ['any', 'food', 'nature', 'mythology', 'literature', 'movies', 'colors'];
    if (type === 'pet' && !validThemes.includes(theme)) {
      return res.status(400).json({ error: 'Valid theme is required for pet names' });
    }
    
    // Determine number of suggestions based on premium status
    const numSuggestions = isPremium ? 25 : 10;
    
    try {
      let names = [];
      let usingAI = false;
      
      // Try to generate names using OpenAI if available and in openai or hybrid mode
      if ((MODEL_CONFIG.mode === 'openai' || MODEL_CONFIG.mode === 'hybrid') && 
          aiService instanceof EnhancedOpenAIService && 
          aiService.isInitialized()) {
        try {
          names = await aiService.generatePersonalNames(type, gender, style, origin, theme, numSuggestions, seed);
          usingAI = true;
        } catch (error) {
          console.error('Error generating personal names with OpenAI:', error);
          // Fall back to local generation
          usingAI = false;
        }
      }
      
      // If we don't have names from OpenAI, use local generation
      if (names.length === 0) {
        // Generate names based on type
        if (type === 'baby') {
          names = generateBabyNames(gender, style, origin, numSuggestions, seed);
        } else if (type === 'pet') {
          names = generatePetNames(gender, style, theme, numSuggestions, seed);
        }
      }
      
      // Validate and improve names
      names = validateAndImproveNames(names, type, origin, style);
      
      // If we don't have enough names, get fallbacks
      if (names.length < numSuggestions) {
        const fallbacks = getFallbackNames(type, gender, style, origin, theme, numSuggestions, seed);
        while (names.length < numSuggestions && fallbacks.length > 0) {
          names.push(fallbacks.shift());
        }
      }
      
      // Shuffle the names based on seed to ensure different results
      names = shuffleArray(names, seed);
      
      // Return only the requested number of suggestions
      return res.json({ 
        names: names.slice(0, numSuggestions),
        ai: usingAI,
        timestamp: Date.now() // Return current timestamp
      });
    } catch (error) {
      console.error('Error generating personal names:', error);
      
      // If generation fails, fall back to pattern recognition
      const fallbackNames = getFallbackNames(type, gender, style, origin, theme, numSuggestions, seed);
      return res.json({ 
        names: fallbackNames.slice(0, numSuggestions),
        fallback: true,
        message: 'Using fallback name generation.',
        timestamp: Date.now() // Return current timestamp
      });
    }
  } catch (error) {
    console.error('Error in generate-personal-names endpoint:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// API endpoint to record user feedback on names
app.post('/api/feedback', async (req, res) => {
  try {
    const { name, rating, type, origin, gender, style, theme } = req.body;
    
    if (!name || !rating || !type) {
      return res.status(400).json({ error: 'Name, rating, and type are required' });
    }
    
    // Validate rating (1-5 stars)
    if (rating < 1 || rating > 5) {
      return res.status(400).json({ error: 'Rating must be between 1 and 5' });
    }
    
    // Create feedback object
    const feedback = {
      name,
      rating,
      type,
      origin: origin || null,
      gender: gender || null,
      style: style || null,
      theme: theme || null,
      timestamp: Date.now()
    };
    
    // In a production environment, this would be stored in a database
    // For this implementation, we'll store it in a file
    const feedbackDir = path.join(__dirname, 'data', 'feedback');
    if (!fs.existsSync(feedbackDir)) {
      fs.mkdirSync(feedbackDir, { recursive: true });
    }
    
    const feedbackFile = path.join(feedbackDir, `feedback_${Date.now()}.json`);
    fs.writeFileSync(feedbackFile, JSON.stringify(feedback, null, 2));
    
    // Log feedback for debugging
    console.log('Received feedback:', feedback);
    
    return res.json({ success: true, message: 'Feedback recorded successfully' });
  } catch (error) {
    console.error('Error recording feedback:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Function to validate and improve names
function validateAndImproveNames(names, type, origin, style) {
  // Filter out invalid names and improve valid ones
  return names
    .map(name => {
      // For Chinese, Japanese, and Arabic names, use special validation
      const isNonLatinScript = origin === 'chinese' || origin === 'japanese' || origin === 'arabic';
      
      // Validate name based on type and script
      if (!nameRules.validateName(name, type)) {
        // If invalid, try to improve it
        if (name.length < 3 && !isNonLatinScript) {
          return nameRules.improvement.abbreviations[name] || '';
        }
        return '';
      }
      
      // Improve name based on type, style, and origin
      return nameRules.improveName(name, type, style, origin);
    })
    .filter(name => name.length > 0); // Remove any empty names
}

// Helper function to generate baby names
function generateBabyNames(gender, style, origin, numSuggestions = 10, seed = 0) {
  let names = [];
  
  // Use expanded datasets for Nordic and Indian names if available
  if (origin === 'nordic' && expandedNames.nordic && expandedNames.nordic[gender]) {
    names = names.concat(expandedNames.nordic[gender]);
  } else if (origin === 'indian' && expandedNames.indian && expandedNames.indian[gender]) {
    names = names.concat(expandedNames.indian[gender]);
  } else {
    // Boy names
    if (gender === 'boy') {
      if (origin === 'english' || origin === 'any') {
        names = names.concat([
          'Liam', 'Noah', 'Oliver', 'Elijah', 'William', 'James', 'Benjamin', 'Lucas', 'Henry', 'Alexander',
          'Mason', 'Michael', 'Ethan', 'Daniel', 'Jacob', 'Logan', 'Jackson', 'Levi', 'Sebastian', 'Mateo',
          'Jack', 'Owen', 'Theodore', 'Aiden', 'Samuel', 'Joseph', 'John', 'David', 'Wyatt', 'Matthew'
        ]);
      }
      
      if (origin === 'french' || origin === 'any') {
        names = names.concat([
          'Louis', 'Hugo', 'Gabriel', 'Léo', 'Raphaël', 'Jules', 'Adam', 'Lucas', 'Arthur', 'Nathan',
          'Ethan', 'Théo', 'Noah', 'Mathis', 'Enzo', 'Maël', 'Timéo', 'Nolan', 'Gabin', 'Sacha'
        ]);
      }
      
      if (origin === 'spanish' || origin === 'any') {
        names = names.concat([
          'Santiago', 'Mateo', 'Sebastián', 'Leonardo', 'Emiliano', 'Diego', 'Alejandro', 'Daniel', 'Gabriel', 'Tomás',
          'Nicolás', 'Samuel', 'Matías', 'David', 'Lucas', 'Joaquín', 'Adrián', 'Pablo', 'Thiago', 'Javier'
        ]);
      }
      
      if (origin === 'italian' || origin === 'any') {
        names = names.concat([
          'Francesco', 'Leonardo', 'Alessandro', 'Lorenzo', 'Mattia', 'Andrea', 'Gabriele', 'Riccardo', 'Tommaso', 'Edoardo',
          'Giuseppe', 'Antonio', 'Federico', 'Diego', 'Marco', 'Giovanni', 'Nicolò', 'Luca', 'Pietro', 'Davide'
        ]);
      }
      
      if (origin === 'german' || origin === 'any') {
        names = names.concat([
          'Noah', 'Leon', 'Paul', 'Ben', 'Elias', 'Jonas', 'Felix', 'Maximilian', 'Henry', 'Luis',
          'Luca', 'Finn', 'Lukas', 'Emil', 'Anton', 'Jakob', 'Oskar', 'Liam', 'Theo', 'Moritz'
        ]);
      }
      
      if (origin === 'greek' || origin === 'any') {
        names = names.concat([
          'Georgios', 'Dimitrios', 'Konstantinos', 'Ioannis', 'Nikolaos', 'Panagiotis', 'Vasileios', 'Christos', 'Athanasios', 'Evangelos',
          'Andreas', 'Alexandros', 'Michail', 'Antonios', 'Theodoros', 'Stavros', 'Petros', 'Spyridon', 'Eleftherios', 'Ilias'
        ]);
      }
      
      if (origin === 'hebrew' || origin === 'any') {
        names = names.concat([
          'Noam', 'Yosef', 'David', 'Uri', 'Itai', 'Daniel', 'Ari', 'Moshe', 'Yehuda', 'Eitan',
          'Ariel', 'Yonatan', 'Shmuel', 'Levi', 'Omer', 'Yair', 'Avraham', 'Binyamin', 'Eliyahu', 'Nadav'
        ]);
      }
      
      if (origin === 'african' || origin === 'any') {
        names = names.concat([
          'Kofi', 'Kwame', 'Amara', 'Chidi', 'Tendai', 'Sekou', 'Mandla', 'Thabo', 'Nnamdi', 'Oluwaseun',
          'Faraji', 'Jelani', 'Kwesi', 'Tau', 'Zuberi', 'Chike', 'Kgosi', 'Themba', 'Olufemi', 'Jabari'
        ]);
      }
      
      if (origin === 'chinese' || origin === 'any') {
        names = names.concat([
          '李明', '王伟', '张强', '刘洋', '陈宇', '杨帆', '赵鑫', '黄海', '周杰', '吴磊',
          '孙浩', '朱峰', '高远', '林阳', '郑华', '梁辰', '谢天', '宋涛', '唐风', '许江'
        ]);
      }
      
      if (origin === 'japanese' || origin === 'any') {
        names = names.concat([
          '大翔', '蓮', '湊', '陽翔', '悠真', '陽太', '樹', '悠人', '悠斗', '蒼',
          '翔太', '颯真', '悠', '大和', '陸', '颯', '陽', '太一', '海翔', '蒼空'
        ]);
      }
      
      if (origin === 'arabic' || origin === 'any') {
        names = names.concat([
          'محمد', 'أحمد', 'يوسف', 'عمر', 'علي', 'إبراهيم', 'عبدالله', 'زياد', 'آدم', 'حسن',
          'خالد', 'عبدالرحمن', 'كريم', 'مالك', 'حمزة', 'زين', 'ياسين', 'نور', 'سليم', 'طارق'
        ]);
      }
    }
    
    // Girl names
    else if (gender === 'girl') {
      if (origin === 'english' || origin === 'any') {
        names = names.concat([
          'Olivia', 'Emma', 'Charlotte', 'Amelia', 'Ava', 'Sophia', 'Isabella', 'Mia', 'Evelyn', 'Harper',
          'Luna', 'Camila', 'Gianna', 'Elizabeth', 'Eleanor', 'Ella', 'Abigail', 'Sofia', 'Avery', 'Scarlett',
          'Emily', 'Aria', 'Penelope', 'Chloe', 'Layla', 'Mila', 'Nora', 'Hazel', 'Madison', 'Ellie'
        ]);
      }
      
      if (origin === 'french' || origin === 'any') {
        names = names.concat([
          'Emma', 'Jade', 'Louise', 'Alice', 'Chloé', 'Lina', 'Léa', 'Rose', 'Anna', 'Mila',
          'Julia', 'Manon', 'Juliette', 'Inès', 'Zoé', 'Camille', 'Lola', 'Agathe', 'Ambre', 'Lou'
        ]);
      }
      
      if (origin === 'spanish' || origin === 'any') {
        names = names.concat([
          'Sofía', 'Isabella', 'Valentina', 'Emma', 'Mía', 'Lucía', 'Camila', 'Victoria', 'Martina', 'Valeria',
          'Ximena', 'Sara', 'Daniela', 'Gabriela', 'Natalia', 'Elena', 'Mariana', 'Paula', 'Catalina', 'Alejandra'
        ]);
      }
      
      if (origin === 'italian' || origin === 'any') {
        names = names.concat([
          'Sofia', 'Giulia', 'Aurora', 'Ginevra', 'Alice', 'Beatrice', 'Emma', 'Vittoria', 'Ludovica', 'Matilde',
          'Giorgia', 'Chiara', 'Martina', 'Greta', 'Bianca', 'Francesca', 'Nicole', 'Gaia', 'Adele', 'Alessia'
        ]);
      }
      
      if (origin === 'german' || origin === 'any') {
        names = names.concat([
          'Emma', 'Mia', 'Hannah', 'Emilia', 'Lina', 'Mila', 'Ella', 'Klara', 'Lea', 'Sofia',
          'Anna', 'Marie', 'Leni', 'Charlotte', 'Leonie', 'Luisa', 'Mathilda', 'Johanna', 'Laura', 'Nele'
        ]);
      }
      
      if (origin === 'greek' || origin === 'any') {
        names = names.concat([
          'Maria', 'Eleni', 'Aikaterini', 'Georgia', 'Sofia', 'Vasiliki', 'Konstantina', 'Dimitra', 'Angeliki', 'Paraskevi',
          'Ioanna', 'Christina', 'Anna', 'Anastasia', 'Alexandra', 'Panagiota', 'Athina', 'Evgenia', 'Zoi', 'Ourania'
        ]);
      }
      
      if (origin === 'hebrew' || origin === 'any') {
        names = names.concat([
          'Tamar', 'Maya', 'Noa', 'Shira', 'Yael', 'Avigail', 'Ayala', 'Adina', 'Talia', 'Naomi',
          'Rivka', 'Sarah', 'Hadas', 'Michal', 'Esti', 'Roni', 'Leah', 'Racheli', 'Hodaya', 'Avital'
        ]);
      }
      
      if (origin === 'african' || origin === 'any') {
        names = names.concat([
          'Amara', 'Nia', 'Zuri', 'Imani', 'Ayana', 'Makena', 'Thema', 'Asha', 'Nala', 'Zahra',
          'Amina', 'Eshe', 'Folami', 'Kesi', 'Lulu', 'Safiya', 'Taji', 'Zola', 'Dalia', 'Jamila'
        ]);
      }
      
      if (origin === 'chinese' || origin === 'any') {
        names = names.concat([
          '李娜', '王芳', '张婷', '刘洁', '陈雪', '杨丽', '赵雯', '黄玲', '周颖', '吴琳',
          '孙茜', '朱莉', '高雅', '林萍', '郑红', '梁婷', '谢雪', '宋琳', '唐婷', '许娟'
        ]);
      }
      
      if (origin === 'japanese' || origin === 'any') {
        names = names.concat([
          '陽菜', '葵', '凛', '澪', '芽依', '結菜', '心春', '陽葵', '咲良', '紬',
          '美月', '結衣', '楓', '美桜', '杏', '莉子', '美羽', '優奈', '心結', '彩花'
        ]);
      }
      
      if (origin === 'arabic' || origin === 'any') {
        names = names.concat([
          'فاطمة', 'مريم', 'زينب', 'نور', 'سارة', 'لينا', 'جنى', 'ليلى', 'رنا', 'هدى',
          'سلمى', 'ياسمين', 'آية', 'ملك', 'حنان', 'ريم', 'دانا', 'لمى', 'رؤى', 'أمل'
        ]);
      }
    }
    
    // Gender neutral names
    else if (gender === 'neutral') {
      if (origin === 'english' || origin === 'any') {
        names = names.concat([
          'Alex', 'Jordan', 'Taylor', 'Morgan', 'Casey', 'Riley', 'Avery', 'Quinn', 'Rowan', 'Skyler',
          'Dakota', 'River', 'Phoenix', 'Sage', 'Remy', 'Blake', 'Charlie', 'Finley', 'Emerson', 'Hayden',
          'Parker', 'Sawyer', 'Kai', 'Reese', 'Jamie', 'Ari', 'Drew', 'Shawn', 'Cameron', 'Elliot'
        ]);
      }
      
      if (origin === 'french' || origin === 'any') {
        names = names.concat([
          'Camille', 'Dominique', 'Claude', 'Maxime', 'Stéphane', 'Frédéric', 'Noël', 'René', 'Yannick', 'Sacha',
          'Charlie', 'Lou', 'Élie', 'Axel', 'Eden', 'Sasha', 'Alix', 'Noa', 'Morgan', 'Louison'
        ]);
      }
      
      if (origin === 'spanish' || origin === 'any') {
        names = names.concat([
          'Ariel', 'Alexis', 'Guadalupe', 'Cruz', 'Angel', 'René', 'Jesús', 'Paz', 'Trinidad', 'Concepción',
          'Reyes', 'Noel', 'Azul', 'Sol', 'Mar', 'Río', 'Valle', 'Amor', 'Luz', 'Cielo'
        ]);
      }
      
      if (origin === 'italian' || origin === 'any') {
        names = names.concat([
          'Andrea', 'Nicola', 'Michele', 'Elia', 'Fiore', 'Sole', 'Celeste', 'Diamante', 'Felice', 'Mare',
          'Amore', 'Cielo', 'Stelle', 'Luna', 'Aria', 'Vento', 'Neve', 'Pace', 'Gioia', 'Luce'
        ]);
      }
      
      if (origin === 'german' || origin === 'any') {
        names = names.concat([
          'Eike', 'Luca', 'Nicola', 'Sascha', 'Kim', 'Toni', 'Kai', 'Mika', 'Jona', 'Robin',
          'Alex', 'Nicki', 'Elia', 'Kaya', 'Manu', 'Noel', 'Rene', 'Sasha', 'Tommi', 'Conny'
        ]);
      }
      
      if (origin === 'nordic' || origin === 'any') {
        names = names.concat([
          'Lo', 'Kim', 'Eli', 'Mika', 'Noa', 'Inge', 'Tove', 'Kai', 'Mio', 'Rene',
          'Ari', 'Sasha', 'Vide', 'Alva', 'Billie', 'Charlie', 'Ellis', 'Helle', 'Nicke', 'Tintin'
        ]);
      }
      
      if (origin === 'greek' || origin === 'any') {
        names = names.concat([
          'Agapi', 'Alexis', 'Aris', 'Fotis', 'Giannis', 'Nikitas', 'Paris', 'Sotiris', 'Thanasis', 'Yannis',
          'Aliki', 'Artemis', 'Dafni', 'Eirini', 'Fani', 'Melina', 'Niki', 'Olympia', 'Thaleia', 'Xenia'
        ]);
      }
      
      if (origin === 'hebrew' || origin === 'any') {
        names = names.concat([
          'Ariel', 'Gal', 'Tal', 'Yuval', 'Amit', 'Shay', 'Yarden', 'Noam', 'Ori', 'Eden',
          'Hadar', 'Lior', 'Maayan', 'Neta', 'Omer', 'Paz', 'Roni', 'Shai', 'Tomer', 'Zohar'
        ]);
      }
      
      if (origin === 'indian' || origin === 'any') {
        names = names.concat([
          'Kiran', 'Prem', 'Santosh', 'Manju', 'Anand', 'Chaman', 'Kamal', 'Jyoti', 'Shashi', 'Noor',
          'Suman', 'Prakash', 'Jeet', 'Tej', 'Jai', 'Shanti', 'Anand', 'Mani', 'Tara', 'Roop',
          'Aman', 'Arun', 'Chandra', 'Gyan', 'Indra', 'Jivan', 'Kush', 'Madan', 'Neel', 'Om'
        ]);
      }
      
      if (origin === 'african' || origin === 'any') {
        names = names.concat([
          'Amani', 'Chioma', 'Diallo', 'Efe', 'Femi', 'Gamba', 'Hasani', 'Imamu', 'Jelani', 'Kamau',
          'Lulu', 'Masego', 'Nuru', 'Oko', 'Panya', 'Quibilah', 'Rudo', 'Sefu', 'Tafari', 'Uzoma'
        ]);
      }
      
      if (origin === 'chinese' || origin === 'any') {
        names = names.concat([
          '晓明', '雨', '天', '云', '宇', '晨', '阳', '雪', '风', '海',
          '山', '林', '天宇', '雨晨', '晓云', '天阳', '雨雪', '晓风', '天海', '雨林'
        ]);
      }
      
      if (origin === 'japanese' || origin === 'any') {
        names = names.concat([
          '陽', '空', '海', '翼', '光', '葵', '樹', '風', '雪', '月',
          '星', '空', '陽', '海', '翼', '光', '葵', '樹', '風', '雪'
        ]);
      }
      
      if (origin === 'arabic' || origin === 'any') {
        names = names.concat([
          'نور', 'سما', 'فجر', 'رؤى', 'هدى', 'سلام', 'أمل', 'سلمى', 'ريم', 'نسيم',
          'فرح', 'سهى', 'ندى', 'رنا', 'سنا', 'ضحى', 'منى', 'رجاء', 'وفاء', 'هناء'
        ]);
      }
    }
  }
  
  // Apply style filtering
  names = filterNamesByStyle(names, style, origin);
  
  // Shuffle and return requested number of names
  return shuffleArray(names, seed).slice(0, numSuggestions);
}

// Helper function to filter names by style
function filterNamesByStyle(names, style, origin) {
  // If no style specified or not enough names, return all
  if (!style || style === 'any' || names.length < 20) {
    return names;
  }
  
  // Create a copy of the names array to avoid modifying the original
  const namesCopy = [...names];
  
  // Shuffle the array with a consistent seed based on style and origin
  const seed = (style.charCodeAt(0) + (origin ? origin.charCodeAt(0) : 0)) / 100;
  const shuffledNames = shuffleArray(namesCopy, seed);
  
  // Select names based on style
  switch (style) {
    case 'common':
      // Common names are typically shorter and more familiar
      return shuffledNames.filter(name => name.length < 8).slice(0, Math.floor(shuffledNames.length * 0.6));
    case 'unique':
      // Unique names are typically longer or less common
      return shuffledNames.filter(name => name.length >= 5).slice(Math.floor(shuffledNames.length * 0.4));
    case 'traditional':
      // Traditional names are typically in the first half of the shuffled array (arbitrary but consistent)
      return shuffledNames.slice(0, Math.floor(shuffledNames.length * 0.5));
    case 'modern':
      // Modern names are typically in the second half of the shuffled array (arbitrary but consistent)
      return shuffledNames.slice(Math.floor(shuffledNames.length * 0.5));
    default:
      return shuffledNames;
  }
}

// Helper function to generate pet names
function generatePetNames(gender, style, theme, numSuggestions = 10, seed = 0) {
  let names = [];
  
  // Common pet names
  if (style === 'common' || style === 'any' || theme === 'any') {
    names = names.concat([
      'Max', 'Bella', 'Charlie', 'Lucy', 'Cooper', 'Luna', 'Buddy', 'Daisy', 'Jack', 'Sadie',
      'Rocky', 'Molly', 'Bear', 'Bailey', 'Duke', 'Stella', 'Tucker', 'Maggie', 'Oliver', 'Chloe',
      'Toby', 'Sophie', 'Lola', 'Bentley', 'Milo', 'Zoe', 'Jax', 'Lily', 'Gus', 'Penny',
      'Winston', 'Rosie', 'Murphy', 'Ruby', 'Leo', 'Piper', 'Zeus', 'Nala', 'Oscar', 'Emma'
    ]);
  }
  
  // Unique pet names
  if (style === 'unique' || style === 'any') {
    names = names.concat([
      'Zephyr', 'Echo', 'Pixel', 'Nimbus', 'Zenith', 'Vesper', 'Quill', 'Fable', 'Cipher', 'Rune',
      'Kestrel', 'Tempest', 'Wisp', 'Orbit', 'Prism', 'Sphinx', 'Vortex', 'Zest', 'Quasar', 'Lyric',
      'Frost', 'Ember', 'Onyx', 'Juniper', 'Indigo', 'Sable', 'Tundra', 'Solstice', 'Meridian', 'Halcyon',
      'Obsidian', 'Cascade', 'Zephyrus', 'Equinox', 'Nebula', 'Odyssey', 'Phoenix', 'Quantum', 'Tempus', 'Vega'
    ]);
  }
  
  // Cute pet names
  if (style === 'cute' || style === 'any') {
    names = names.concat([
      'Muffin', 'Cupcake', 'Peanut', 'Biscuit', 'Pudding', 'Button', 'Sprinkles', 'Marshmallow', 'Jellybean', 'Snuggles',
      'Bubbles', 'Cuddles', 'Pumpkin', 'Squish', 'Twinkle', 'Wiggle', 'Fluff', 'Nibbles', 'Giggles', 'Waffles',
      'Snickerdoodle', 'Butterscotch', 'Dumpling', 'Noodle', 'Pickle', 'Tootsie', 'Skittles', 'Taffy', 'Truffle', 'Whiskers',
      'Blossom', 'Cotton', 'Doodle', 'Freckles', 'Gizmo', 'Hiccup', 'Jelly', 'Mochi', 'Nugget', 'Pebbles'
    ]);
  }
  
  // Funny pet names
  if (style === 'funny' || style === 'any') {
    names = names.concat([
      'Sir Barksalot', 'Professor Whiskers', 'Captain Fluffypants', 'Mister Noodles', 'Lady Woofington', 'Doctor Purrington', 'Sergeant Slobber', 'Princess Pounce', 'Baron von Wiggletail', 'Count Meowface',
      'Sir Hopsalot', 'Madame Fuzzyface', 'Lord Chonkington', 'Duke of Waggerton', 'Queen Floofington', 'Admiral Snuggles', 'General Pawsington', 'Empress Scratchnsniff', 'King Barksley', 'Duchess Droolalot',
      'Señor Squeakerton', 'Monsieur Mittens', 'Commodore Cuddles', 'Lieutenant Lickface', 'Major Munchies', 'Colonel Clawsome', 'Archduke Fluffington', 'Countess Whiskerton', 'Prince Purrfect', 'Marquis de Meow'
    ]);
  }
  
  // Cool pet names
  if (style === 'cool' || style === 'any') {
    names = names.concat([
      'Ace', 'Blaze', 'Dash', 'Jagger', 'Maverick', 'Phoenix', 'Rogue', 'Storm', 'Viper', 'Zeke',
      'Arrow', 'Bandit', 'Cobra', 'Diesel', 'Harley', 'Jett', 'Onyx', 'Rebel', 'Titan', 'Wolf',
      'Axel', 'Blade', 'Colt', 'Draco', 'Fang', 'Ghost', 'Hunter', 'Jet', 'Kilo', 'Legend',
      'Nitro', 'Orion', 'Phantom', 'Ranger', 'Savage', 'Thunder', 'Venom', 'Warrior', 'Xander', 'Yukon'
    ]);
  }
  
  // Theme-specific names
  if (theme === 'food') {
    names = names.concat([
      'Cookie', 'Pepper', 'Ginger', 'Oreo', 'Olive', 'Mocha', 'Cocoa', 'Biscuit', 'Honey', 'Peanut',
      'Muffin', 'Taco', 'Nacho', 'Noodle', 'Pickle', 'Waffles', 'Pancake', 'Brownie', 'Cupcake', 'Donut'
    ]);
  } else if (theme === 'nature') {
    names = names.concat([
      'River', 'Sky', 'Storm', 'Willow', 'Aspen', 'Maple', 'Cedar', 'Pebble', 'Coral', 'Daisy',
      'Fern', 'Jasper', 'Moss', 'Sage', 'Sunny', 'Timber', 'Breeze', 'Cliff', 'Meadow', 'Misty'
    ]);
  } else if (theme === 'mythology') {
    names = names.concat([
      'Zeus', 'Apollo', 'Athena', 'Thor', 'Loki', 'Odin', 'Freya', 'Artemis', 'Hera', 'Hermes',
      'Isis', 'Osiris', 'Anubis', 'Bastet', 'Hades', 'Persephone', 'Poseidon', 'Ares', 'Gaia', 'Atlas'
    ]);
  } else if (theme === 'literature') {
    names = names.concat([
      'Gatsby', 'Atticus', 'Scout', 'Sherlock', 'Watson', 'Darcy', 'Romeo', 'Juliet', 'Hamlet', 'Ophelia',
      'Heathcliff', 'Holden', 'Matilda', 'Hermione', 'Potter', 'Frodo', 'Gandalf', 'Arwen', 'Aslan', 'Narnia'
    ]);
  } else if (theme === 'movies') {
    names = names.concat([
      'Simba', 'Nala', 'Timon', 'Pumba', 'Yoda', 'Chewie', 'Leia', 'Vader', 'Rocky', 'Rambo',
      'Ripley', 'Neo', 'Trinity', 'Marty', 'Doc', 'Indy', 'Bond', 'Groot', 'Rocket', 'Thanos'
    ]);
  } else if (theme === 'colors') {
    names = names.concat([
      'Blue', 'Ruby', 'Amber', 'Ebony', 'Jade', 'Rusty', 'Silver', 'Goldie', 'Violet', 'Indigo',
      'Scarlet', 'Sienna', 'Hazel', 'Ivory', 'Onyx', 'Raven', 'Slate', 'Tawny', 'Crimson', 'Cobalt'
    ]);
  }
  
  // Filter by gender if specified
  if (gender === 'male') {
    // These are somewhat arbitrary gender assignments, but they help provide gender-specific options
    const maleNames = [
      'Max', 'Charlie', 'Cooper', 'Buddy', 'Jack', 'Rocky', 'Bear', 'Duke', 'Tucker', 'Oliver',
      'Toby', 'Bentley', 'Milo', 'Jax', 'Gus', 'Winston', 'Murphy', 'Leo', 'Zeus', 'Oscar',
      'Zephyr', 'Pixel', 'Zenith', 'Quill', 'Cipher', 'Orbit', 'Sphinx', 'Vortex', 'Quasar',
      'Frost', 'Onyx', 'Obsidian', 'Phoenix', 'Quantum', 'Tempus',
      'Sir Barksalot', 'Professor Whiskers', 'Captain Fluffypants', 'Mister Noodles', 'Baron von Wiggletail', 'Count Meowface',
      'Sir Hopsalot', 'Lord Chonkington', 'Duke of Waggerton', 'Admiral Snuggles', 'General Pawsington', 'King Barksley',
      'Señor Squeakerton', 'Monsieur Mittens', 'Commodore Cuddles', 'Lieutenant Lickface', 'Major Munchies', 'Colonel Clawsome', 'Prince Purrfect', 'Marquis de Meow',
      'Ace', 'Blaze', 'Dash', 'Jagger', 'Maverick', 'Phoenix', 'Rogue', 'Storm', 'Viper', 'Zeke',
      'Arrow', 'Bandit', 'Cobra', 'Diesel', 'Harley', 'Jett', 'Onyx', 'Rebel', 'Titan', 'Wolf',
      'Axel', 'Blade', 'Colt', 'Draco', 'Fang', 'Ghost', 'Hunter', 'Jet', 'Kilo', 'Legend',
      'Nitro', 'Orion', 'Phantom', 'Ranger', 'Savage', 'Thunder', 'Venom', 'Warrior', 'Xander', 'Yukon'
    ];
    names = names.filter(name => maleNames.includes(name) || !['Bella', 'Lucy', 'Luna', 'Daisy', 'Sadie', 'Molly', 'Stella', 'Maggie', 'Chloe', 'Sophie', 'Lola', 'Zoe', 'Lily', 'Penny', 'Rosie', 'Ruby', 'Piper', 'Nala', 'Emma'].includes(name));
  } else if (gender === 'female') {
    const femaleNames = [
      'Bella', 'Lucy', 'Luna', 'Daisy', 'Sadie', 'Molly', 'Stella', 'Maggie', 'Chloe', 'Sophie',
      'Lola', 'Zoe', 'Lily', 'Penny', 'Rosie', 'Ruby', 'Piper', 'Nala', 'Emma',
      'Echo', 'Nimbus', 'Vesper', 'Fable', 'Rune', 'Kestrel', 'Tempest', 'Wisp', 'Prism', 'Lyric',
      'Ember', 'Juniper', 'Indigo', 'Sable', 'Tundra', 'Solstice', 'Meridian', 'Halcyon', 'Cascade', 'Nebula', 'Odyssey', 'Vega',
      'Muffin', 'Cupcake', 'Biscuit', 'Pudding', 'Button', 'Sprinkles', 'Marshmallow', 'Jellybean', 'Snuggles',
      'Bubbles', 'Cuddles', 'Pumpkin', 'Squish', 'Twinkle', 'Wiggle', 'Fluff', 'Nibbles', 'Giggles', 'Waffles',
      'Snickerdoodle', 'Butterscotch', 'Dumpling', 'Noodle', 'Pickle', 'Tootsie', 'Skittles', 'Taffy', 'Truffle', 'Whiskers',
      'Blossom', 'Cotton', 'Doodle', 'Freckles', 'Gizmo', 'Hiccup', 'Jelly', 'Mochi', 'Nugget', 'Pebbles',
      'Lady Woofington', 'Doctor Purrington', 'Princess Pounce', 'Madame Fuzzyface', 'Queen Floofington', 'Empress Scratchnsniff', 'Duchess Droolalot', 'Countess Whiskerton'
    ];
    names = names.filter(name => femaleNames.includes(name) || !['Max', 'Charlie', 'Cooper', 'Buddy', 'Jack', 'Rocky', 'Bear', 'Duke', 'Tucker', 'Oliver', 'Toby', 'Bentley', 'Milo', 'Jax', 'Gus', 'Winston', 'Murphy', 'Leo', 'Zeus', 'Oscar'].includes(name));
  }
  
  // Shuffle and return requested number of names
  return shuffleArray(names, seed).slice(0, numSuggestions);
}

// Function to get fallback names for personal naming
function getFallbackNames(type, gender, style, origin, theme, count = 10, seed = 0) {
  // Comprehensive fallback lists
  const fallbacks = {
    baby: {
      english: {
        boy: [
          'Liam', 'Noah', 'Oliver', 'Elijah', 'William', 'James', 'Benjamin', 'Lucas', 'Henry', 'Alexander',
          'Mason', 'Michael', 'Ethan', 'Daniel', 'Jacob', 'Logan', 'Jackson', 'Levi', 'Sebastian', 'Mateo',
          'Jack', 'Owen', 'Theodore', 'Aiden', 'Samuel', 'Joseph', 'John', 'David', 'Wyatt', 'Matthew'
        ],
        girl: [
          'Olivia', 'Emma', 'Charlotte', 'Amelia', 'Ava', 'Sophia', 'Isabella', 'Mia', 'Evelyn', 'Harper',
          'Luna', 'Camila', 'Gianna', 'Elizabeth', 'Eleanor', 'Ella', 'Abigail', 'Sofia', 'Avery', 'Scarlett',
          'Emily', 'Aria', 'Penelope', 'Chloe', 'Layla', 'Mila', 'Nora', 'Hazel', 'Madison', 'Ellie'
        ],
        neutral: [
          'Alex', 'Jordan', 'Taylor', 'Morgan', 'Casey', 'Riley', 'Avery', 'Quinn', 'Rowan', 'Skyler',
          'Dakota', 'River', 'Phoenix', 'Sage', 'Remy', 'Blake', 'Charlie', 'Finley', 'Emerson', 'Hayden',
          'Parker', 'Sawyer', 'Kai', 'Reese', 'Jamie', 'Ari', 'Drew', 'Shawn', 'Cameron', 'Elliot'
        ]
      },
      // Other origins...
    },
    pet: {
      common: [
        'Max', 'Bella', 'Charlie', 'Lucy', 'Cooper', 'Luna', 'Buddy', 'Daisy', 'Jack', 'Sadie',
        'Rocky', 'Molly', 'Bear', 'Bailey', 'Duke', 'Stella', 'Tucker', 'Maggie', 'Oliver', 'Chloe',
        'Toby', 'Sophie', 'Lola', 'Bentley', 'Milo', 'Zoe', 'Jax', 'Lily', 'Gus', 'Penny',
        'Winston', 'Rosie', 'Murphy', 'Ruby', 'Leo', 'Piper', 'Zeus', 'Nala', 'Oscar', 'Emma'
      ],
      // Other styles...
    }
  };
  
  // Get appropriate fallback list
  let nameList = [];
  
  if (type === 'baby') {
    // Default to English if origin not found
    const originList = fallbacks.baby[origin] || fallbacks.baby.english;
    // Default to boy names if gender not found
    nameList = originList[gender] || originList.boy;
  } else {
    // For pet names, use style-based lists
    nameList = fallbacks.pet[style] || fallbacks.pet.common;
  }
  
  // Shuffle and return requested number of names
  return shuffleArray(nameList, seed).slice(0, count);
}

// Function to generate fallback names for function naming
function generateFallbackNames(input, type, count = 10, seed = 0) {
  // Simple pattern recognition for function naming
  const prefixes = ['get', 'set', 'create', 'update', 'delete', 'fetch', 'process', 'calculate', 'validate', 'format', 'convert', 'parse', 'handle', 'initialize', 'render', 'display', 'show', 'hide', 'toggle', 'enable', 'disable', 'check', 'verify', 'find', 'search', 'sort', 'filter', 'map', 'reduce', 'transform'];
  
  const suffixes = ['Data', 'Value', 'Item', 'Element', 'Component', 'Object', 'Array', 'List', 'Collection', 'Set', 'Map', 'Dictionary', 'Info', 'Details', 'Summary', 'Result', 'Response', 'Request', 'Input', 'Output', 'Error', 'Exception', 'Event', 'Callback', 'Handler', 'Listener', 'Observer', 'Provider', 'Consumer', 'Factory'];
  
  // Extract keywords from input
  const keywords = input
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(word => word.length > 3)
    .map(word => word.charAt(0).toUpperCase() + word.slice(1));
  
  // Generate names based on keywords
  const names = [];
  
  // Add prefix + keyword combinations
  for (const prefix of shuffleArray(prefixes, seed).slice(0, 5)) {
    for (const keyword of shuffleArray(keywords, seed + 0.1).slice(0, 3)) {
      names.push(prefix + keyword);
    }
  }
  
  // Add keyword + suffix combinations
  for (const keyword of shuffleArray(keywords, seed + 0.2).slice(0, 5)) {
    for (const suffix of shuffleArray(suffixes, seed + 0.3).slice(0, 3)) {
      names.push(keyword + suffix);
    }
  }
  
  // Add prefix + keyword + suffix combinations
  for (const prefix of shuffleArray(prefixes, seed + 0.4).slice(0, 3)) {
    for (const keyword of shuffleArray(keywords, seed + 0.5).slice(0, 2)) {
      for (const suffix of shuffleArray(suffixes, seed + 0.6).slice(0, 2)) {
        names.push(prefix + keyword + suffix);
      }
    }
  }
  
  // If we still don't have enough names, add some generic ones
  if (names.length < count) {
    const genericNames = [
      'processData', 'handleRequest', 'calculateResult', 'validateInput', 'formatOutput',
      'getData', 'setData', 'createItem', 'updateItem', 'deleteItem',
      'fetchData', 'processResult', 'initializeComponent', 'renderElement', 'displayInfo',
      'checkValidity', 'verifyCredentials', 'findElement', 'searchDatabase', 'sortItems',
      'filterResults', 'mapValues', 'reduceArray', 'transformData', 'convertFormat',
      'parseInput', 'handleEvent', 'toggleVisibility', 'enableFeature', 'disableOption'
    ];
    
    names.push(...shuffleArray(genericNames, seed + 0.7));
  }
  
  // Remove duplicates and return requested number of names
  return [...new Set(names)].slice(0, count);
}

// Helper function to shuffle an array with a seed
function shuffleArray(array, seed = Math.random()) {
  const newArray = [...array];
  let currentIndex = newArray.length;
  let temporaryValue, randomIndex;
  
  // Create a seeded random number generator
  const seededRandom = function() {
    const x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
  };
  
  // While there remain elements to shuffle...
  while (0 !== currentIndex) {
    // Pick a remaining element...
    randomIndex = Math.floor(seededRandom() * currentIndex);
    currentIndex -= 1;
    
    // And swap it with the current element.
    temporaryValue = newArray[currentIndex];
    newArray[currentIndex] = newArray[randomIndex];
    newArray[randomIndex] = temporaryValue;
  }
  
  return newArray;
}

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
EOL

echo "Updated server.js with all improvements"
